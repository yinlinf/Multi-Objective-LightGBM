from __future__ import absolute_import

from pkg_resources import get_distribution, DistributionNotFound

try:
    __version__ = get_distribution(__name__).version
except DistributionNotFound:
    # package is not installed
    __version__ = "unknown"

import json
import functools

from builtins import map, str as py3_str, bytes as py3_bytes
from past.builtins import basestring
from builtins import object
from contextlib import contextmanager

from buzzsaw._pybs import ffi, lib
lib.buzzsaw_setup_logging()


RESULT_OK = b'Okay'


class BuzzsawError(Exception):
    pass


def _format(docs):
    """
    Formats a group of documents into a line-delimited jsonl blob, which is the
    format that buzzsaw-python expects.
    :param docs: either a string or an iterable of documents. Each element of
    the iterable can be another iterable, consisting of actual documents, which
    is treated as a group by the bindings.

    :returns: a utf-8 encoded byte string of linebreak delimited jsonl
    documents.
    """

    # This little helper allows us to handle the case
    # where the input is a python array of strings which are
    # the json serialized docs.
    def _maybe_json_dumps(doc):
        if isinstance(doc, basestring):
            return doc.strip()
        else:
            return json.dumps(doc)

    # If docs is already a string, we assume that it is a valid JSONL
    # blob and we can pass it directly to buzzsaw; otherwise
    # we transform it into one.
    if not isinstance(docs, basestring):
        docs = "\n".join(map(_maybe_json_dumps, docs))

    # NOTE: This is only possible in python 2 because we use the future
    # compatibility library (see `from builtins import map, str, bytes` above)
    if isinstance(docs, py3_str):
        return docs.strip().encode('utf-8')
    elif isinstance(docs, py3_bytes):
        return docs.strip()
    else:
        raise BuzzsawError("Failed to format input %s" % docs)


def from_file(config_path):
    """
    Loads a Buzzsaw task from a given configuration path.
    :param path: str
    :returns: a Buzzsaw instance wrapping the opaque pointer
    returned by the api.
    """
    result = lib.buzzsaw_from_file(config_path.encode('utf-8'))

    # Note that we don't call a deallocate on the entire
    # result, just the status string - since we intend to keep the
    # data pointer for a while.
    with as_str(result.status) as status:
        if not status == RESULT_OK:
            raise BuzzsawError("Unable to load config: %s!" % status)
        else:
            return Buzzsaw(result.data)


def from_config(config):
    """
    Loads a Buzzsaw task from a config structure - either a JSON
    string or a JSON serializable structure.
    :param config: a dict or a string
    :returns: a Buzzsaw instance wrapping the opaque pointer returned
    by the api.
    """
    if not isinstance(config, basestring):
        config = json.dumps(config)

    if isinstance(config, py3_str):
        config = config.encode('utf-8')

    result = lib.buzzsaw_from_config(config)

    # Note that we don't call a deallocate on the entire
    # result, just the status string - since we intend to keep the
    # data pointer for a while.
    with as_str(result.status) as status:
        if not status == RESULT_OK:
            raise BuzzsawError("Unable to load config: %s!" % status)
        else:
            return Buzzsaw(result.data)


@contextmanager
def as_str(p):
    """
    Simple context manager to handle deallocating any owned strings passed
    back to us from the C API.
    """
    yield ffi.string(p)
    lib.buzzsaw_free_str(p)


@contextmanager
def as_fitted_config(result):
    """
    A context manager to handle extracting the data from the
    config fitting operation and to handle memory deallocation of
    the buzzsaw result type returned by the API.
    """
    try:
        status = ffi.string(result.status)
        assert status == RESULT_OK, status

        yield ffi.string(result.data)
    except AssertionError as e:
        raise BuzzsawError(e.args)
    finally:
        lib.buzzsaw_free_fit_result(result)


@contextmanager
def as_channels(result):
    """
    A context manager to handle extracting channels from the Buzzsaw C API
    result and to deallocate the memory once done with that.
    """
    try:
        status = ffi.string(result.status)
        assert status == RESULT_OK, status

        yield ffi.string(result.data)
    except AssertionError as e:
        raise BuzzsawError(e.args)
    finally:
        lib.buzzsaw_free_str(result.status)
        lib.buzzsaw_free_str(result.data)


@contextmanager
def as_features(result, grouped=False, **kwargs):
    """
    A context manager to handle extracting features from the Buzzsaw C API
    result and to deallocate the memory once we are finished with that.
    """
    try:
        status = ffi.string(result.status)
        assert status == RESULT_OK, status

        features_output = result.data

        records = ffi.unpack(features_output.data, features_output.len)

        def unpack_features():
            for group in records:
                grouped_features = ffi.unpack(group.data, group.len)

                features = [ffi.buffer(feature.data, feature.len)[:]
                            for feature in grouped_features]

                assert len(features) != 0, "No features returned"

                # Grouped inputs are returned as a list of lists of features,
                # just like their original representation. Ungrouped input is
                # coerced to a single group before processing (as if it were
                # a single line of grouped documents), so we need to unpack it
                # from the wrapping list before yielding in order to match the
                # original structure.
                if grouped:
                    yield features
                else:
                    assert len(features) == 1,\
                        "Grouped output returned for ungrouped input!"
                    yield features[0]

        # We need to evaluate this generator so that once the
        # context manager exits the C results can be deallocated.
        yield list(unpack_features())

    except AssertionError as e:
        raise BuzzsawError(e.args)
    finally:
        lib.buzzsaw_free_features_result(result)


def feature_formatter(func):
    """
    A decorator to handle the boilerplate of passing in
    raw documents and extracting back feature lists from the
    Buzzsaw API.

    This mainly handles taking care of either passing in raw
    blocks of data directly into the API, or transforming a
    python datastructure into a raw block of data suitable for
    passing in to the API.
    """
    @functools.wraps(func)
    def wrapper(obj, docs, grouped=False, **kwargs):
        docs = _format(docs)

        with as_features(func(obj, docs, grouped), grouped) as features:
            return features

    return wrapper


class Buzzsaw(object):
    """
    Interface class for interacting with a Buzzsaw task, in order to
    perform featurization from Python via the C API exposed by Buzzsaw.
    """

    def __init__(self, ptr):
        # Never reference this pointer anywhere except in this class
        self.__ptr = ptr

    def __del__(self):
        lib.buzzsaw_free(self.__ptr)
        self.__ptr = None

    @staticmethod
    def from_file(fname):
        return from_file(fname)

    @staticmethod
    def from_config(config):
        return from_config(config)

    def channels(self):
        with as_channels(lib.buzzsaw_channels(self.__ptr)) as x:
            # The type of x will always be py3_bytes, and since python3.5
            # does not decode those automatically, we have to manually
            # call .decode('utf-8') here.
            return json.loads(x.decode('utf-8'))

    @feature_formatter
    def train(self, docs, grouped=False):
        return lib.buzzsaw_supervised(self.__ptr, docs, grouped)

    @feature_formatter
    def features(self, docs, grouped=False):
        return lib.buzzsaw_features(self.__ptr, docs, grouped)

    @feature_formatter
    def pack_train(self, docs, grouped=False):
        return lib.buzzsaw_pack_supervised(self.__ptr, docs, grouped)

    @feature_formatter
    def pack_features(self, docs, grouped=False):
        return lib.buzzsaw_pack_features(self.__ptr, docs, grouped)

    @staticmethod
    def fit(config, docs, grouped=False, **kwargs):
        if not isinstance(config, basestring):
            config = json.dumps(config).strip().encode('utf-8')

        docs = _format(docs)

        with as_fitted_config(lib.buzzsaw_fit(config, docs, grouped)) as config:
            return config
