# auto-generated file
__all__ = ['lib', 'ffi']

import os
from buzzsaw._pybs__ffi import ffi

lib = ffi.dlopen(os.path.join(os.path.dirname(__file__), '_pybs__lib.so'), 4098)
del os
