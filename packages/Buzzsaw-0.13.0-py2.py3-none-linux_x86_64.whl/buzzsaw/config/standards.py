"""Buzzsaw Configuration Standards

This module defines a couple of standards in Buzzsaw Configurations.
"""


class DAG:
    """Directed Acyclic Graphs available for Buzzsaw configurations"""
    fit = "fit"
    features = "features"
    supervised = "supervised"


class DType:
    """Data types supported by Buzzsaw"""
    string = "str"
    integer = "int"
    float64 = "f64"
    boolean = "bool"
    dense_vector = "d64"
    sparse_vector = "sparse"
    string_set = "[str]"
    mapped = "mapped"


class OutputFormat:
    """Output formats supported by Buzzsaw"""
    JSON = "JSON"
    SVM = "SVM"
    TFR = "TFR"
    TSV = "TSV"
    VW = "VW"