from collections import Iterable
from itertools import chain
from builtins import map


def flatten(nested):
    """ Helper to flatten a nested list"""
    wrapped = map(lambda x: x if isinstance(x, Iterable) else [x], nested)
    return chain.from_iterable(wrapped)