"""Buzzsaw Configuration Generator

This module helps ease the creation of Buzzsaw configurations.

TODO:
    - Refactor the elements of `procs` to be their own type instead of a dict.
    This will allow us to clean up a hacky implementation in show_node_outputs
        - node_name = next(iter(node))
"""
import json
import copy
from .. import Buzzsaw, from_config
from collections import namedtuple
from .standards import DAG, OutputFormat
from .utils import flatten


def default_dag():
    return {"channels": {}, "procs": []}


class BuzzsawConfig:
    """Holds the state of a Buzzsaw configuration

    Attributes:
        fit (dict): representation of the fit DAG
        features (dict): representation of the features DAG
        supervised (dict): representation of the supervised DAG
        output (dict): representation of the output settings
    """

    def __init__(self, filename=None):
        """Args:
            filename (str, optional): Specifies whether to load a JSON file at
                the filename or use a blank config dictionary otherwise.
        """
        if filename is None:
            self._get_default_config()
        else:
            self._get_config_from_file(filename)

    def _get_default_config(self):
        """Sets config attributes to their blank defaults"""
        self.fit = default_dag()
        self.features = default_dag()
        self.supervised = default_dag()
        self.output = {}

    def _get_config_from_file(self, filename):
        """Imports config attributes from an existing file. Only supports
           json configs
        """
        with open(filename, 'r') as file:
            config = json.load(file)

        # Defaults provided if key isn't found
        self.fit = config["Supervised"].get("fit", default_dag())
        self.features = config["Supervised"].get("features", default_dag())
        self.supervised = config["Supervised"].get("supervised", default_dag())
        self.output = config["Supervised"].get("output", {})

    def add_channel(self, name, dtype, dag, imputer=None):
        """ Adds a channel to the config. If there's an imputer, the key value
            pair to insert is the name and a dictionary. Otherwise its just the
            name and a string

        Args:
            name (str): Name of the channel.
            dtype (str): Type of the channel as a string.
            dag (str): DAG where the channel will be inserted.
            imputer(Imputer namedtuple): imputer
        """
        value = dtype if imputer is None else {"channel_type": dtype,
                                               "imputer": imputer.imputer_type,
                                               "settings": imputer.settings}
        if dag == DAG.fit:
            self.fit["channels"][name] = value
        elif dag == DAG.features:
            self.features["channels"][name] = value
        elif dag == DAG.supervised:
            self.supervised["channels"][name] = value

    def add_proc(self, output_name, channel_names, fps, dag, fit_inputs=None):
        """Adds a proc dictionary to the config

        Args:
            output_name (str): name of the output node
            channel_names (list of str): names of the inputs to this stack
            fps (list): feature processors to be used in this stack
            dag (str): DAG where the proc will be inserted
            fit_inputs (list of str): names of the fit_input channels
        """
        # Flatten the list for convenience. Allows manipulation of lists of
        # FeatureProcessors
        procs = [{proc.name: proc.settings} for proc in flatten(fps)]
        fp_stack = {output_name: {"inp": channel_names, "run": procs}}
        if fit_inputs is not None:
            fp_stack[output_name]["fit_inp"] = fit_inputs

        if dag == DAG.fit:
            self.fit["procs"].append(fp_stack)
        elif dag == DAG.features:
            self.features["procs"].append(fp_stack)
        elif dag == DAG.supervised:
            self.supervised["procs"].append(fp_stack)

    def set_output(self, output_format, settings):
        """Sets the output format of the config

        Args:
            output_format(str): name of the output format
            settings (dict): dictionary of settings
        """
        self.output = {output_format: settings}

    @property
    def config(self):
        """Property for getting the config as a dict"""
        config = {"Supervised": {}}

        # If the fit channel has anything in it, add it, otherwise skip
        if len(self.fit["channels"]) > 0:
            config["Supervised"]["fit"] = self.fit
        config["Supervised"]["features"] = self.features
        config["Supervised"]["supervised"] = self.supervised
        config["Supervised"]["output"] = self.output
        return config

    @property
    def as_json(self):
        """Property for getting the config as json"""
        return json.dumps(self.config, indent=4)

    """Series of functions for setting the output format"""
    def set_output_json(self, targets, features):
        """This format allows users to set the field name of the outputs. To do
            so, pass in dictionaries with keys representing the desired field
            names and values being the BuzzsawObject associated with this name.
            To set the fieldnames to the name of the channel, just pass in
            lists of FeatureProcessors.

        Args:
            targets (list of BuzzsawNode or str:BuzzsawNode dict)
            features (list of BuzzsawNode or str:BuzzsawNode dict)
        """
        settings_dict = {"targets": {}, "features": {}}
        if isinstance(targets, dict):
            settings_dict["targets"] = {name: node.name for name, node in targets.items()}
        else:
            for channel in targets:
                settings_dict["targets"][channel.name] = channel.name
        if isinstance(features, dict):
            settings_dict["features"] = {name: node.name for name, node in features.items()}
        else:
            for channel in features:
                settings_dict["features"][channel.name] = channel.name

        self.set_output(OutputFormat.JSON, settings_dict)

    def set_output_svm(self, target, feature, task, query=None, precision=None, comment=None):
        """Args:
            target (BuzzsawNode): target channel
            feature (BuzzsawNode): feature channel
            task (str): designates the task
            query (int, optional): the query ID associated with this output
            precision (int, optional): number of decimal places
            comment (str, optional): comment
        """
        settings_dict = {"target": target.name, "features": feature.name,
                         "task": task, "query": query, "precision": precision,
                         "comment": comment}
        pruned = {k: v for k, v in settings_dict.items() if v is not None}
        self.set_output(OutputFormat.SVM, pruned)

    def set_output_tfr(self, targets, features):
        """Args:
            targets (list of BuzzsawNode): target channels,
            features (list of BuzzsawNode): feauture channels
        """
        settings_dict = {"targets": [channel.name for channel in targets],
                         "features": [channel.name for channel in features]}
        self.set_output(OutputFormat.TFR, settings_dict)

    def set_output_tsv(self, targets, features, precision=None):
        """Args:
            targets (list of BuzzsawNode): target channels
            features (list of BuzzsawNode): feauture channels
            precision (int, optional): number of decimal places
        """
        settings_dict = {"targets": [channel.name for channel in targets],
                         "features": [channel.name for channel in features],
                         "precision": precision}
        pruned = {k: v for k, v in settings_dict.items() if v is not None}
        self.set_output(OutputFormat.TSV, pruned)

    def set_output_vw(self, target, ns, task, weight=None, label=None, precision=None):
        """Args:
            target (BuzzsawNode): target channel
            ns (dict of BuzzsawNode:str): namespace dictionary
            task (str): specifies the VW task
            weight (BuzzsawNode, optional): weight channel
            label (BuzzsawNode, optional): label channel
            precision (int, optional)
        """
        settings_dict = {
            "ns": {channel.name: vw_namespace for channel, vw_namespace in ns.items()},
            "task": task,
            "precision": precision,
            "target": target.name if target else None,
            "weight": weight.name if weight else None,
            "label": label.name if label else None,
        }
        pruned = {k: v for k, v in settings_dict.items() if v is not None}
        self.set_output(OutputFormat.VW, pruned)

    def show_node_outputs(self, fit_docs, generate_docs):
        """Shows the intermediary states of the document during transformation

            Args:
                fit_docs (list of dict): documents we want to use in the fit stage
                generate_docs (list of dict): documents that we want to examine
        """
        output_settings = {"targets": {}, "features": {}}

        for name in self.supervised["channels"].keys():
            output_settings["targets"][name] = name
        for node in self.supervised["procs"]:
            node_name = next(iter(node))
            output_settings["targets"][node_name] = node_name

        for name in self.features["channels"].keys():
            output_settings["features"][name] = name
        for node in self.features["procs"]:
            node_name = next(iter(node))
            output_settings["features"][node_name] = node_name

        config_copy = copy.deepcopy(self)
        config_copy.set_output(OutputFormat.JSON, output_settings)

        fitted_config = Buzzsaw.fit(config_copy.config, fit_docs)
        transformed = from_config(fitted_config).train(generate_docs)

        return transformed

    def write(self, filename):
        """Write the configuration to file"""
        with open(filename, 'w') as file:
            json.dump(self.config, file)


class BuzzsawNode:
    """Representation of a node in a Buzzsaw configuration

    Attributes:
        channel_names (list of str or list of BuzzsawNode) Name(s) associated with this node
        config (BuzzsawConfig): the config object this is associted with
        dag (str): the DAG this is associated with
    """
    def __init__(self, channel_names, config, dag):
        self.channel_names = [str(x) for x in channel_names]
        self.config = config
        self.dag = dag

    @property
    def name(self):
        return ":".join(self.channel_names)

    def apply(self, output_name, fps, fit_inputs=None):
        """Adds the proc to the config representation and returns a
            BuzzsawInputrepresenting the result of these transformations

        Args:
            output_name (str): string associated with the result of the FPs
            fps (list of FeatureProcessor): All the feature
                processors to be applied
            fit_inputs (list of BuzzsawNode): list of Nodes from the fit DAG

        """
        self.config.add_proc(output_name=output_name,
                             channel_names=self.channel_names,
                             fps=fps,
                             dag=self.dag,
                             fit_inputs=[node.name for node in fit_inputs] if fit_inputs else None)

        return BuzzsawNode(channel_names=[output_name], config=self.config, dag=self.dag)

    def __str__(self):
        return self.name


class BuzzsawInput(BuzzsawNode, object):
    """Representation of an input channel in a Buzzsaw configuration

    Attributes:
        channel_name (str): Name of the channel
        datatype (str): Datatype of this channel
        config (BuzzsawConfig): The config object this is associated with
        dag (str): The DAG this is associated with
        imputer (Imputer namedtuple): imputer for this channel
    """

    def __init__(self, channel_name, datatype, config, dag, imputer=None):
        self.channel_name = channel_name
        self.datatype = datatype
        config.add_channel(name=self.name,
                           dtype=self.datatype,
                           dag=dag,
                           imputer=imputer)
        super(BuzzsawInput, self).__init__(channel_names=[channel_name], config=config, dag=dag)

    @property
    def name(self):
        return self.channel_name


class FeatureProcessor:
    """ Class for feature processors
    """
    def __init__(self, name, settings):
        """
        Args:
            name (str): Name of the FP. Must match the Buzzsaw definition
            settings (dict): dictionary of settings
        """
        self.name = name
        self.settings = settings


"""
NamedTuple for imputers
    imputer_type (str): type of this imputer e.g. "Constant"
    settings (dict): dictionary of settings
"""
Imputer = namedtuple('Imputer', ['imputer_type', 'settings'])