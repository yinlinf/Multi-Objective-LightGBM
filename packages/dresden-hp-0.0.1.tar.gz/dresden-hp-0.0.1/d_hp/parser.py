from __future__ import absolute_import
from itertools import combinations, product, count
import re

import scipy.stats as stats
from six.moves import map
from six.moves import range

PSET_RX = re.compile(r'(?<!\\):')


def splitter(t, values):
    # Optional, discrete
    if t == 'o':
        yield ""
        yield values

    # Optional, generic
    elif t.startswith('o'):
        if t[1] == "s":
            raise Exception("Cannot use optional with distribution sampling!")
        yield ""
        for v in splitter(t[1:], values):
            yield v

    # Discrete
    elif t == 'd':
        for v in values.split(';'):
            yield v

    # power set
    elif t == 'p':
        delim, values = PSET_RX.split(values, 1)
        delim = delim.replace(r'\:', ':')
        vs = values.split(';')
        for i in range(1, len(vs) + 1):
            for c in combinations(vs, i):
                yield delim.join(c)

    # range
    elif t == 'r':
        t = float if ('.' in values or 'e' in values) else int
        start, stop, incr = list(map(t, values.split(':')))
        while (start <= stop if incr > 0 else start >= stop):
            yield start
            start += incr

    elif t == 's':
        dist, rest = values.split(':', 1)
        params = () if not rest else list(map(float, rest.split(':')))
        s = getattr(stats, dist, None)

        if s is None:
            raise TypeError("Unknown distribution `%s`" % dist)

        yield s(*params)


def regex_replace(rx, template):
    c = count()
    return rx.sub(lambda _: "{P%i}" % next(c), template)


class Parser(object):
    def parse(self, raw):
        raise NotImplementedError()


class SimpleParser(object):
    rx = re.compile(r'\{(s|o?[drp]?){1,2}:[^}]+\}')

    def parse(self, template):
        def f(ss):
            sf = {}
            isDiscrete = True
            for i, (t, v) in enumerate(ss):
                params = list(splitter(t, v))
                if len(params) == 1 and hasattr(params[0], 'rvs'):
                    params = params[0]
                    isDiscrete = False

                sf["P%i" % i] = params

            return sf, isDiscrete

        rule_sets = []
        for rule in self.rx.finditer(template):
            rule_sets.append(rule.group()[1:-1].split(':', 1))

        pTemplate = regex_replace(self.rx, template)
        parameters, isDiscrete = f(rule_sets)
        return pTemplate, parameters, isDiscrete


from .templater import Templater


def parse_string(string):
    sp = SimpleParser()
    template, hps, isDiscrete = sp.parse(string)
    return Templater(template), hps, isDiscrete


def parse_file(path):
    with open(path) as f:
        return parse_string(f.read())
