from __future__ import absolute_import
import subprocess
import shlex
import logging
import time
import select

from .base import Evaluator


class ProcEvaluator(Evaluator):
    """
    Base class for external process based running
    """

    def execute(self, command, name, scorer=lambda x: False):
        try:
            retcode, res = self.launch_proc(command, name, scorer)

        except OSError:
            logging.exception("trial failed!  Does your executable exist?")
            return None

        except Exception:
            logging.exception("trial failed!")
            return None

        else:
            if res is not None:
                try:
                    res = float(res.strip().split()[-1])
                except (ValueError, IndexError) as e:
                    res = float('nan')

            return res

    def launch_proc(self, command, name, scorer):
        logging.info("Running %s", command)
        cmd = shlex.split(command)
        proc = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            stdout=subprocess.PIPE)

        rets = self.log_process(proc, name, scorer)

        # Clean up
        proc.kill()
        retcode = proc.wait()
        return retcode, rets

    @staticmethod
    def log_process(proc, name, scorer):
        rets = None
        while True:
            so = proc.stdout.fileno()
            ri, _, err = select.select([so], [], [so], 0.1)
            if ri:
                x = proc.stdout.readline()
                if not x:
                    break

                logging.info("%s: %s", name, x.strip())
                if scorer(x):
                    rets = x

            elif err:
                break

        return rets
