class Evaluator(object):
    def __init__(self, trial_id, hp_params, context, meta_params):
        self.trial_id = trial_id
        self.hp_params = hp_params
        self.context = context
        self.meta_params = meta_params

    def evaluate(self, allowed_time):
        raise NotImplementedError()
