from __future__ import absolute_import
import re
from .proc import ProcEvaluator
import six


def replace(ctx):
    def f(mg):
        variable = mg.groups()[0]
        if variable not in ctx:
            raise Exception("Unknown meta variable `{}`".format(variable))

        return six.text_type(ctx[variable])

    return f


class TemplateProcContext(object):
    def __init__(self, train_template, test, scorer, env_variables):
        self.train = train_template
        self.test = test
        self.scorer = scorer
        self.env_vars = env_variables


VAR_RX = re.compile(r'<(\w+)>')


class TemplateProcEvaluator(ProcEvaluator):
    """
    Template runner builds an external command from hyperparameters.
    """

    def template_vars(self, cmd):
        env_vars = self.context.env_vars.copy()
        env_vars['TRIAL'] = self.trial_id
        return VAR_RX.sub(replace(env_vars), cmd)

    def train_template(self):
        return self.template_vars(self.context.train.template(self.hp_params))

    def evaluate(self, allowed_time):
        train_command = self.train_template()
        if not self.has_test():
            # Everything is done in the train script
            return self.execute(train_command, "Train/Test",
                                self.context.scorer)

        # Train then Test
        self.execute(train_command, "Train")
        test_command = self.template_vars(self.context.test)
        return self.execute(test_command, "Test", self.context.scorer)

    def has_test(self):
        return self.context.test is not None


class ConfigProcContext(object):
    def __init__(self, train_command, test_command, scorer, env_variables,
                 config, config_path):
        self.train = train_command
        self.test = test_command
        self.scorer = scorer
        self.env_variables = env_variables
        self.config = config
        self.config_path = config_path


class ConfigProcEvaluator(ProcEvaluator):
    """
    Template runner builds an external command from hyperparameters.
    """

    def template_vars(self, cmd, new_config_path):
        env_vars = self.context.env_variables.copy()
        env_vars.update(self.meta_params)
        env_vars['TRIAL'] = self.trial_id
        env_vars['CONFIG'] = new_config_path
        return VAR_RX.sub(replace(env_vars), cmd)

    def template_config(self):
        new_config_path = "{}.{}".format(self.context.config_path,
                                         self.trial_id)
        with open(new_config_path, 'w') as out:
            new_config = self.context.config.template(self.hp_params)
            out.write(self.template_vars(new_config, new_config_path))

        return new_config_path

    def evaluate(self, allowed_time):
        new_config_path = self.template_config()
        train_command = self.template_vars(self.context.train, new_config_path)
        if not self.has_test():
            # Everything is done in the train script
            return self.execute(train_command, "Train/Test",
                                self.context.scorer)

        # Train then Test
        self.execute(train_command, "Train")
        test_command = self.template_vars(self.context.test, new_config_path)
        return self.execute(test_command, "Test", self.context.scorer)

    def has_test(self):
        return self.context.test is not None
