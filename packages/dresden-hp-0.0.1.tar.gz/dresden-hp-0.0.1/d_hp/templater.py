class Templater(object):
    def __init__(self, template):
        self.temp = template

    def template(self, params):
        return self.temp.format(**params)
