from __future__ import absolute_import
import logging
import sys
from threading import Thread
from queue import Queue
from collections import namedtuple, deque

from .evaluator.templater import TemplateProcContext, TemplateProcEvaluator, \
        ConfigProcContext, ConfigProcEvaluator
from .parser import parse_string, parse_file
from .searcher import GridSearch, RandomSearch, \
            SuccessiveHalvingSearch, HyperbandSearch, HyperoptSearch
from six.moves import range


def process(in_q, out_q):
    while True:
        data = in_q.get()
        if data is None: break
        key, ev = data
        out_q.put((key, ev.evaluate(0)))


def search(searcher, context, evaluator, n_threads):
    # We spin up a number of threads and talk via queues
    q_in, q_out = Queue(), Queue()

    threads = []
    for t in range(n_threads):
        thread = Thread(target=process, args=[q_in, q_out])
        thread.daemon = True
        thread.start()
        threads.append(thread)

    def feed(f):
        for trial_id, hp, meta in f():
            key = (trial_id, hp, meta)
            r = evaluator(trial_id, hp, context, meta)
            q_in.put((key, r))

    feed(lambda: searcher.start())

    while not searcher.done():
        feed(lambda: searcher.finished(*q_out.get()))

    for t in threads:
        q_in.put(None)

    return searcher.results()


class GenSearcher(object):
    def run(self, env_vars):
        raise NotImplementedError()

    def pretty_run(self, env_vars):
        raise NotImplementedError()


class HPTemplateSearcher(GenSearcher):
    def __init__(self,
                 train,
                 test,
                 threads,
                 scorer,
                 searcher,
                 evaluator=TemplateProcEvaluator):
        train_template, hps, is_discrete = parse_string(train)
        self.train = train_template
        self.is_discrete = is_discrete
        self.hps = hps
        self.test = test
        self.threads = threads
        self.scorer = scorer
        self.evaluator = evaluator
        self.searcher = searcher

    def run(self, env_vars):
        ctx = TemplateProcContext(self.train, self.test, self.scorer, env_vars)
        searcher = self.searcher(self.hps, self.is_discrete)
        return search(searcher, ctx, self.evaluator, self.threads)

    def pretty_run(self, env_vars):
        for key, score in self.run(env_vars):
            yield self.train.template(key[1]), score


class HPConfigFileSearcher(GenSearcher):
    def __init__(self,
                 train,
                 test,
                 config,
                 threads,
                 scorer,
                 searcher,
                 evaluator=ConfigProcEvaluator):

        self.config_path = config
        config_template, hps, is_discrete = parse_file(config)
        self.config = config_template
        self.hps = hps
        self.train = train
        self.test = test
        self.threads = threads
        self.scorer = scorer
        self.evaluator = evaluator
        self.searcher = searcher
        self.is_discrete = is_discrete

    def run(self, env_vars):
        ctx = ConfigProcContext(self.train, self.test, self.scorer, env_vars,
                                self.config, self.config_path)

        searcher = self.searcher(self.hps, self.is_discrete)
        return search(searcher, ctx, self.evaluator, self.threads)

    def pretty_run(self, env_vars):
        for key, score in self.run(env_vars):
            yield "Config: {}.{}".format(self.config_path, key[0]), score
