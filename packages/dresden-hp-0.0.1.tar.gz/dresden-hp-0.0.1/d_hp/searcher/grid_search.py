from __future__ import absolute_import
from sklearn.model_selection import ParameterGrid

from .base import SimpleSearcher
from .utils import top_k


class GridSearch(SimpleSearcher):
    def __init__(self, parameters, lower_is_better, topK):
        self.sampler = ParameterGrid(parameters)
        self.lower_is_better = lower_is_better
        self.top_k = topK

    def start(self):
        self.scores = []
        for i, hp in enumerate(self.sampler):
            yield i, hp, {}

        self.trials = i + 1
