from __future__ import absolute_import
import logging
import six
import numpy as np
from threading import Thread
from queue import Queue

from hyperopt import fmin, tpe, hp, rand
import hyperopt.pyll.stochastic

from .base import SimpleSearcher
from .utils import top_k


class HyperoptSearch(SimpleSearcher):
    def __init__(self, trials, parameters, lower_is_better, top_k):
        self.trials = trials
        self.parameters = parameters
        self.parameters_hp = {
            k: self.convert_scip_hp(k, v)
            for (k, v) in six.iteritems(self.parameters)
        }
        self.lower_is_better = lower_is_better
        self.top_k = top_k
        self.q_int = Queue()
        self.q_out = Queue()
        self.cur_trial_num = 0
        self.hyperopt_done = False
        self.is_done = False
        self.current_hp_set = {}

    def convert_scip_hp(self, label, dist_s):
        name = dist_s.dist.name
        ans = []
        lower, upper = dist_s.args
        if name == 'uniform' or name == 'randint':
            ### Note: randint is also implemented using a
            ###       hp.uniform value (converted back to int eventually)

            ans = hp.uniform(label, lower, upper)
        else:
            raise TypeError(
                'Only support \'uniform\' or \'randint\' distributions.')
        return ans

    def transform_sampled_params(self, work):
        for k, v in six.iteritems(self.parameters):
            name = v.dist.name

            #### Randint is implemented as hp.uniform
            if name is 'randint':
                original_value = work[k]
                work[k] = int(original_value)

        return work

    def hyperopt_run(self, work):
        work = self.transform_sampled_params(work)
        self.q_int.put(work)
        ((index, q_out_val, meta), score) = self.q_out.get()
        if not self.lower_is_better:
            score = -score

        return score

    def start(self):
        self.scores = []
        self.doneQ = Queue()

        # start hyperopt
        self.hyperopt_thread = Thread(
            target=fmin,
            kwargs={
                'fn': self.hyperopt_run,
                'space': self.parameters_hp,
                'algo': tpe.suggest,
                'max_evals': self.trials
            })
        self.hyperopt_thread.start()

        # get first value
        self.current_hp_set = self.q_int.get()
        yield self.cur_trial_num, self.current_hp_set, {}

    def finished(self, key, score):
        self.scores.append((key, score))
        self.q_out.put((key, score))
        self.cur_trial_num += 1

        if (self.cur_trial_num == (self.trials)) or (
                not self.hyperopt_thread.isAlive()):
            self.hyperopt_thread.join()
            self.is_done = True
        else:
            self.current_hp_set = self.q_int.get()
        yield self.cur_trial_num, self.current_hp_set, {}

    def done(self):
        return self.cur_trial_num == self.trials or self.is_done
