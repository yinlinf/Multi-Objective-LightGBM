from __future__ import absolute_import
from itertools import count
from math import log, ceil, floor
import six
import logging
from sklearn.model_selection import ParameterSampler
from .base import SimpleSearcher
from .utils import top_k


class SuccessiveHalvingSearch(SimpleSearcher):

    def __init__(self, num_hp_configs, num_iters, parameters, lower_is_better, \
                        top_k =1, trial_id=0, r=9, eta=3):
        if ceil(log(num_hp_configs, eta)) + 1 < num_iters:
            raise ValueError("number of iterations can not be greater \
                                    than number of hp configs.")

        self.lower_is_better = lower_is_better
        self.r = r
        self.eta = eta
        self.max_iter = num_iters
        self.iter = 0
        self.num_hp_configs = num_hp_configs
        self.sampler = ParameterSampler(parameters, self.num_hp_configs)
        self.top_k = top_k
        self.scores_iter = {}
        self.trial_id = count(trial_id)

    def start(self):
        self.scores = []
        trial_id_start = self.trial_id
        for i, hp in enumerate(self.sampler):
            if i == self.num_hp_configs:
                break
            yield next(trial_id_start), hp, {"R": self.r}

    def finished(self, key, score):
        def one_pass_succ_half_done():
            return len(self.scores_iter) == self.num_hp_configs

        ret = iter(())
        trial_id = key[0]
        self.scores_iter[trial_id] = (key, score)
        logging.debug("Best score till now (succ_halv): %s", \
                top_k(list(six.itervalues(self.scores_iter)), 1, \
                self.lower_is_better)[0])

        if one_pass_succ_half_done():
            self.iter += 1
            ret = self.next_iter_hp_configs()
        return ret

    def next_iter_hp_configs(self):
        self.num_hp_configs = int(floor(self.num_hp_configs / self.eta))
        results_list = list(six.itervalues(self.scores_iter))
        topK_results = top_k(results_list, self.num_hp_configs, \
                                self.lower_is_better)
        self.r *= self.eta
        logging.debug(
            "Succ halving: iter_num - %s, num_hp_configs - %s, resource : %s" %
            (self.iter, self.num_hp_configs, self.r))
        temp = []
        for (trial_id, hp, meta), _ in topK_results:
            meta["R"] = self.r
            temp.append((next(self.trial_id), hp, meta))
        if not self.done():
            self.scores_iter = {}

        sampler = iter(temp)
        return sampler

    def done(self):
        return self.iter >= self.max_iter

    def results(self):
        self.scores = list(six.itervalues(self.scores_iter))
        return super(SuccessiveHalvingSearch, self).results()
