from .base import SimpleSearcher


class FixedSearch(SimpleSearcher):
    def __init__(self, param_set, lower_is_better, topK):
        self.parameters = param_set
        self.lower_is_better = lower_is_better
        self.top_k = topK
        self.trials = len(self.parameters)

    def start(self):
        self.scores = []
        for i, hp in enumerate(self.parameters):
            yield i, hp, {}
