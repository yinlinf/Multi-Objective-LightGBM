from __future__ import absolute_import
import logging
from sklearn.model_selection import ParameterSampler
import logging

from .base import SimpleSearcher
from .utils import top_k


class RandomSearch(SimpleSearcher):

    def __init__(self, parameters, lower_is_better, top_k, seed, \
                        trials, R=81):
        self.trials = trials
        self.sampler = ParameterSampler(parameters, trials, random_state=seed)
        self.lower_is_better = lower_is_better
        self.top_k = top_k
        self.R = R
        self.best_model_score = None

    def start(self):
        self.scores = []
        for i, hp in enumerate(self.sampler):
            if i == self.trials:
                break

            yield i, hp, {"R": self.R}

    def finished(self, key, score):
        if len(self.scores) > 0:
            logging.debug("Best score till now : %s", top_k(self.scores, 1, \
                                self.lower_is_better)[0])
        return super(RandomSearch, self).finished(key, score)
