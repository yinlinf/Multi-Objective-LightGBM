from __future__ import absolute_import
import six
from math import log, ceil, floor
import logging
from sklearn.model_selection import ParameterSampler
from .base import SimpleSearcher
from .utils import top_k
from .succ_halving_search import SuccessiveHalvingSearch


class HyperbandSearch(SimpleSearcher):
    def __init__(self, parameters, lower_is_better, seed, top_k, R=81, eta=3):
        if eta == 1:
            raise ValueError("Eta can not be 1")

        if R < eta:
            raise ValueError("R can not be less than eta")

        self.eta = eta
        self.R = R
        self.max_iter = int(floor(log(R, eta))) + 1
        self.B = (self.max_iter) * self.R
        self.num_hp_configs = self.get_num_hp_configs()
        self.r = int(self.R * pow(self.eta, -self.max_iter + 1))
        self.results_list = []
        self.top_k = top_k
        self.parameters = parameters
        self.lower_is_better = lower_is_better
        self.best_model_score = None
        self.sampler = SuccessiveHalvingSearch(self.num_hp_configs, \
                            self.max_iter, self.parameters, \
                            self.lower_is_better, self.top_k,  0, \
                            self.r, self.eta)
        self.scores = []
        self.trial_id = 0
        self.seed = seed

    def get_num_hp_configs(self):
        num_configs = int(
            ceil((int((self.B / self.R / self.max_iter)) * pow(
                self.eta, self.max_iter - 1))))
        return num_configs

    def start(self):
        for i, hp, meta in self.sampler.start():
            if i == self.num_hp_configs:
                break

            yield i, hp, meta

    def finished(self, key, score):
        ret = self.sampler.finished(key, score)
        best_score = lambda score1, score2, lower_is_better: \
                        min(score1, score2) if lower_is_better else \
                        max(score1, score2)
        if self.best_model_score:
            self.best_model_score = best_score(score, self.best_model_score,
                                               self.lower_is_better)

        else:
            self.best_model_score = score

        logging.debug("Best score till now (hyperband) : %s",
                      self.best_model_score)
        if self.sampler.done():
            self.max_iter -= 1
            self.trial_id = next(self.sampler.trial_id)
            self.scores.extend(self.sampler.results())
            #_, self.best_model_score = top_k(self.scores, 1, \
            #                                    self.lower_is_better)[0]
            if self.max_iter == 0:
                return iter(())

            self.r = int(self.R * pow(self.eta, -self.max_iter + 1))
            self.num_hp_configs = self.get_num_hp_configs()
            self.sampler = SuccessiveHalvingSearch(self.num_hp_configs, \
                                self.max_iter, self.parameters, \
                                self.lower_is_better, self.top_k, \
                                self.trial_id, self.r, self.eta)
            ret = self.sampler.start()
            self.sampler.scores_iter = {}
        return ret

    def done(self):
        return self.max_iter <= 0

    def results(self):
        return super(HyperbandSearch, self).results()
