from .utils import top_k


class Searcher(object):
    def start(self):
        raise NotImplementedError()

    def done(self):
        raise NotImplementedError()

    def finished(self, trial_id, hp, score):
        raise NotImplementedError()

    def results(self):
        raise NotImplementedError()


class SimpleSearcher(Searcher):
    def finished(self, key, score):
        self.scores.append((key, score))
        return iter(())

    def done(self):
        return len(self.scores) == self.trials

    def results(self):
        return top_k(self.scores, self.top_k, self.lower_is_better)
