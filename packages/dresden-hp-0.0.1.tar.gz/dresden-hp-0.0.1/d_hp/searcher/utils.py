def top_k(raw_results, topK, lower_is_better):
    only_valid = [s for s in raw_results if s[1] is not None]
    results = sorted(only_valid, key=lambda x: x[1])
    if lower_is_better:
        return list(reversed(results[:topK]))

    return results[-topK:]
