#!/usr/bin/env python

from __future__ import absolute_import
from setuptools import setup

import d_hp

# Re-sync the requirements.txt when upgrading the package by running below mentioned command
# virtualenv venv
# source venv/bin/activate
# pip install .
# pip freeze | grep -v dresden-hp > requirements.txt
setup(
    name='dresden-hp',
    version=d_hp.__version__,
    description='Tools for hyperparameter search',
    url="https://github.etsycorp.com/Engineering/dresden",
    test_suite="tests",
    packages=['d_hp', 'd_hp/evaluator', 'd_hp/searcher'],
    scripts=["bin/param-search.py", "bin/splitter.py"],
    install_requires=[
        'numpy==1.16.5', 'scikit-learn==0.20.2', 'scipy==1.4.1',
        'hyperopt==0.1.1', 'six==1.14.0', 'pytest==4.6.5'
    ],
    author='Etsy')
