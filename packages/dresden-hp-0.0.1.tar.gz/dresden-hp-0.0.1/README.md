dresden-hp
===

Framework for implementing and running hyperparameter search. 

Installation
---

Easiest way to install it is clone the directory to your machine of choice and run
    
    bash install.sh

in the main directory.  This will install all the dresden packages and their dependencies.
You will either need to be in a virtualenv or use sudo to install.  Sudo is _not_ recommended.

Binaries
---

dresden-hp provides two binaries for use in hyperparameter search

    splitter.py - application for splitting raw datasets into train and test sets

    param-search.py - application for running commands with hyperparameters


param-search.py
---

param-search.py provides an easy way to quickly run hyper parameter search.  It operates
by parsing commands a config files for certain tokens (See `Templating` below) and 
replacing with different sampled parameters.

It provides a few modes:

    1. Run a single command which both trains and evaluates the hyperparameters
    2. Run separate train and test commands
    3. Separately template a config file and pass it into other commands.

Further more, it provides a number of parameters for choosing

    --score-regex - Prefix in stdout which contains the score.  Ex. `score: <score>`
    --trials - Number of random samples to run
    --threads - Number of concurrent threads to use
    --seed - Random seed to use.  Change if you wish for different results
    --log-file - Write all standard output to a log file.  By default will write to stdout


Templating
---

There are two classes of tags that param-search.py looks for:

    - meta-vars: These are tags that reference meta information about the run, such as 
                 the trial number or the path to a template config file.  These are 
                 specified using angle brackets: `<TRIAL>` or `<CONFIG>`.  Other algorithms
                 might add additional meta-vars as necessary for their functionality
                 (but not as of yet)

    - hyper-vars: These are the parameters that are actually searched over by the 
                  underlying algorithms.  They are detailed below

hyper-vars
---

Hyper-vars are defined using curly braces, `{}`.  They are enumerated below with examples!

    1. Discrete: Choose one from a set.  Items are separated by semicolons(;): {d:item 1;item 2;item 3; etc}
    
        param-search.py 'echo score: {d:1;2;3}' --trials 3

    2. Ranges: Choose from a range of items: `{r:START:STOP:STEP}`
        
        param-search.py 'echo score: {r:1:20:3}' --trials 5
        
    3. Powerset: Compute the powerset from a set of discrete items: {p:delimiter:item 1;item 2;item 3;etc}
        
        param-search.py 'python -c "print \"score:\", {p:*:-1;-2;-3;0;-1;2;3}"' --trials 20

    4. Optional: either include or don't include an item: {o:--l2 1e-7}

        param-search.py 'python -c "print \"score:\", {p:*:-1;-2;-3;0;-1;2;3} {o:/ -2}"' --trials 20

    5. Sampling: sample from a provided distribution and the given modents.  you can use any distribution
       listed in [Scipy](https://docs.scipy.org/doc/scipy/reference/stats.html). Format: {s:distribution:param 1:param 2:...}.  

        param-search.py 'python -c "print \"score:\", {s:beta:2.31:0.627} * {p:*:-1;-2;-3;0;-1;2;3} {o:/ -2}"' --trials 20

Modes
---

Single Command: param-search.py takes a single command for both templating and evaluation.  The above examples in hyper-vars
are single command functions

Config Files: param-search.py is usually most powerful when using file templating and executing them in Single Command Mode

    See `examples/config/run.sh` for a working example!

When running in `Config mode`, param-search.py will copy the create a new config file for each run to `/path/to/file.<TRIAL>`.  You can read those files to see which parameters were checked.  


