from __future__ import absolute_import
from mock import mock, Mock
import unittest
from d_common.test.readers import PairwiseDocReader, FlatDocReader, ListDocReader, HeadFilter


class TestReaders(unittest.TestCase):

    @mock.patch('d_common.utils.yieldLines')
    def test_pairwise_doc_reader(self, mock_yield_json):
        filename = 'test.dat'
        mock_yield_json.return_value = (y for y in [
            '{ "d1": ["a1_document"], "d2": ["a2_document"] }',
            '{ "d1": ["b1_document"], "d2": ["b2_document"] }'
        ])

        all_data = []
        for data in PairwiseDocReader().read(filename):
            all_data.append(data)

        self.assertListEqual(all_data, [[u'a2_document', u'a1_document'], [u'b2_document', u'b1_document']])

    @mock.patch('d_common.utils.yieldLines')
    def test_flat_doc_reader(self, mock_yield_json):
        filename = 'test.dat'
        mock_yield_json.return_value = (y for y in [
            '{ "group_field": 0, "data": "meow" }',
            '{ "group_field": 0, "data": "cat" }',
            '{ "group_field": 2, "data": "not a cat" }',
            '{ "group_field": 1, "data": "bark" }',
            '{ "group_field": 1, "data": "dog" }',
            '{ "group_field": 0, "data": "more cats" }',
            '{ "group_field": 1, "data": "bork" }'])

        all_data = []
        for data in FlatDocReader("group_field").read(filename):
            all_data.append(data)

        self.assertListEqual(all_data,
                             [[{u'data': u'meow', u'group_field': 0}, {u'data': u'cat', u'group_field': 0}],
                              [{u'data': u'not a cat', u'group_field': 2}],
                              [{u'data': u'bark', u'group_field': 1}, {u'data': u'dog', u'group_field': 1}],
                              [{u'data': u'more cats', u'group_field': 0}],
                              [{u'data': u'bork', u'group_field': 1}]]
                             )


class TestFilters(unittest.TestCase):

    def setUp(self):
        self.documents = [
            '{ "group_field": 0, "data": "meow" }',
            '{ "group_field": 0, "data": "cat" }',
            '{ "group_field": 2, "data": "not a cat" }',
            '{ "group_field": 1, "data": "bark" }',
            '{ "group_field": 1, "data": "dog" }',
            '{ "group_field": 0, "data": "more cats" }',
            '{ "group_field": 1, "data": "bork" }']

    @mock.patch('d_common.utils.yieldLines')
    def test_head_list_filter(self, mock_yield_json):
        mock_yield_json.return_value = (y for y in self.documents)
        head_reader = HeadFilter(ListDocReader(), 2)
        data = [doc for doc in head_reader.read("sample.dat")]
        self.assertListEqual(data, [{u'group_field': 0, u'data': u'meow'}, {u'group_field': 0, u'data': u'cat'}])

    @mock.patch('d_common.utils.yieldLines')
    def test_head_group_filter(self, mock_yield_json):
        mock_yield_json.return_value = (y for y in self.documents)
        head_reader = HeadFilter(FlatDocReader("group_field"), 2)
        data = [doc for doc in head_reader.read("sample.dat")]
        self.assertListEqual(data, [[{u'group_field': 0, u'data': u'meow'}, {u'group_field': 0, u'data': u'cat'}],
                                    [{u'group_field': 2, u'data': u'not a cat'}]])
