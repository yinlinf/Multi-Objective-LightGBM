#!/usr/bin/env python
from __future__ import absolute_import
import unittest

from d_common.time_utils import DateRange


class DateRangeGeneratorTest(unittest.TestCase):
    def setUp(self):
        pass

    def test_simple(self):
        # given
        start, end = '2018-07-28', '2018-08-02'

        # when
        actual = [d for d in DateRange("%Y-%m-%d").stream_dates(start, end)]

        # then
        expected = [
            '2018-07-28', '2018-07-29', '2018-07-30', '2018-07-31',
            '2018-08-01', '2018-08-02'
        ]
        self.assertEqual(actual, expected)


if __name__ == '__main__':
    logging.basicConfig(steam=sys.stderr)
    unittest.main()
