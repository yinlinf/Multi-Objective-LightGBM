#!/usr/bin/env python
from __future__ import absolute_import
import logging
import os
import sys
import shutil
import unittest
import subprocess

from d_common.packaging.repository import GcsRepository, Version, FilestoreRepository
from mock import mock, patch, Mock
from pytest import raises
from google.cloud.exceptions import GoogleCloudError


class GcsRepositoryTest(unittest.TestCase):
    def setUp(self):
        self.bucket = Mock()
        self.bucket.list_blobs = Mock()

    @mock.patch('google.cloud.storage.Client')
    def test_should_list_files(self, mock_client):
        mock_client.return_value.get_bucket.return_value = self.bucket
        # Compressed model
        version_one = Mock()
        version_one.name = 'some-model/some-model-1.13.tar.gz'
        # Uncompressed model
        version_two = 'some-model/some-model-1.14/'

        class Page(object):
            def __init__(self):
                self.prefixes = (version_two,)

            def __iter__(self):
                return iter([version_one])

        class GcsResponse(object):
            def __init__(self):
                self.pages = [Page()]

        self.bucket.list_blobs.return_value = GcsResponse()
        repo = GcsRepository('some_bucket', '/unit_tests')

        versions = repo.list('some-model')

        self.assertEqual(len(versions), 2)
        self.assertEqual(versions[0].name, 'some-model')
        self.assertEqual(versions[0].major, 1)
        self.assertEqual(versions[1].name, 'some-model')
        self.assertEqual(versions[1].major, 1)
        # Ordering of versions is not preserved
        self.assertTrue(versions[0].minor in (13, 14))
        self.assertTrue(versions[1].minor in (13, 14) and
                        versions[1].minor != versions[0].minor)

    @mock.patch('google.cloud.storage.Client')
    def test_should_ignore_files_not_matching_expected_pattern(
            self, mock_client):
        mock_client.return_value.get_bucket.return_value = self.bucket
        not_a_model_file = Mock()
        not_a_model_file.name = 'some-model/this-is-not-a-model-file'

        class Page(object):
            def __init__(self):
                self.prefixes = tuple()

            def __iter__(self):
                return iter([not_a_model_file])

        class GcsResponse(object):
            def __init__(self):
                self.pages = [Page()]

        self.bucket.list_blobs.return_value = GcsResponse()
        repo = GcsRepository('some_bucket', '/unit_tests')

        versions = repo.list('some-model')

        self.assertEqual(0, len(versions))

    @mock.patch('google.cloud.storage.Client')
    @patch.object(GcsRepository, 'list')
    @patch.object(GcsRepository, '_compress_file')
    def test_should_upload_a_file(self, mock_compress, mock_list, mock_client):
        mock_compress.return_value = 'some-model.tar.gz'
        mock_client.return_value.get_bucket.return_value = self.bucket
        self.bucket.blob = Mock()
        self.bucket.blob.return_value.upload_from_filename = Mock()
        repo = GcsRepository('some_bucket', '/unit_tests')
        mock_list.return_value = []

        repo.upload(Version('some-model', 1, 2), '/from/path', compress=True)

        self.bucket.blob.return_value.upload_from_filename.assert_called_with(
            'some-model.tar.gz')

    @mock.patch('google.cloud.storage.Client')
    @patch.object(GcsRepository, 'list')
    def test_should_not_upload_invalid_gcs_file(self, mock_list, mock_client):
        #given
        mock_client.return_value.get_bucket.return_value = self.bucket
        self.bucket.blob = Mock()
        self.bucket.blob.return_value.upload_from_filename = Mock()
        repo = GcsRepository('some_bucket', '/somePath//unit_tests/')
        mock_list.return_value = []

        #then
        self.assertRaises(OSError, repo.upload,
                          Version('someModel', 1, 2), '/from/path', True)

    @mock.patch('google.cloud.storage.Client')
    @patch.object(GcsRepository, 'list')
    @patch.object(GcsRepository, '_compress_file')
    def test_should_retry_five_times_to_upload(self, mock_compress, mock_list,
                                               mock_client):
        def fail_first_four_times(path):
            fail_first_four_times.retry_count += 1
            if fail_first_four_times.retry_count < 5:
                raise GoogleCloudError('error uploading')
            pass

        fail_first_four_times.retry_count = 0

        mock_compress.return_value = 'some-model.tar.gz'
        mock_client.return_value.get_bucket.return_value = self.bucket
        self.bucket.blob = Mock()
        self.bucket.blob.return_value.upload_from_filename = fail_first_four_times
        repo = GcsRepository('some_bucket', '/unit_tests')
        mock_list.return_value = []

        repo.upload(Version('some-model', 1, 2), '/from/path', compress=True)

    @mock.patch('google.cloud.storage.Client')
    @patch.object(GcsRepository, 'list')
    def test_should_raise_exception_if_file_version_already_exists(
            self, mock_list, mock_client):
        mock_client.return_value.get_bucket.return_value = self.bucket
        self.bucket.blob = Mock()
        self.bucket.blob.return_value.upload_from_filename = Mock()
        repo = GcsRepository('some_bucket', '/unit_tests')
        mock_list.return_value = [Version('some-model', 1, 2)]

        self.assertRaises(OSError, repo.upload,
                          Version('some-model', 1, 2), '/from/path', True)

    @mock.patch('subprocess.call')
    @mock.patch('google.cloud.storage.Client')
    @patch.object(GcsRepository, 'list')
    def test_should_upload_a_directory(self, mock_list, mock_client,
                                       mock_subprocess):
        mock_client.return_value.get_bucket.return_value = self.bucket
        mock_subprocess.return_value = 0
        repo = GcsRepository('some_bucket', '/unit_tests')
        mock_list.return_value = []

        repo.upload(Version('some-model', 1, 2), '/from/path', compress=False)

        mock_subprocess.assert_called_with([
            'gsutil', '-m', 'cp', '-r', '/from/path',
            'gs://some_bucket/unit_tests/some-model/some-model-1.2'])

    @mock.patch('google.cloud.storage.Client')
    @patch.object(GcsRepository, 'list')
    def test_should_not_upload_invalid_gcs_directory(self, mock_list,
                                                     mock_client):
        # given
        # self.path = '/some/invalid//path/'
        mock_client.return_value.get_bucket.return_value = self.bucket
        repo = GcsRepository('some_bucket', '/somePath//unit_tests/')
        mock_list.return_value = []

        # then
        self.assertRaises(OSError, repo.upload,
                          Version('someModel', 1, 2), '/from/path', False)

    @mock.patch('google.cloud.storage.Client')
    @patch.object(GcsRepository, 'list')
    def test_should_retry_five_times_to_upload_directory(self, mock_list,
                                                         mock_client):
        def fail_first_four_times(subprocess_command):
            fail_first_four_times.retry_count += 1
            if fail_first_four_times.retry_count < 5:
                return 1
            else:
                return 0

        fail_first_four_times.retry_count = 0

        mock_client.return_value.get_bucket.return_value = self.bucket
        subprocess.call = fail_first_four_times
        repo = GcsRepository('some_bucket', '/unit_tests')
        mock_list.return_value = []

        repo.upload(Version('some-model', 1, 2), '/from/path', compress=False)

    @mock.patch('google.cloud.storage.Client')
    @patch.object(GcsRepository, 'list')
    def test_should_raise_exception_if_directory_version_already_exists(
            self, mock_list, mock_client):
        mock_client.return_value.get_bucket.return_value = self.bucket
        repo = GcsRepository('some_bucket', '/unit_tests')
        mock_list.return_value = [Version('some-model', 1, 2)]

        self.assertRaises(OSError, repo.upload,
                          Version('some-model', 1, 2), '/from/path', False)


class FilestoreRepositoryTest(unittest.TestCase):
    def setUp(self):
        self.bucket = Mock()
        self.bucket.list_blobs = Mock()

    @mock.patch('google.cloud.storage.Client')
    def test_get_base_name(self, mock_client):
        repo = FilestoreRepository('some_bucket', '/unit_tests', '/filestore')
        #when
        base_name = repo.get_base_name(Version('modelA', 1, 2), suffix="")
        #then
        self.assertEqual(base_name, "modelA-1.2")

        #when
        base_name = repo.get_base_name(Version('modelB', 1, 12))
        #then
        self.assertEqual(base_name, "modelB-1.12.tar.gz")

    @mock.patch('google.cloud.storage.Client')
    @patch.object(GcsRepository, 'list')
    @patch.object(GcsRepository, '_compress_file')
    def test_should_upload_a_file(self, mock_compress, mock_list, mock_client):
        mock_compress.return_value = 'some-model.tar.gz'
        mock_client.return_value.get_bucket.return_value = self.bucket
        self.bucket.blob = Mock()
        self.bucket.blob.return_value.upload_from_filename = Mock()
        repo = FilestoreRepository('some_bucket', '/unit_tests', '/tmp')
        mock_list.return_value = []
        repo.copy_to_mounted_filestore_location = Mock()
        os.path.exists = Mock(return_value=True)
        repo.upload(Version('some-model', 1, 2), '/from/path', compress=True)

        # assert calls
        repo.copy_to_mounted_filestore_location.assert_called_once_with(
            '/from/path', '/tmp/unit_tests/some-model', 'some-model-1.2', False)
        self.bucket.blob.return_value.upload_from_filename.assert_called_with(
            'some-model.tar.gz')

    @mock.patch('subprocess.call')
    @mock.patch('google.cloud.storage.Client')
    @patch.object(GcsRepository, 'list')
    def test_should_upload_a_directory(self, mock_list, mock_client,
                                  mock_subprocess):
        mock_client.return_value.get_bucket.return_value = self.bucket
        mock_subprocess.return_value = 0
        repo = FilestoreRepository('some_bucket', '/unit_tests', '/tmp')
        mock_list.return_value = []
        repo.copy_to_mounted_filestore_location = Mock()
        os.path.exists = Mock(return_value=True)
        repo.upload(Version('some-model', 1, 2), '/from/path', compress=False)

        # assert calls
        repo.copy_to_mounted_filestore_location.assert_called_once_with(
            '/from/path', '/tmp/unit_tests/some-model', 'some-model-1.2', False)
        mock_subprocess.assert_called_with([
            'gsutil', '-m', 'cp', '-r', '/from/path',
            'gs://some_bucket/unit_tests/some-model/some-model-1.2'])

    @mock.patch('google.cloud.storage.Client')
    def test_copy_to_mounted_filestore_location(self, mock_client):
        mock_client.return_value.get_bucket.return_value = self.bucket
        self.bucket.blob = Mock()
        #----------------------------------------------------------------
        # versioned model exist on filestore
        repo = FilestoreRepository('some_bucket', '/unit_tests', '/tmp')
        os.path.exists = Mock(return_value=True)
        with raises(IOError):
            repo.copy_to_mounted_filestore_location(
                '/from/some-model-1.2', '/tmp/unit_tests/some-model',
                'some-model-1.2', compress=False)

        #----------------------------------------------------------------
        # uncompressed model does exist, move the model directly.
        os.path.exists = Mock()
        os.path.exists.side_effect = [False, True]
        shutil.move = Mock()
        os.makedirs = Mock()
        repo.copy_to_mounted_filestore_location('/from/some-model-1.2',
                                                '/tmp/unit_tests/some-model',
                                                'some-model-1.2',
                                                compress=False)

        #then
        shutil.move.assert_called_once_with\
            ('/from/some-model-1.2', '/tmp/unit_tests/some-model')

    @mock.patch('google.cloud.storage.Client')
    @patch.object(GcsRepository, '_compress_file')
    def test_copy_tarred_model_to_mounted_filestore_location(self,
                                                             mock_compress,
                                                             mock_client):
        mock_compress.return_value = 'some-model-1.2.tar.gz'
        mock_client.return_value.get_bucket.return_value = self.bucket
        self.bucket.blob = Mock()

        repo = FilestoreRepository('some_bucket', '/unit_tests', '/tmp')
        os.path.exists = Mock()
        os.path.exists.side_effect = [False, True]
        shutil.move = Mock()
        os.makedirs = Mock()
        repo.copy_to_mounted_filestore_location('/from/some-model-1.2',
                                                '/tmp/unit_tests/some-model',
                                                'some-model-1.2',
                                                compress=True)

        # then
        shutil.move.assert_called_once_with \
            ('some-model-1.2.tar.gz', '/tmp/unit_tests/some-model')


if __name__ == '__main__':
    logging.basicConfig(stream=sys.stderr)
    unittest.main()
