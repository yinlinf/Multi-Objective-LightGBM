from __future__ import absolute_import
import unittest

from d_common.graphite_utils import _post_metrics, post_metrics
from mock import mock, MagicMock, patch


class GraphiteUtilsTest(unittest.TestCase):
    @patch('d_common.graphite_utils.open')
    def test_post_graphite_sends(self, mock_open):
        # given
        mock_socket = MagicMock()

        # when
        _post_metrics(mock_socket, "stats_filename", "col1", "col2",
                      "namespace")

        # then
        mock_socket.sendall.assert_called_once()

    @patch('d_common.graphite_utils.open')
    @patch('d_common.graphite_utils.open_close_socket')
    @patch('d_common.graphite_utils.get_graphite_socket')
    def test_post_graphite_closes_socket(self, mock_get_graphite_socket, *_):
        # given
        mock_socket = MagicMock()
        mock_get_graphite_socket.return_value = mock_socket

        # when
        post_metrics("graphite_host", "graphite_port", "stats_filename", "col1",
                     "col2", "namespace")

        # then
        mock_socket.close.assert_called_once()

    @patch('d_common.graphite_utils.open')
    @patch('csv.DictReader')
    def test_post_graphite_message(self, mock_DictReader, mock_open):
        # given
        rows = [
            {
                "std": 1,
                "mean": 2,
                "timestamp": 3
            },
            {
                "std": 4,
                "mean": 5,
                "timestamp": 6
            },
            {
                "std": 7,
                "mean": 8,
                "timestamp": 9
            },
        ]
        mock_socket = MagicMock()
        mock_DictReader.return_value.__iter__ = MagicMock(
            return_value=iter(rows))

        # when
        _post_metrics(mock_socket, "stats_filename", "timestamp",
                      ["std", "mean", "timestamp"], "namespace")

        # then
        expected_message_list = [
            "namespace.std 1 3",
            "namespace.mean 2 3",
            "namespace.timestamp 3 3",
            "namespace.std 4 6",
            "namespace.mean 5 6",
            "namespace.timestamp 6 6",
            "namespace.std 7 9",
            "namespace.mean 8 9",
            "namespace.timestamp 9 9",
        ]
        expected_message = "\n".join(expected_message_list) + "\n"
        mock_socket.sendall.assert_called_with(expected_message.encode())

