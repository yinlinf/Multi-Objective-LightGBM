#!/usr/bin/env python
from __future__ import absolute_import
import unittest
import logging

from d_common.test.ranker import partition_schema


class EvaluateRankerTest(unittest.TestCase):
    """
    TODO : Replace assertEqual by assertCountEqual in python3.
    """

    def setUp(self):

        self.doc_a = [{"tag-field": "cat", "action-field": ["click", "cart"]},
                 {"tag-field": "cat", "action-field": ["click"]},
                 {"tag-field": "cat", "action-field": ["purchase"]},
                 {"tag-field": "bear", "action-field": ["click"]},
                 {"tag-field": "dog", "action-field": []}
                 ]

    def test_tag_head(self):

        reader = partition_schema("head:field:tag-field", "action-field", ["click", "cart", "purchase"])
        tags = reader(self.doc_a)
        self.assertEqual(sorted(tags), sorted(["tag-field.cat"]))

        reader = partition_schema("head:field-subset:tag-field:dog", "action-field", ["click", "cart", "purchase"])
        tags = reader(self.doc_a)
        self.assertEqual(sorted(tags), sorted(["tag-field.other"]))

    def test_tag_distinct(self):

        reader = partition_schema("distinct:field:tag-field", "action-field", ["click", "cart", "purchase"])
        tags = reader(self.doc_a)
        self.assertEqual(sorted(tags), sorted(["tag-field.cat", "tag-field.bear", "tag-field.dog"]))

    def test_tag_restrict_by_action(self):

        reader = partition_schema("action-only:field:tag-field", "action-field", ["click", "cart", "purchase"])
        tags = reader(self.doc_a)
        self.assertEqual(sorted(tags), sorted(["tag-field.cat", "tag-field.bear"]))

        reader = partition_schema("action-only:field:tag-field", "action-field", ["purchase"])
        tags = reader(self.doc_a)
        self.assertEqual(sorted(tags), sorted(["tag-field.cat"]))

        reader = partition_schema("action-only:field:tag-field", "action-field", [])
        tags = reader(self.doc_a)
        self.assertEqual(sorted(tags), sorted([]))

    def test_tag_group_as_other(self):
        reader = partition_schema("action-only:field-subset:tag-field:cat",
                                  "action-field", ["click", "cart", "purchase"])

        tags = reader(self.doc_a)
        self.assertEqual(sorted(tags), sorted(["tag-field.cat","tag-field.other"]))

        reader = partition_schema("action-only:field-subset:tag-field:cat,dog",
                                  "action-field", ["click", "cart", "purchase"])
        tags = reader(self.doc_a)
        self.assertEqual(sorted(tags), sorted(["tag-field.cat", "tag-field.other"]))

    def test_null(self):
        reader = partition_schema("distinct:field:other-field",
                                  "action-field", ["click", "cart", "purchase"])
        tags = reader(self.doc_a)
        self.assertEqual(sorted(tags), sorted(["other-field.null"]))

if __name__ == '__main__':
    import sys
    logging.basicConfig(stream=sys.stderr)
    unittest.main()
