from __future__ import absolute_import
import unittest
import logging
from d_common.interfaces import Ranker, KNNSearcher, EmbeddingGenerator
from d_common.application.basics.ensemble_ann import EnsembleANN


class Model1(KNNSearcher):
    def decision_function(self, docs, **kwargs):
        return "model1"

class Model2(EmbeddingGenerator):
    def decision_function(self, docs, **kwargs):
        assert ("field_name" in kwargs), "field_name should be arg for Model2"
        return "model2"


class EnsembleTreeTests(unittest.TestCase):

    def test_execute_dag(self):
        schema = {
            "application": {
                "entrypoint": {},
                "opts": {
                    "ensemble_dag": {
                        "task_1": {
                            "model_name": "model_name1"
                        }
                    }
                }
            },
            "models": {
                "model_name1": Model1()
            }
        }


        ensemble_ann = EnsembleANN(schema["models"], schema["application"]["opts"], "logger")
        actual_result = ensemble_ann.execute_dag_ann([{"test_doc": "test_doc"}])
        expected_result = "model1"
        self.assertEqual(actual_result, expected_result)

        schema = {
            "application": {
                "entrypoint": {},
                "opts": {
                    "ensemble_dag": {
                        "task_1": {
                            "model_name": "model_name1"
                        },
                        "task_2": {
                            "model_name": "model_name2",
                            "upstream_dependency": "task_1"
                        }
                    }
                }
            },
            "models": {
                "model_name1": Model1(),
                "model_name2": Model2()
            }
        }

        context = [{"test_doc": "test_doc", "field_name": "fn"}]
        docs = context[0]["test_doc"]
        optional_args = context[0]
        optional_args.pop("test_doc", None)

        ensemble_ann = EnsembleANN(schema["models"], schema["application"]["opts"], "logger")
        actual_result = ensemble_ann.execute_dag_ann(docs, **optional_args)
        expected_result = "model2"
        self.assertEqual(actual_result, expected_result)

        optional_args.pop("field_name", None)
        with self.assertRaises(Exception) as err:
            ensemble_ann.execute_dag_ann(docs, **optional_args)

        actual_error_msg = "field_name should be arg for Model2"
        self.assertIn(actual_error_msg, str(err.exception)) 



if __name__ == '__main__':
    import sys
    logging.basicConfig(stream=sys.stderr)
    unittest.main()
