#!/usr/bin/env python
from __future__ import absolute_import
import unittest

from d_common.metrics import ndcg, mrr, precision, err, psndcg


class PsndcgTest(unittest.TestCase):
    def setUp(self):
        pass

    def test_psndcg_1(self):
        rel_scores = [1, 0, 0, 1, 0]
        prop_scores = [1, 0.8, 0.6, 0.4, 0.2]

        psndcg1 = round(psndcg(rel_scores, prop_scores=prop_scores), 4)
        assert (psndcg1 == 1.2733)

        rel_scores = [0, 0, 1]
        psndcg2 = round(psndcg(rel_scores, prop_scores=prop_scores), 4)
        assert (psndcg2 == 0.8333)

        rel_scores = [0, 0, 0, 0]
        psndcg3 = round(psndcg(rel_scores, prop_scores=prop_scores), 4)
        assert (psndcg3 == 0)

    def test_psndcg_2(self):

        rel_scores = [1, 0, 1, 0, 1]
        prop_scores = [1, 0.4, 0.6, 0.8, 0.2]
        psndcg1 = round(psndcg(rel_scores, prop_scores=prop_scores), 4)
        assert (psndcg1 == 1.7681)

        rel_scores = [0, 0, 1]
        psndcg2 = round(psndcg(rel_scores, prop_scores=prop_scores), 4)
        assert (psndcg2 == 0.8333)

        rel_scores = [0, 0, 0, 0]
        psndcg3 = round(psndcg(rel_scores, prop_scores=prop_scores), 4)
        assert (psndcg3 == 0)


if __name__ == '__main__':
    import logging
    import sys
    logging.basicConfig(stream=sys.stderr)
    unittest.main()
