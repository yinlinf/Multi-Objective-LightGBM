#!/usr/bin/env python
from __future__ import absolute_import
import json
import os
import sys
import unittest
import logging
import tempfile

from d_common.application.schema import Schema

from .utils import with_temp_file


class TestSchema(unittest.TestCase):
    @with_temp_file
    def test_simple_schema(self, fname):
        """
        tests simple loading of a schema
        """

        with open(fname, 'w') as out:
            out.write("""{
                "models": {"foo": {}},
                "application": {"entrypoint": {"type": "module", "path": ""}},
                "meta": ["one", "two", "three"]
            }""")

        schema = Schema(fname)
        self.assertEqual(schema.meta, ["one", "two", "three"])
        self.assertEqual(schema.app,
                         {"entrypoint": {
                             "type": "module",
                             "path": ""
                         }})
        self.assertEqual(schema.models, {"foo": {}})

    @with_temp_file
    def test_load_app_from_path(self, fname):

        dirname = os.path.dirname(__file__)
        # Write out schema
        with open(fname, 'w') as out:
            schema = {
                "models": {},
                "application": {
                    "entrypoint": {
                        "type": "file",
                        "path": '{}:TestApp'.format(
                            os.path.join(os.getcwd(), dirname, 'app.py'))
                    },
                    "opts": {
                        "foo": "bar"
                    }
                }
            }
            json.dump(schema, out)

        s = Schema(fname)
        app = s.load_application()

        self.assertEquals(app.models, {})
        self.assertEquals(app.opts, {"foo": "bar"})
        self.assertEquals(type(app).__name__, 'TestApp')


if __name__ == '__main__':
    logging.basicConfig(steam=sys.stderr)
    unittest.main()
