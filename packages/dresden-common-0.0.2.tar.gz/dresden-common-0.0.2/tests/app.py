from __future__ import absolute_import
from d_common.application.app import App


class TestApp(App):
    """
    Simply tests that it loads it correctly
    """

    def channels(self):
        return {"foo": "int"}

    def evaluate(self, context, **query):
        return True
