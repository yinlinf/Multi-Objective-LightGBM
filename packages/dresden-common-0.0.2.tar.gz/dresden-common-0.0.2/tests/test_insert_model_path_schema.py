#!/usr/bin/env python
from __future__ import absolute_import
import unittest
import logging
import sys

from mock import patch
from bin import insert_model_path_schema as up_schema
from d_common.packaging.repository import Version


class InsertModelPathSchemaTest(unittest.TestCase):
    def test_validate_schema_file_models_field_exists(self):
        schema = {"application": "application_fields"}

        with self.assertRaises(KeyError) as err:
            up_schema.validate_schema_file(schema)
        actual_error_message = "There is no configuration for `models`. " \
                               "Please add dictionary with `models` as key and `path`, " \
                               "`interface`, `packager` and `opts` as values"
        self.assertIn(actual_error_message, str(err.exception))

    def test_validate_models_configuration_required_key_exists(self):
        schema = {
            "models": {
                "vw": {
                    "packager": "exists",
                    "interface": "exists"
                }
            }
        }

        with self.assertRaises(KeyError) as err:
            up_schema.validate_schema_file(schema)
        actual_error_message = "`models` configuration does not have required fields: `packager, interface, path`"
        self.assertIn(actual_error_message, str(err.exception))

        schema = {"models": {"vw": {"path": "exists", "interface": "exists"}}}

        with self.assertRaises(KeyError) as err:
            up_schema.validate_schema_file(schema)
        actual_error_message = "`models` configuration does not have required fields: `packager, interface, path`"
        self.assertIn(actual_error_message, str(err.exception))

    def test_validate_model_configuration_gcs_path_type(self):

        schema = {
            "models": {
                "vw": {
                    "packager": "exists",
                    "path": {
                        "gcs": "not_dict"
                    },
                    "interface": "exists"
                }
            }
        }

        with self.assertRaises(TypeError) as err:
            up_schema.validate_schema_file(schema)
        # TODO: Fix me to check the full error message; due to python 2/3's str. being different
        # we cannot directly match at the moment.
        actual_error_message = "Type of gcs parameters are expected `dict` but passed"
        self.assertIn(actual_error_message, str(err.exception))

    def test_validate_path_required_keys_exists(self):

        schema = {
            "models": {
                "vw": {
                    "packager": "exists",
                    "path": {
                        "gcs": {
                            "bucket": "exists",
                            "model": "exists"
                        }
                    },
                    "interface": "exists"
                }
            }
        }

        with self.assertRaises(KeyError) as err:
            up_schema.validate_schema_file(schema)
        actual_error_message = "The GCS configuration does not include all required keys:"\
                               " required keys: `bucket, path, model`"
        self.assertIn(actual_error_message, str(err.exception))

        schema = {
            "models": {
                "vw": {
                    "packager": "exists",
                    "path": {
                        "gcs": {
                            "bucket": "exists",
                            "path": "exists"
                        }
                    },
                    "interface": "exists"
                }
            }
        }

        with self.assertRaises(KeyError) as err:
            up_schema.validate_schema_file(schema)
        actual_error_message = "The GCS configuration does not include all required keys:" \
                               " required keys: `bucket, path, model`"
        self.assertIn(actual_error_message, str(err.exception))

        schema = {
            "models": {
                "vw": {
                    "packager": "exists",
                    "path": {
                        "gcs": {
                            "path": "exists",
                            "model": "exists"
                        }
                    },
                    "interface": "exists"
                }
            }
        }

        with self.assertRaises(KeyError) as err:
            up_schema.validate_schema_file(schema)
        actual_error_message = "The GCS configuration does not include all required keys:" \
                               " required keys: `bucket, path, model`"
        self.assertIn(actual_error_message, str(err.exception))

    @patch('bin.insert_model_path_schema.get_latest_version')
    def test_replace_schema_path_with_full_model_path(self, mock_version):
        schema = {
            "models": {
                "vw": {
                    "packager": "exists",
                    "path": {
                        "gcs": {
                            "path": "path",
                            "model": "model_name",
                            "bucket": "bucket_name"
                        }
                    },
                    "interface": "exists"
                }
            }
        }
        mock_version.return_value = Version('test-model-name', '0', '1')
        updated_schema = up_schema.replace_schema_path_with_full_model_path(
            schema)

        updated_path = updated_schema['models']['vw']['path']
        expected_path = 'gs://bucket_name/path/model_name/test-model-name-0.1.tar.gz'

        self.assertEqual(updated_path, expected_path)

    def test_validate_model_configuration_path_type(self):

        schema = {
            "models": {
                "vw": {
                    "packager": "exists",
                    "path": "path",
                    "interface": "exists"
                }
            }
        }

        actual_schema = up_schema.replace_schema_path_with_full_model_path(
            schema)
        expected_schema = {
            "models": {
                "vw": {
                    "packager": "exists",
                    "path": "path",
                    "interface": "exists"
                }
            }
        }
        self.assertEqual(actual_schema, expected_schema)

    def test_create_full_path(self):
        actual_path = up_schema.create_full_path(
            prefix='gs://',
            suffix=".tar.gz",
            delimiter="/",
            directory_paths=("bucket/", "/path", "model", "version"))
        expected_path = "gs://bucket/path/model/version.tar.gz"

        self.assertEqual(actual_path, expected_path)

    def test_override_gcs_path_in_schema(self):
        schema = {
            "models": {
                "vw": {
                    "packager": "exists",
                    "path": "path",
                    "interface": "exists"
                }
            }
        }

        destinations_path = {
            'vw': 'gs://test-bucket/test-path/test-model-namespace'
        }

        actual_schema = up_schema.override_gcs_path_in_schema(
            schema, destinations_path)
        expected_schema = {
            "models": {
                "vw": {
                    "packager": "exists",
                    "path": {
                        'gcs': {
                            'bucket': 'test-bucket',
                            'model': 'test-model-namespace',
                            'path': 'test-path'
                        }
                    },
                    "interface": "exists"
                }
            }
        }

        self.assertEqual(actual_schema, expected_schema)

    def test_split_destination_path(self):
        expected_bucket_name = 'test-bucket'
        expected_directory_path = 'test-directory-path'
        expected_model_namespace = 'test-namespace'

        actual_bucket_name, actual_directory_path, actual_model_namespace = up_schema.split_destination_path(
            'gs://test-bucket/test-directory-path/test-namespace')

        self.assertEqual(actual_bucket_name, expected_bucket_name)
        self.assertEqual(actual_directory_path, expected_directory_path)
        self.assertEqual(actual_model_namespace, expected_model_namespace)


if __name__ == '__main__':
    logging.basicConfig(stream=sys.stderr)
    unittest.main()
