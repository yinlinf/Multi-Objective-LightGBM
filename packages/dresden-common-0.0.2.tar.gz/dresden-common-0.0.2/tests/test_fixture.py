#!/usr/bin/env python
from __future__ import print_function
from __future__ import absolute_import
import json
import os
import sys
import unittest
import logging
import tempfile
import d_common
import time

from mock import patch, MagicMock
from d_common.application.app import App
from d_common.application.fixture import Fixture, FixtureError, MIN_FIXTURE_SAMPLES

from .utils import with_temp_file
from six.moves import range


class TestSimpleApp(App):
    """
    Takes X and multiplies it by 2 + offset
    """

    def channels(self):
        return {"x": "int"}

    def evaluate(self, context, **query):
        return context['x'] * 2 + self.opts.get('offset', 0)


class TestFixtureClass:
    def __init__(self):
        pass

    @staticmethod
    def generate(in_file, data_sample):
        with open(in_file, 'w') as f:
            print(json.dumps(data_sample), file=f)


class TestFixture(unittest.TestCase):
    @with_temp_file
    @with_temp_file
    def test_fixture_error(self, in_file, fixture_file):
        """
        tests simple loading of a schema
        """

        with open(in_file, 'w') as f:
            for i in range(10):
                ctx = json.dumps({"x": i})
                print(ctx, file=f)

        # Write out the fixture with App
        app = TestSimpleApp({}, {}, logging)

        Fixture.generate(app, in_file, fixture_file)

        self.assert_(Fixture.test(app, fixture_file))

        # Test normal case
        with self.assertRaises(FixtureError):
            app = TestSimpleApp({}, {"offset": 1}, logging)
            Fixture.test(app, fixture_file)

    @with_temp_file
    @with_temp_file
    def test_fixture_number_test_samples(self, in_file, fixture_file):
        """
        tests simple loading of a schema
        """
        # given
        data_sample = [{"x": i} for i in range(10)]
        data_sample_iterator = iter(data_sample)

        # Write out the fixture with App
        app = TestSimpleApp({}, {}, logging)
        d_common.application.fixture.Fixture.generate = MagicMock(
            return_value=TestFixtureClass.generate(in_file, data_sample))
        d_common.application.fixture.yieldJson = MagicMock(
            iter(data_sample_iterator))

        # when
        Fixture.test(app, fixture_file, 1)

        # then
        d_common.application.fixture.yieldJson.assert_called_once()

    def test_check_time_limit_overtime_under_processed(self):
        """
        tests time/fixture processing limit for over time limit but too under processed
        """
        start = time.time()
        start -= 30  # 30 seconds have passed by
        with self.assertRaises(Exception):
            Fixture._check_time_limit(start, MIN_FIXTURE_SAMPLES, 0)

    def test_check_time_limit_overtime_enough_processed(self):
        """
        tests time/fixture processing limit for over time and enough processed
        """
        start = time.time()
        start -= 30
        min_proc_thresh = 10
        self.assertEquals(
            Fixture._check_time_limit(start, min_proc_thresh, 10), True)


if __name__ == '__main__':
    logging.basicConfig(steam=sys.stderr)
    unittest.main()
