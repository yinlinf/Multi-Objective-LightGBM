#!/usr/bin/env python
from __future__ import absolute_import
import logging
import sys
import unittest
import os
from d_common.packaging.packager import *
from d_common.packaging.repository import Version
from mock import mock, patch, Mock, mock_open


class PackagerTest(unittest.TestCase):
    @patch('d_common.packaging.packager.save_schema')
    @patch('d_common.packaging.packager.update_schema')
    @patch('d_common.packaging.packager.hash_models')
    @patch('d_common.packaging.packager.copy_schema')
    @patch('d_common.packaging.packager.create_output_directory')
    @patch('d_common.packaging.packager.load_repository')
    def test_should_package(self, mock_load_repository, mock_create_output_dir,
                            mock_copy_schema, mock_hash_models,
                            mock_update_schema, mock_save_schema):
        # A very basic test that at least makes sure the packager runs through at a high level. Note that we do
        # also test the packager via integration tests in the build
        args = TestArgs().with_fixture_input_path(None)
        mock_repository = Mock()
        mock_load_repository.return_value = mock_repository
        mock_repository.list.return_value = [Version(0, 0, 1)]

        package(args, should_log=False)

        mock_create_output_dir.assert_called()
        mock_copy_schema.assert_called()
        mock_hash_models.assert_called()
        mock_update_schema.assert_called()
        mock_save_schema.assert_called()

    @patch('d_common.packaging.packager.write_model_config')
    @patch('d_common.packaging.packager.save_schema')
    @patch('d_common.packaging.packager.update_schema')
    @patch('d_common.packaging.packager.hash_models')
    @patch('d_common.packaging.packager.copy_schema')
    @patch('d_common.packaging.packager.create_output_directory')
    @patch('d_common.packaging.packager.load_repository')
    @patch.dict('os.environ', {"ETSY_LIBRARIES": "buzzsaw==0.1.2,faiss==1.2.3"})
    def test_should_create_model_config_if_etsy_libraries_set(
            self, mock_load_repository, mock_create_output_dir,
            mock_copy_schema, mock_hash_models, mock_update_schema,
            mock_save_schema, mock_write_model_config):
        args = TestArgs()
        mock_repository = Mock()
        mock_load_repository.return_value = mock_repository
        mock_repository.list.return_value = [Version(0, 0, 1)]
        mock_create_output_dir.return_value = "output/path"

        package(args, should_log=False)

        mock_write_model_config.assert_called_with({
            'buzzsaw_version': '0.1.2',
            'faiss_version': '1.2.3'
        }, "output/path/model_runtime_config.json")

    @patch('d_common.packaging.packager.process_fixtures')
    @patch('d_common.packaging.packager.save_schema')
    @patch('d_common.packaging.packager.update_schema')
    @patch('d_common.packaging.packager.hash_models')
    @patch('d_common.packaging.packager.copy_schema')
    @patch('d_common.packaging.packager.create_output_directory')
    @patch('d_common.packaging.packager.load_repository')
    def test_should_process_fixtures_if_fixture_input_path_set(
            self, mock_load_repository, mock_create_output_dir,
            mock_copy_schema, mock_hash_models, mock_update_schema,
            mock_save_schema, mock_process_fixtures):
        args = TestArgs().with_fixture_input_path("fixture input path")
        mock_repository = Mock()
        mock_load_repository.return_value = mock_repository
        mock_repository.list.return_value = [Version(0, 0, 1)]
        mock_create_output_dir.return_value = "output/path"
        mock_save_schema.return_value = "schema"

        package(args, should_log=False)

        mock_process_fixtures.assert_called_with(
            "schema", args.fixture_input_path, args.raw_fixture_input_path)

    @patch('d_common.packaging.packager.save_schema')
    @patch('d_common.packaging.packager.update_schema')
    @patch('d_common.packaging.packager.hash_models')
    @patch('d_common.packaging.packager.copy_schema')
    @patch('d_common.packaging.packager.create_output_directory')
    @patch('d_common.packaging.packager.build_version')
    @patch('d_common.packaging.packager.load_repository')
    def test_should_copy_schema_with_metadata(
            self, mock_load_repository, mock_build_version,
            mock_create_output_dir, mock_copy_schema, mock_hash_models,
            mock_update_schema, mock_save_schema):
        args = TestArgs()
        mock_repository = Mock()
        mock_load_repository.return_value = mock_repository
        mock_version = Mock()
        mock_build_version.return_value = mock_version
        mock_schema = Mock()
        mock_copy_schema.return_value = mock_schema
        mock_hash = 'some_hash123'
        mock_hash_models.return_value = mock_hash

        package(args, should_log=False)

        mock_update_schema.assert_called_with(mock_schema, mock_version,
                                              mock_hash, args.comment)

    @patch('d_common.packaging.packager.create_output_directory')
    @patch('d_common.packaging.packager.save_schema')
    @patch('d_common.packaging.packager.update_schema')
    @patch('d_common.packaging.packager.hash_models')
    @patch('d_common.packaging.packager.load_repository')
    @patch('d_common.utils.class_loader')
    @patch('d_common.packaging.packager.copy_application')
    @patch('d_common.packaging.packager.prepare_schema_with_overrides')
    @patch('d_common.application.schema.Schema.validate_schema_file')
    @patch('d_common.packaging.packager.copy_models_from_gcs')
    @patch('d_common.application.schema.Schema.packagers')
    @patch(
        "builtins.open",
        new_callable=mock_open,
        read_data=
        '{"application":"app","models":{"foo":{"packager":"d_vw.interfaces:Packager","path":"somepath","interface":"test"},"bar":{"packager":"d_vw.interfaces:Packager","path":"somepath","interface":"test"}}}'
    )
    def test_ensemble_package(self, mock_open_file, mock_schema_packager,
                              mock_copy_model_from_gcs, mock_validate_schema,
                              mock_override, mock_copy_app, mock_class_load,
                              mock_load_repository, mock_hash_models,
                              mock_update_schema, mock_save_schema,
                              mock_create_dir):
        #given
        args = TestArgs()
        mock_repository = Mock()
        mock_load_repository.return_value = mock_repository
        mock_repository.list.return_value = [Version(0, 0, 1)]
        mock_create_dir.return_value = '/tmp/0-0.2'
        mock_schema_packager.return_value = [[
            'foo', mock_class_load, {
                "gcs": {
                    "bucket": "somebk",
                    "path": "somepath",
                    "model": "testmodel"
                }
            }
        ], ['bar', mock_class_load, 'somelocalpath']]

        #when
        package(args, should_log=False)

        #then
        mock_validate_schema.assert_called()
        mock_override.assert_called()
        mock_copy_model_from_gcs.assert_called()
        mock_hash_models.assert_called()
        mock_update_schema.assert_called()
        mock_save_schema.assert_called()


class TestArgs():
    name = 'package-name'
    version = 'next'
    tmpDir = '/tmp'
    fixture_input_path = None
    raw_fixture_input_path = None
    schema = 'schema'
    comment = 'comment'

    def with_fixture_input_path(self, fixture_input_path):
        self.fixture_input_path = fixture_input_path
        return self


if __name__ == '__main__':
    logging.basicConfig(stream=sys.stderr)
    unittest.main()
