#!/usr/bin/env python
from __future__ import absolute_import
import unittest

from d_common.metrics import ndcg, err, mrr, kendall, psndcg, grouped_auc


class AUCTest(unittest.TestCase):
    def setUp(self):
        pass

    def test_grouped_auc_1(self):
        rel_scores = [1, 0, 0, 1, 0, 0]

        auc1 = grouped_auc(rel_scores)
        assert (auc1 == 0.75)

        rel_scores = [0, 0, 1]
        auc2 = grouped_auc(rel_scores)
        assert (auc2 == 0.0)

        rel_scores = [0, 0, 0, 1, 0]
        auc3 = grouped_auc(rel_scores)
        assert (auc3 == 0.25)


if __name__ == '__main__':
    import logging
    import sys
    logging.basicConfig(stream=sys.stderr)
    unittest.main()
