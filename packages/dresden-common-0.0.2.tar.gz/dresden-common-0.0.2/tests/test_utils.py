from __future__ import absolute_import
import unittest

from d_common.utils import *
from mock import mock, Mock


class UtilsTest(unittest.TestCase):
    def setUp(self):
        self._os_path_isdir = os.path.isdir
        self._os_list_dir = os.listdir
        self._os_path_join = os.path.join
        self.file_list_in_dir = {
            'test_dir/': ['test_file_1', 'test_file_2', 'test_dir1/'],
            'test_dir/test_dir1/': ['test_file_3', 'test_file_4', 'test_dir2/'],
            'test_dir/test_dir1/test_dir2/': ['test_file_5']
        }
        os.path.isdir = self.mock_is_dir
        os.listdir = self.mock_list_dir
        os.path.join = self.mock_os_path_join

    @staticmethod
    def mock_os_path_join(path1, path2):
        return path1.rstrip('/') + '/' + path2

    @staticmethod
    def mock_is_dir(path):
        return True if path.endswith('/') else False

    def mock_list_dir(self, dir_name):
        return self.file_list_in_dir[dir_name]

    def tearDown(self):
        os.path.exists = self._os_path_isdir
        os.listdir = self._os_list_dir
        os.path.join = self._os_path_join

    @mock.patch('d_common.utils._close_file')
    @mock.patch('d_common.utils._open_file')
    def test_yield_json(self, mock_open_file, mock_close_file):
        filename = 'test.dat'
        mock_open_file.return_value = [
            '{ "field": "value" }', '{ "line-two": 5 }'
        ]

        all_data = []
        for data in yieldJson(filename):
            all_data.append(data)

        self.assertEqual(all_data, [{'field': 'value'}, {'line-two': 5}])
        mock_open_file.assert_called_with(filename)
        mock_close_file.assert_called()

    @mock.patch('importlib.import_module')
    def test_class_loader(self, mock_import_module):
        mod_path = "mod.to.Mock"
        path = mod_path + ":ClassName"
        mock_cls_obj = Mock()

        mock_import_module.return_value = Mock(ClassName=mock_cls_obj)
        cls_obj = class_loader(path)

        self.assertEqual(cls_obj, mock_cls_obj)
        mock_import_module.assert_called_with(mod_path)

    @mock.patch("imp.load_source")
    def test_file_loader_new_source(self, mock_load_source):
        mod_path = u"mod.to.Mock"
        path = mod_path + u":ClassName"
        name = hashlib.md5(mod_path.encode("utf-8")).hexdigest()

        with mock.patch.dict('sys.modules', {}):
            try:
                file_loader(path)
            except KeyError:
                pass
            mock_load_source.assert_called_with(name, mod_path)

    @mock.patch("imp.load_source")
    def test_file_loader_existing_source(self, mock_load_source):
        mod_path = u"mod.to.Mock"
        path = mod_path + u":ClassName"
        mock_cls_obj = Mock()
        mod = Mock(ClassName=mock_cls_obj)
        name = hashlib.md5(mod_path.encode("utf-8")).hexdigest()

        with mock.patch.dict('sys.modules', {name: mod}):
            cls_obj = file_loader(path)
            self.assertEqual(cls_obj, mock_cls_obj)

    def test_get_all_files_in_nested_directory_tree(self):
        # given
        test_dir = 'test_dir/'
        expected_files = [
            'test_dir/test_file_1', 'test_dir/test_file_2',
            'test_dir/test_dir1/test_file_3', 'test_dir/test_dir1/test_file_4',
            'test_dir/test_dir1/test_dir2/test_file_5'
        ]

        test_dir_1 = 'test_dir/test_dir1/'
        expected_files_1 = [
            'test_dir/test_dir1/test_file_3', 'test_dir/test_dir1/test_file_4',
            'test_dir/test_dir1/test_dir2/test_file_5'
        ]

        test_dir_2 = 'test_dir/test_dir1/test_dir2/'
        expected_files_2 = ['test_dir/test_dir1/test_dir2/test_file_5']

        # when
        actual_files = get_all_files_in_nested_directory_tree(test_dir)
        actual_files_1 = get_all_files_in_nested_directory_tree(test_dir_1)
        actual_files_2 = get_all_files_in_nested_directory_tree(test_dir_2)

        # then
        self.assertEqual(actual_files, expected_files)
        self.assertEqual(actual_files_1, expected_files_1)
        self.assertEqual(actual_files_2, expected_files_2)

    @mock.patch('d_common.utils.yieldLines')
    @mock.patch('d_common.utils.get_all_files_in_nested_directory_tree')
    def test_yieldLinesFromDirectory(
            self, mock_get_all_files_in_nested_directory_tree,
            mock_yield_lines):
        # given
        mock_yield_lines.return_value = ['test_file_output']
        mock_get_all_files_in_nested_directory_tree.return_value = [
            'test_file1'
        ]

        # when
        docs = list(yieldLinesFromDirectory('test_dir/'))

        # then
        mock_yield_lines.assert_called_once_with('test_file1', False)
        self.assertEqual(docs, ['test_file_output'])

    @mock.patch('d_common.utils.yieldLines')
    @mock.patch('d_common.utils.get_all_files_in_nested_directory_tree')
    def test_yieldLinesFromDir_with_delete(
            self, mock_get_all_files_in_nested_directory_tree,
            mock_yield_lines):
        #given
        mock_yield_lines.return_value = ['test_file_output']
        mock_get_all_files_in_nested_directory_tree.return_value = [
            'test_file', 'test_file', 'test_file'
        ]

        # when
        docs = list(yieldLinesFromDirectory('test_dir/', postdelete=True))

        #then
        mock_yield_lines.assert_called_with('test_file', True)
        self.assertEqual(mock_yield_lines.call_count, 3)
        self.assertEqual(
            docs, ['test_file_output', 'test_file_output', 'test_file_output'])


class TestArgs():
    mod_path = "mod.to.Mock"
    path = mod_path + ":ClassName"
    mock_cls_obj = Mock()
