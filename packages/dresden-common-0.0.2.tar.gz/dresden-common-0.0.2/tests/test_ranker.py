#!/usr/bin/env python
from __future__ import absolute_import
import sys
import unittest
import logging

from d_common.test.ranker import LabelScorer


class RankerTest(unittest.TestCase):
    def setUp(self):
        pass

    def test_ranker(self):
        s1 = LabelScorer('label', 'click')
        s2 = LabelScorer('label')
        doc1 = {'data': 'abc', 'label': 'click'}
        doc2 = {'data': 'abc', 'label': 'no_event'}
        doc3 = {'data': 'abc', 'label': 'purchase'}
        self.assertEqual(s1.score(doc1), 1)
        self.assertEqual(s1.score(doc2), 0)
        self.assertEqual(s1.score(doc3), 0)
        self.assertEqual(s2.score(doc1), 1)
        self.assertEqual(s2.score(doc2), 0)
        self.assertEqual(s2.score(doc3), 1)


if __name__ == '__main__':
    import sys
    logging.basicConfig(stream=sys.stderr)
    unittest.main()
