from __future__ import absolute_import
import unittest
import logging
from d_common.ensemble_list import EnsembleList, EnsembleValidator, EnsembleNode


class Model:
    def __init__(self, channels):
        self.channels_data = channels

    def channels(self):
        return self.channels_data

    def decision_function(self, docs):
        if "field_name" in docs[0]:
            return [1]
        else:
            return [0]


class EnsembleTreeTests(unittest.TestCase):
    def test_create_dag(self):

        ensemble_list = EnsembleList()
        ensemble_params = {
            "task_1": {
                "model_name": "model_name1",
                "model": "model1",
                "field_name": "field_name"
            },
            "task_3": {
                "model_name": "model_name3",
                "model": "model3",
                "field_name": "field_name",
                "upstream_dependency": "task_2"
            },
            "task_2": {
                "model_name": "model_name2",
                "model": "model2",
                "field_name": "field_name",
                "upstream_dependency": "task_1"
            }
        }

        dag = ensemble_list.create_dag(ensemble_params)
        actual_result = [node.task_name for node in dag]
        expected_result = ['task_1', 'task_2', 'task_3']

        self.assertEquals(actual_result, expected_result)

    def test_create_ensemble_nodes(self):

        ensemble_list = EnsembleList()
        ensemble_params = {
            "task_1": {
                "model_name": "model_name1",
                "model": "model1",
                "field_name": "field_name"
            },
            "task_3": {
                "model_name": "model_name3",
                "model": "model3",
                "field_name": "field_name",
                "upstream_dependency": "task_2"
            },
            "task_2": {
                "model_name": "model_name2",
                "model": "model2",
                "field_name": "field_name",
                "upstream_dependency": "task_1"
            }
        }
        actual_node_list = ensemble_list._create_ensemble_nodes(ensemble_params)
        actual_task_sequence = [node.task_name for node in actual_node_list]
        expected_task_sequence = ["task_1", "task_2", "task_3"]

        self.assertEquals(actual_task_sequence, expected_task_sequence)

    def test_execute_dag(self):
        ensemble_list = EnsembleList()
        ensemble_params = {
            "task_1": {
                "model_name": "model_name1",
                "field_name": "field_name",
                "model": Model({
                    "key1": "value1"
                }),
            }
        }
        ensemble_list.create_dag(ensemble_params)

        actual_result = ensemble_list.execute_dag([{"test_doc": "test_doc"}])
        expected_result = [0]
        self.assertEqual(actual_result, expected_result)

        ensemble_list = EnsembleList()
        ensemble_params = {
            "task_1": {
                "model_name": "model_name1",
                "field_name": "field_name",
                "model": Model({
                    "key1": "value1"
                }),
            },
            "task_2": {
                "model_name": "model_name2",
                "field_name": "field_name",
                "model": Model({
                    "key2": "value2"
                }),
                "upstream_dependency": "task_1"
            }
        }
        ensemble_list.create_dag(ensemble_params)

        actual_result = ensemble_list.execute_dag([{"test_doc": "test_doc"}])
        expected_result = [1]
        self.assertEqual(actual_result, expected_result)

    def test_execute_dag_for_returning_scores_for_all_models(self):
        ensemble_list = EnsembleList()
        ensemble_params = {
            "task_1": {
                "model_name": "model_name1",
                "field_name": "field_name",
                "return_score": True,
                "model": Model({
                    "key1": "value1"
                }),
            },
            "task_2": {
                "model_name": "model_name2",
                "field_name": "field_name",
                "model": Model({
                    "key2": "value2"
                }),
                "upstream_dependency": "task_1"
            },
            "task_3": {
                "model_name": "model_name3",
                "field_name": "field_name",
                "model": Model({
                    "key3": "value3"
                }),
                "return_score": True,
                "upstream_dependency": "task_2"
            }
        }
        ensemble_list.create_dag(ensemble_params)

        actual_result = ensemble_list.execute_dag([{"test_doc": "test_doc"}])
        expected_result = {'model_name3': [1], 'model_name1': [0]}
        self.assertEqual(actual_result, expected_result)

    def test_ordered_list(self):
        ensemble_list = EnsembleList()
        node1 = EnsembleNode(
            model='model2',
            model_name='model_name2',
            task_name="task-2",
            upstream_dependency="task-1")
        node2 = EnsembleNode(
            model='model1', model_name='model_name1', task_name="task-1")
        node3 = EnsembleNode(
            model='model3',
            model_name='model_name3',
            task_name="task-3",
            upstream_dependency="task-2")
        ensemble_nodes = [node1, node2, node3]

        actual_result = [
            node.task_name
            for node in ensemble_list._ordered_list(ensemble_nodes)
        ]
        expected_result = ["task-1", "task-2", "task-3"]

        self.assertEqual(actual_result, expected_result)

        ensemble_list = EnsembleList()
        node1 = EnsembleNode(
            model='model2',
            model_name='model_name2',
            task_name="task-2",
            upstream_dependency="task-1")
        node2 = EnsembleNode(
            model='model1',
            model_name='model_name1',
            task_name="task-1",
            upstream_dependency="task-2")
        node3 = EnsembleNode(
            model='model3',
            model_name='model_name3',
            task_name="task-3",
            upstream_dependency="task-2")
        ensemble_nodes = [node1, node2, node3]

        with self.assertRaises(ValueError):
            ensemble_list._ordered_list(ensemble_nodes)

        ensemble_list = EnsembleList()
        node1 = EnsembleNode(
            model='model2',
            model_name='model_name2',
            task_name="task-2",
            upstream_dependency="task-1")
        node2 = EnsembleNode(
            model='model1', model_name='model_name1', task_name="task-1")
        node3 = EnsembleNode(
            model='model3',
            model_name='model_name3',
            task_name="task-3",
            upstream_dependency="task-4")
        ensemble_nodes = [node1, node2, node3]

        with self.assertRaises(ValueError):
            ensemble_list._ordered_list(ensemble_nodes)

    def test_create_ensemble_nodes_map(self):
        ensemble_list = EnsembleList()
        node1 = EnsembleNode(
            model='model2',
            model_name='model_name2',
            task_name="task-2",
            upstream_dependency="task-1")
        node2 = EnsembleNode(
            model='model1', model_name='model_name1', task_name="task-1")
        ensemble_nodes = [node1, node2]

        actual_result = ensemble_list._create_ensemble_nodes_map(ensemble_nodes)
        expected_result = {"root": node2, "task-1": node1}

        self.assertEqual(actual_result, expected_result)

    def test_get_channels(self):
        ensemble_list = EnsembleList()
        ensemble_params = {
            "task_1": {
                "model_name": "model_name1",
                "field_name": "field_name",
                "model": Model({
                    "features": {
                        "key1": "value1"
                    }
                }),
            },
            "task_2": {
                "model_name": "model_name2",
                "field_name": "field_name",
                "model": Model({
                    "features": {
                        "key2": "value2",
                        "field_name": "test"
                    }
                }),
                "upstream_dependency": "task_1"
            }
        }
        ensemble_list.create_dag(ensemble_params)
        actual_result = ensemble_list.get_channels()
        expected_result = {'features': {"key1": "value1", "key2": "value2"}}
        self.assertEqual(actual_result, expected_result)


class EnsembleValidatorTests(unittest.TestCase):
    def test_validate_ensemble_dag_is_linear(self):

        ensemble_list = EnsembleList()
        ensemble_params = {
            "task_1": {
                "model_name": "model_name1",
                "model": "model1",
                "field_name": "field_name"
            },
            "task_3": {
                "model_name": "model_name3",
                "model": "model3",
                "field_name": "field_name",
                "upstream_dependency": "task_1"
            },
            "task_2": {
                "model_name": "model_name2",
                "model": "model2",
                "field_name": "field_name",
                "upstream_dependency": "task_1"
            }
        }
        with self.assertRaises(ValueError):
            ensemble_list.create_dag(ensemble_params)

    def test_validate_ensemble_params(self):
        ensemble_validator = EnsembleValidator()
        ensemble_params = [
            {
                "model_name": "model_name1",
                "model": "model1",
                "field_name": "field_name"
            },
        ]
        with self.assertRaises(TypeError):
            ensemble_validator.validate_ensemble_params(ensemble_params)

        ensemble_params = {
            1: {
                "model_name": "model_name1",
                "model": "model1",
                "field_name": "field_name"
            },
        }
        with self.assertRaises(TypeError):
            ensemble_validator.validate_ensemble_params(ensemble_params)

        ensemble_params = {
            "task_1": {
                "model_name": "model_name1",
                "field_name": "field_name"
            },
        }
        with self.assertRaises(KeyError):
            ensemble_validator.validate_ensemble_params(ensemble_params)


if __name__ == '__main__':
    import sys
    logging.basicConfig(stream=sys.stderr)
    unittest.main()
