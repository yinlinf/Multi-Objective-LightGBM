from __future__ import absolute_import
from tempfile import NamedTemporaryFile, mkdtemp
from functools import wraps


def with_temp_file(f):
    @wraps(f)
    def _f(*args, **kwargs):
        ntf = NamedTemporaryFile()
        nargs = args + (ntf.name, )
        try:
            return f(*nargs, **kwargs)
        finally:
            ntf.close()

    return _f


def with_temp_dir(f):
    @wraps(f)
    def _f(*args, **kwargs):
        dn = mkdtemp()
        nargs = args + (dn, )
        try:
            return f(*nargs, **kwargs)
        finally:
            shutil.rmtree(dn)

    return _f
