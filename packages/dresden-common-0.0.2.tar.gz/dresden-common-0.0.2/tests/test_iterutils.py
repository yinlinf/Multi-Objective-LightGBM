#!/usr/bin/env python
from __future__ import absolute_import
import logging
import sys
import unittest

from d_common.iterutils import *
from mock import mock, patch, Mock


class IterUtilsTest(unittest.TestCase):
    def test_unique(self):
        it = [1, 2, 2, 4, 4]

        unique_gen = unique(it)
        unique_set = [i for i in unique_gen]

        self.assertEqual(unique_set, [1, 2, 4])

    # test `unique` with parity function
    # resulting set from unique() are the elements whose uniqueness is determined by the key
    def test_unique_func(self):
        it = [1, 2, 3, 4, 6]
        parity = lambda x: (x % 2)

        unique_gen_par = unique(it, parity)
        unique_set_par = [i for i in unique_gen_par]

        self.assertEqual(unique_set_par, [1, 2])

    def test_group_with(self):
        it = [1, 2, 3, 4, 6]
        parity = lambda x: (x % 2)

        groups = group_with(it, parity)

        self.assertEqual(len(list(groups.keys())), 2)
        self.assertEqual(sorted(groups[0]), [2, 4, 6])
        self.assertEqual(sorted(groups[1]), [1, 3])

    def test_batch(self):
        it = [1, 2, 3, 4, 6]
        slice_size = 2

        batch_gen = batch(it, slice_size)
        batch_list = [group for group in batch_gen]

        self.assertEqual(batch_list, [[1, 2], [3, 4], [6]])

    def test_batch_with(self):
        it = [(0,3), (0,2), (0,55), (1,23), (3,5), (3,98)]
        batch_gen = batch_with(it, lambda tup:tup[0])
        batch_list = [group for group in batch_gen]
        self.assertEqual(batch_list, [[(0,3),(0,2), (0,55)],
                                      [(1,23)],
                                      [(3,5),(3,98)]])

    def test_sliding(self):
        it = [1, 2, 3, 4, 6]

        sliding_gen = sliding(it, 3)
        slide_list = [window for window in sliding_gen]

        self.assertEqual(slide_list, [[1, 2, 3], [2, 3, 4], [3, 4, 6]])

    def test_unpeek(self):
        it = [1, 2, 3, 4, 6]

        unpeek_gen = unpeek(it, "array")

        self.assertEqual(next(unpeek_gen), "array")

        unpeek_list = [i for i in unpeek_gen]

        self.assertEqual(unpeek_list, [1, 2, 3, 4, 6])

    def test_peek(self):
        it = [1, 2, 3, 4, 6]

        item, gen = peek(it, None)

        self.assertEqual(item, 1)

        peek_list = [i for i in gen]

        self.assertEqual(peek_list, [1, 2, 3, 4, 6])

    def test_peek_empty_it(self):
        it = []

        sent, gen = peek(it, None)

        self.assertEqual(sent, None)

    def test_has_next(self):
        it2 = [4, 5, 2]
        small_it = [1]

        next_exists, it2 = has_next(small_it)

        self.assertEqual(next_exists, True)

        next(it2)
        next_exists, _ = has_next(it2)

        self.assertEqual(next_exists, False)

    def test_ibatch(self):
        it = [1, 2, 3, 4, 6]
        slice_size = 2

        ibatch_gen = ibatch(it, slice_size)
        ibatch_list = [[i for i in gen] for gen in ibatch_gen]

        self.assertEqual(ibatch_list, [[1, 2], [3, 4], [6]])

    def test_round_robin(self):
        it = [1, 2, 3, 4, 6]
        it2 = [4, 5, 2]

        gen = round_robin(iter(it), iter(it2))
        robin_list = [i for i in gen]

        self.assertEqual(robin_list, [1, 4, 2, 5, 3, 2, 4, 6])

    def test_unfold(self):
        it = [1, 2, 3, 4, 6]

        class counter:
            j = -1

        def data_f():
            counter.j += 1
            return it[counter.j]

        def check_f1(data):
            return True if data < 3 else False

        def check_f2(data):
            return True if data < 4 else False

        gen1 = unfold(data_f, check_f1)
        list_len1 = len([i for i in gen1])

        self.assertEqual(list_len1, 2)

        counter.j = -1
        gen2 = unfold(data_f, check_f2)
        list_len2 = len([i for i in gen2])

        self.assertEqual(list_len2, 3)

    def test_dsu_sort(self):
        it = [1, 2, 3, 4, 6]

        gen1 = dsu_sort(it, lambda x: 1.0 / (x * 1.0))
        list1 = [i for i in gen1]

        self.assertEqual(list1, [6, 4, 3, 2, 1])

        gen2 = dsu_sort(it, lambda x: 1.0 / (x * 1.0), reverse=True)
        list2 = [i for i in gen2]

        self.assertEqual(list2, [1, 2, 3, 4, 6])


if __name__ == '__main__':
    logging.basicConfig(stream=sys.stderr)
    unittest.main()
