#!/usr/bin/env python
from __future__ import print_function
from __future__ import absolute_import
import unittest
import sys
import logging

from mock import patch
from d_common.application.hooks import Hook


class TestSchema:
    def __init__(self, multiple_score_app=False):
        self.multiple_score_app = multiple_score_app
        self.post_fork_models = True

    def load_application(self):
        if not self.multiple_score_app:
            return Application(return_single_prediction_score=True)
        elif self.multiple_score_app:
            return Application(return_double_prediction_score=True)

    def get_fixture_path(self):
        return "test_path"


class Application:
    def __init__(self,
                 return_single_prediction_score=False,
                 return_double_prediction_score=False):
        self.return_single_prediction_score = return_single_prediction_score
        self.return_double_prediction_score = return_double_prediction_score

    def evaluate(self, features):
        if self.return_single_prediction_score:
            return [list(feature.values())[0] for feature in features]
        elif self.return_double_prediction_score:
            return {
                'model_name_one': [
                    list(feature.values())[0] for feature in features
                ],
                'model_name_two': [
                    list(feature.values())[0] for feature in features
                ],
            }
        else:
            return []


class Request:
    def __init__(self, batch_request=False, single_request=False):
        self.batch_request = batch_request
        self.single_request = single_request
        self.args = {'batch': batch_request}

    def get_data(self):
        return True

    def get_json(self):

        if self.single_request:
            return {"test_feature_name": 'test_prediction_score'}
        elif self.batch_request:
            return {
                111: {
                    "test_feature_name_1": 'test_prediction_score_1'
                },
                222: {
                    "test_feature_name_2": 'test_prediction_score_2'
                }
            }
        else:
            return {}


class TestHook(unittest.TestCase):
    @patch('d_common.application.hooks.Schema')
    def test_batch(self, mock_schema):

        # Testing batch request when single prediction is returned from a model
        mock_schema.return_value = TestSchema(multiple_score_app=False)
        hook = Hook('test_path')
        request = Request(batch_request=True)
        actual_response = hook.batch(request)
        expected_response = {
            111: 'test_prediction_score_1',
            222: 'test_prediction_score_2'
        }
        self.assertEqual(actual_response, expected_response)

        # Testing batch request when double prediction is returned from a model
        mock_schema.return_value = TestSchema(multiple_score_app=True)
        hook = Hook('test_path')
        request = Request(batch_request=True)
        actual_response = hook.batch(request)
        expected_response = {
            111: {
                'model_name_one': 'test_prediction_score_1',
                'model_name_two': 'test_prediction_score_1'
            },
            222: {
                'model_name_one': 'test_prediction_score_2',
                'model_name_two': 'test_prediction_score_2'
            }
        }

        self.assertEqual(actual_response, expected_response)

    @patch('d_common.application.hooks.Schema')
    def test_single(self, mock_schema):
        # Testing single request when single prediction is returned from a model
        mock_schema.return_value = TestSchema(multiple_score_app=False)
        hook = Hook('test_path')
        request = Request(single_request=True)
        actual_response = hook.__call__(request)
        expected_response = 'test_prediction_score'
        self.assertEqual(actual_response[1], expected_response)

        # Testing single request when double prediction is returned from a model
        mock_schema.return_value = TestSchema(multiple_score_app=True)
        hook = Hook('test_path')
        request = Request(single_request=True)
        actual_response = hook.__call__(request)
        expected_response = {
            'model_name_one': 'test_prediction_score',
            'model_name_two': 'test_prediction_score'
        }
        self.assertEqual(actual_response[1], expected_response)


if __name__ == '__main__':
    logging.basicConfig(steam=sys.stderr)
    unittest.main()
