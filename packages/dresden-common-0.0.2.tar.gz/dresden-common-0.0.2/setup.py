#!/usr/bin/env python
from __future__ import absolute_import

import os

from setuptools import setup, find_packages

import d_common

BASE = os.path.dirname(os.path.abspath(__file__))
TEST_DEPS = [
    'pytest<=4.6.5;python_version<"3"',
    'pytest>=4.6.5;python_version>="3"',
    'mock==3.0.5',
]

# Re-sync the requirements.txt when upgrading the package by running below mentioned command
# virtualenv venv
# source venv/bin/activate
# pip install .
# pip freeze | grep -v dresden-common > requirements.txt
setup(
    name='dresden-common',
    version=d_common.__version__,
    description='Common tooling for dresden repos',
    url="https://github.etsycorp.com/Engineering/dresden",
    test_suite="tests",
    packages=find_packages(BASE),
    scripts=[
        'bin/date-range.py', 'bin/dresden-package.py', 'bin/dresden-test.py',
        'bin/gcs-stream.sh', 'bin/hdfs-stream.py', 'bin/hdfs.py',
        'bin/post-graphite.py', 'bin/storage-fs-for-migration-only.sh',
        'bin/hdfs-stream-cached.sh', 'bin/get-latest-version.py',
        'bin/install_buzzsaw_wheel.sh', 'bin/install_wheel_from_gcs.sh',
        'bin/install_deb_from_gcs.sh', 'bin/insert_model_path_schema.py'
    ],
    install_requires=[
        'six==1.14.0',
        'numpy<=1.16.4;python_version<"3"',
        'numpy>=1.16.4;python_version>="3"',
        'scipy==1.4.1',
        'scikit-learn==0.20.2', 'pywebhdfs==0.4.1',
        'google-cloud-storage==1.26.0',
        'crcmod==1.7', 'datadog==0.16.0',
        'pyarrow==0.15.1'
    ],
    extras_require={"test": TEST_DEPS},
    tests_require=TEST_DEPS,
    author='Etsy')
