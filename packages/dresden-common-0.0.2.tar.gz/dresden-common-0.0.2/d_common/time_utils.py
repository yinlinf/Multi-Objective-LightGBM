from __future__ import print_function
from __future__ import absolute_import
import sys
import time
import datetime


class DateRange(object):
    def __init__(self, date_format="%Y-%m-%d"):
        self.date_format = date_format

    def stream_dates(self, start, end):
        """Yield dates between a start and end date

        >>> [d for d in DateRange().stream_dates('2018-07-28', '2018-08-02')]
        ['2018-07-28', '2018-07-29', '2018-07-30', '2018-07-31', '2018-08-01', '2018-08-02']
        """

        sDate = self._parse_date(start)

        if end.startswith(('-', '+')):
            sDate, eDate = self._adjust_days(sDate, end)
        else:
            eDate = self._parse_date(end)

        if sDate > eDate:
            sDate, eDate = eDate, sDate

        td = datetime.timedelta(days=1)
        dates = []
        if sDate <= eDate:
            while sDate < eDate:
                yield self._format_date(sDate)
                sDate += td

            yield self._format_date(eDate)

    def _parse_date(self, d):
        return datetime.datetime.strptime(d, self.date_format)

    def _format_date(self, d):
        return d.strftime(self.date_format)

    def _adjust_days(self, d, delta):
        amount = int(delta[1:])
        td = datetime.timedelta(days=amount)
        if delta[0] == "+":
            return d, d + td

        return d - td, d
