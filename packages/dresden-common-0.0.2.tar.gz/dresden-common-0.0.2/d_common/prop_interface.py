from __future__ import absolute_import
from d_common.interfaces import Regressor
import json
import six


def convertDocToKey(doc, keys):
    '''
      {
        "listingId" : 123456     _______|\  
        "queryPos"  : 3         |         \   (123456, 3, dress)   
        "query"     : "dress"   |_______  /  
         .                              |/
         .
      } 
      input:
        doc  - json formatted listing
        keys - [listingId, queryPos, query]
      output:
        (123456, 3, dress)
    '''
    return tuple([doc.get(k, "NA") for k in keys])
    

def load(path, target_key, **extra_flags):
    '''
      Sample Input: 
      [                                                      
        {query: "dress", target: "click", queryPos: 2, propScore: 0.4}  
        {query: "dress", target: "purchase", queryPos: 5, propScore: 0.7}  
      ] 

      Sample Output:
         {
           ("dress", "click", 2)    : 0.4
           ("dress", "purchase", 5) : 0.7
         }
      Args:
        path - contains propensity scores as sample input format
    '''
    if extra_flags is None:
        extra_flags = {}

    with open(path) as f:
        propScores = json.load(f)

    assert(len(propScores) > 0)
    ret = {}
    prop_key = list(six.iterkeys(propScores[0]))
    prop_key.remove(target_key)
    for propScore in propScores:
        t = convertDocToKey(propScore, prop_key)
        ret[tuple(t)] = propScore[target_key]

    return ret, prop_key, target_key



class PropRegressor(Regressor):
    
    def __init__(self, evaluator, prop_key, target_key):
        self.evaluator = evaluator    
        self.prop_key = prop_key
        self.target_key = target_key

    @classmethod
    def load(cls, path, target_key, **extra_flags):
        '''
           Arguments:
              path        - contains calculated propensity scores as json format
              extra_flags - dictionary containing `target_key` as key
        '''
        evaluator, prop_key, target_key = load(path, target_key)
        return cls(evaluator, prop_key, target_key)

    def predict(self, doc, **opts):
        assert isinstance(doc, dict)
        t = convertDocToKey(doc, self.prop_key)
        return self.evaluator.get(t, 0)
