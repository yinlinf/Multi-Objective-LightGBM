from __future__ import absolute_import
from itertools import count, islice, cycle
import threading
import logging
import multiprocessing
import subprocess

import d_common.storage as storage
from six.moves import zip


class GzipFO(object):
    lock = threading.Lock()

    def __init__(self, buf_size=4096 ** 2):
        self.buf_size = buf_size

    def _launch(self, flags, **kwargs):
        with self.lock:
            return subprocess.Popen(
                ['gzip'] + flags, bufsize=self.buf_size, **kwargs)

    def read(self, payload):
        raise NotImplementedError()

    def write(self, data):
        raise NotImplementedError()


class GzipWriter(GzipFO):
    def __init__(self, filename, comp_level=9, buf_size=4096 ** 2):
        super(GzipWriter, self).__init__(buf_size)
        self.filename = filename
        self.comp_level = comp_level
        self._start()

    def _start(self):
        self.f = open(self.filename, 'w')
        logging.debug("Launching external gzip...")
        self.proc = self._launch(
            ['-%s' % self.comp_level],
            stdin=subprocess.PIPE,
            stdout=self.f.fileno())
        logging.debug("gzip launched with %s", self.proc.pid)

    def __enter__(self):
        return self

    def __exit__(self, *args, **kwargs):
        self.proc.stdin.close()
        self.proc.wait()
        self.f.close()

    def write(self, data):
        self.proc.stdin.write(data)


class ForkedCompositeWriter(object):
    """
    Forks out N processes for multiproc writing, unioning them at the end
    """
    SENTINEL = ()

    def __init__(self,
                 filename,
                 serializer,
                 num_channels,
                 buf_size=100,
                 forks=2):
        self.filename = filename
        self.serializer = serializer
        self.num_channels = num_channels
        self.forks = forks
        self.buf_size = buf_size

    def add(self, doc):
        self._buffer.append(doc)
        if len(self._buffer) > self.buf_size:
            self.flush()

    def flush(self):
        if self._buffer:
            next(self._wit).send(self._buffer)

        self._buffer = []

    @staticmethod
    def _writer(inf, fn, sentinel, serializer, num_channels):
        writer = storage.CompositeSerialFileSystem(fn, serializer, num_channels)
        with writer as w:
            while True:
                data = inf.recv()
                if data == sentinel:
                    break

                for d in data:
                    w.add(d)

    @property
    def inames(self):
        for i in count(0):
            yield '%s.temp.%s' % (self.filename, i)

    def _create(self):
        for fn in islice(self.inames, self.forks):
            reader, writer = multiprocessing.Pipe()
            process = multiprocessing.Process(
                target=self._writer,
                args=[
                    reader, fn, self.SENTINEL, self.serializer,
                    self.num_channels
                ])
            yield fn, reader, writer, process

    def __enter__(self):
        self._writers = []
        self._readers = []
        self._procs = []
        self._fn = []
        for fn, r, w, p in self._create():
            self._fn.append(fn)
            self._readers.append(r)
            self._writers.append(w)
            self._procs.append(p)
            p.start()

        self._wit = cycle(self._writers)
        self._buffer = []

        return self

    def __exit__(self, exc_type, exc_val, exc_tb):

        if exc_type:
            # No cleanup
            return

        self.flush()

        for w, p in zip(self._writers, self._procs):
            w.send(self.SENTINEL)
            w.close()
            p.join()

        for r in self._readers:
            r.close()

        # Merge
        storage.CompositeSerialFileSystem.merge(self._fn, self.filename)

        # Purge
        for fn in self._fn:
            storage.CompositeSerialFileSystem.purge(fn)

        # Cleanup
        self._wit = self._writers = self._readers = self._fn = self._procs = None
