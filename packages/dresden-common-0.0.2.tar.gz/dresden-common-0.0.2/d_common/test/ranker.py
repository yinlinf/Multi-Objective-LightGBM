#!/usr/bin/env python3
from __future__ import absolute_import
import sys
import random
import six
from multiprocessing import cpu_count
import json

import numpy as np

from d_common.test.partitions import partition_schema
from d_common.test.readers import build_readers
from d_common.test.reporters import NoopReporter, SimpleCsvReporter, PercentileCsvReporter
from d_common.utils import class_loader
from d_common.metrics import ndcg, mrr, precision, err, psndcg, grouped_auc
from d_common.mt import ParPipeline
from d_common.logger import setupLogging, logArgs

from d_common.interfaces import Ranker
from .test import Test
from six.moves import zip


class RandomRanker(Ranker):
    """
    Ranker that generates a random ordering of the items.
    """

    def __init__(self, seed=2017):
        """
        :param seed: Seed to RNG
        """
        self.rs = np.random.RandomState(seed)

    def rank(self, docs, **kwargs):
        """ Copy the input and then randomly shuffle the copy in place.

        :param docs: Items (documents) to order
        :param kwargs:
        :return: Ranked items.
        """
        docs = docs[:]
        self.rs.shuffle(docs)
        return docs

    def decision_function(self, docs):
        """
        returns a random number for each passed document
        :param docs: Items (documents)
        :return: random number between 0,1 wrapped in a list.
        """
        return [random.uniform(0, 1) for doc in docs]


class FieldRanker(Ranker):
    """
    Ranker based on an accessible field in the input items.

    Common usage : x has field "original_position" denoting the ordering of the items
                   presented to the user. In this case the sorting returns the documents
                   to their original order.

    """

    def __init__(self, field, rank_descending):
        """

        :param field: The field used to rank the items. Items need __getitem__() method and
                      field must be a valid input.
        :param rank_descending: (String) Whether to sort in descending order, aka, reversed.
                                This is a string instead of a boolean because this is a user provided
                                value. It will be converted to a boolean here.
        """
        self.field = field
        self.rank_descending = rank_descending.lower() == "true"

    def rank(self, docs, **kwargs):
        """

        :param docs: Iterable of items (documents) to be ranked.
        :type docs: Iterable[A]
        :param kwargs:
        :return: New iterable of items ranked according to 'field'.
        """
        return sorted(
            docs, key=lambda x: x[self.field], reverse=self.rank_descending)


class Scorer(object):
    """
    Base class for Scorers.
    """

    def __init__(self, field):
        self.field = field

    def score(self, doc):
        """
        :param doc:
        :type doc: Any
        :return: Numeric value
        """
        raise NotImplementedError()


def parse_scorers(arg_string):
    """
    Expected syntax

    field:starts_with:string
    field:contains:string
    field:value

    :param arg_string:
    :return:
    """

    # This is brittle and crazy
    scorer_data = arg_string.split(":")
    if (scorer_data[1] == "starts_with"):
        return LabelScorer(scorer_data[0], scorer_data[2])
    if (scorer_data[1] == "contains"):
        return ContainsScorer(scorer_data[0], scorer_data[2])
    if (scorer_data[1] == "value"):
        return NumberScorer(scorer_data[0])


def build_scorers(action_to_score, score_field, score_type, extra_scorers):
    """
    Gets scorers based on configuration arguments

    :param action_to_score: List of actions such as "click" or "purchase" to score
    :param score_field: Field of data to score on, as a string
    :param score_type: String either "label", "contain" or "number" to make a LabelScorer
                      ContainsScorer or NumberScorer if action_to_score is not defined
    :param extra_scorers: List of any additional scorers to add on which are
                          in string format parseable by parse_scorers()

    """
    # If we have defined actions to score - then the scorers are taken to be a list of tuples
    # of scores associated to those actions.
    # We can extend this to incorporate the additional metrics we care about.
    if action_to_score:
        if score_type == 'label':
            scorers = [(action, LabelScorer(score_field, action))
                       for action in action_to_score]
        elif score_type == 'contain':
            scorers = [(action, ContainsScorer(score_field, action))
                       for action in action_to_score]
        else:
            raise Exception("NumberScorer is not available when action to score is specified.")

    # If we don't have defined actions to score, look at score_type
    else:
        if score_type == 'label':
            scorers = [('label', LabelScorer(score_field))]
        elif score_type == 'number':
            scorers = [('number', NumberScorer(score_field))]
        else:
            raise Exception("To use ContainsScorer, action to score need to be provided.")

    # Add any additional scorers
    for scorer_args in (extra_scorers if extra_scorers is not None else []):
        scorers.append((scorer_args.replace(":", "_"),
                        parse_scorers(scorer_args)))

    return scorers


class ContainsScorer(Scorer):
    def __init__(self, field, element):
        """
        :param field: Field to use.
        :type field: Legal input to __getitem__ for docs (typically str).
        :param element:
        """
        super(ContainsScorer, self).__init__(field)
        self.element = element

    def score(self, doc):
        """
        Extracts doc[field] and
        Returns 1 if value contains element.

        :param doc:
        :type doc: dict[_,Str] (or something with __getitem__ method that returns container).
        :return:
        """
        return 1 if (self.element in doc[self.field]) else 0


class LabelScorer(Scorer):
    """
    Maps a document to 1,0 value based on the value in field.

    Examples :
        no_action_scorer = LabelScore("cats")
        doc_a = {"cats": "no_cats", "other_field": "stuff"}
        no_action_scorer.score(doc_a)
        > 0
        doc_b = {"cats" : "many_cats", "other_field": "more_stuff"}
        no_action_score.score(doc_b)
        > 1

        action_scorer = LabelScore("cats", "meow")
        doc_c = {"cats: "meowing", "other_field": "hi"}
        action_scorer.score(doc_c)
        > 1
        doc_d = {"cats": "sleeping", "other_field": "bark"}
        action_scorer.score(doc_d)
        > 0
    """

    def __init__(self, field, action=None):
        """
        :param field: Field to use.
        :type field: Legal input to __getitem__ for docs (typically str).
        :param action: String name of action or None.
        :type action: Str or None
        """
        super(LabelScorer, self).__init__(field)
        self.action = action

    def score(self, doc):
        """
        Extracts doc[field] and
        If action is None : Returns 0 if the string starts with "no_" else 1
        If action != None : Returns 1 if string starts with action else 0.

        :param doc:
        :type doc: dict[_,Str] (or something with __getitem__ method that returns strings).
        :return:
        """
        if self.action is None:
            return 0 if doc[self.field].startswith('no_') else 1
        else:
            return 1 if doc[self.field].startswith(self.action) else 0


class NumberScorer(Scorer):
    """
    Map document to number accessed by given field.
    """

    def score(self, doc):
        """
        Return numeric value from self.field in doc.
        :param doc:
        :return: Numeric value
        """
        return doc[self.field]


class RankTester(object):
    def __init__(self, rankers, metrics, scorers, partitions, threads,
                 reporter):
        """

        :param rankers:
        :param metrics:
        :param scorers: List of tuples of type (String, Document => Numeric) = (scorer_name, scorer_method)
        :param threads:
        :param reporter:
        """
        self.rankers = rankers
        self.metrics = metrics
        self.scorers = scorers
        self.partitions = partitions
        self.p_rpt = reporter
        self.threads = threads

    def _build_pipeline(self):
        """
        Constructs the computation pipeline given rankers, metrics, scorers, reporter.
        :return:
        """

        def process(data):
            """Define how each sample if processed.
            For each ranker, rank the documents
            For each definition of relevance/gain, assign gain to each document (redundancy here).
            For each ranking metric - apply it to the ranked docs + gains.

            :param data: Tuple of (tags, documents)
            :return: (tags, List of Dictionaries of metric_name-action_type -> value, set of metric names.)
                     (tags, List[Dict[String, Numeric]], Set[String])
            """

            documents = data
            scores = []
            tags = []
            metric_keys = set()
            for partition in self.partitions:
                for t in partition(documents):
                    tags.append(t)

            for ranker in self.rankers:
                ranked_docs = ranker.rank(documents)
                relevance_scores = []
                for action, scorer in self.scorers:
                    relevance_scores.append(
                        (action, [scorer.score(doc) for doc in ranked_docs]))

                metrics = {}
                for name, metric in six.iteritems(self.metrics):
                    metric.r_rank = ranked_docs
                    for action, s in relevance_scores:
                        if sum(s) > 0:
                            key = '{}-{}'.format(name, action)
                            metric_keys.add(key)
                            metrics[key] = metric(s)

                # return all values since tags count on preservation of indexes
                scores.append(metrics)

            return tags, scores, metric_keys

        return ParPipeline(threads=self.threads) >> process

    def rank(self, doc_iterator):
        """
        Ranks all documents in the input iterator
        :param doc_iterator:
        :return:
        """
        f = self._build_pipeline()
        agg_tags = []
        agg_scores = [[] for _ in six.moves.range(len(self.rankers))]
        agg_metrics = set()
        for i, (tags, scores, metrics) in enumerate(f(doc_iterator)):
            if i % 10000 == 0 and i > 0:
                self.p_rpt.report(agg_tags, agg_scores, agg_metrics, sys.stderr)

            agg_tags.append(tags)
            agg_metrics |= metrics
            for s, si in zip(agg_scores, scores):
                s.append(si)

        return agg_tags, agg_scores, agg_metrics


class MetricAt(object):
    """
    Selects ranking metric given - an integer K and the string name of a ranking metric that is defined
    for a given fixed number K of the top ranked items.
    """

    def __init__(self, metric, k=None):
        """

        :param metric: String name of the metric to use.
        :type metric: String
        :param k: Number of items to use.
        :type k: Int
        """

        assert metric in ('ndcg', 'precision', 'err')
        if metric == 'ndcg':
            self.m = ndcg
        elif metric == 'precision':
            self.m = precision
        else:
            self.m = err

        self.k = k

    def __call__(self, xs):
        """
        Evaluate metric with given list of items.
        :param xs:
        :return:
        """
        return self.m(xs, self.k)


class PropMetricAt(object):
    def __init__(self, metric, k=None, prop_scores=None, prop_score_field=None):
        assert metric in ('psndcg')
        self.m = psndcg
        self.k = k
        self.prop_scores = prop_scores
        self.prop_score_field = prop_score_field

    def __call__(self, xs):
        prop_scores = [d[self.prop_score_field] for d in self.r_rank]
        self.prop_scores = prop_scores
        return self.m(xs, self.k, prop_scores=self.prop_scores)


def build_metrics(args):
    """
    Generate dictionary of metrics from args.

    Note : By design this takes a single position K at which to calculate the metrics.
    :param args:
    :return: Dict[String, Function]
    """
    metrics = {}
    if 'mrr' in args.metric:
        metrics['mrr'] = mrr
    if 'grouped_auc' in args.metric:
        metrics['grouped_auc'] = grouped_auc
    if 'ndcg' in args.metric:
        metrics['ndcg'] = MetricAt('ndcg', args.k)
    if 'precision' in args.metric:
        metrics['precision'] = MetricAt('precision', args.k)
    if 'err' in args.metric:
        metrics['err'] = MetricAt('err', args.k)
    if 'psndcg' in args.metric:
        metrics['psndcg'] = PropMetricAt(
            'psndcg', args.k, prop_score_field=args.propScoreField)

    if not metrics:
        raise Exception("No valid metrics specified. Received : " +
                        str(args.metric))

    return metrics


def load_rankers(args):
    """
    Construct rankers from relevant arguments.
    :param args:
    :return:
    """

    ranker_names = []
    rankers = []

    for name, plugin, path, extras in args.rankers:
        ranker = class_loader(plugin).load(path, **json.loads(extras))
        ranker_names.append(name)
        rankers.append(ranker)

    if args.random_ranker:
        ranker_names.append('random')
        rankers.append(RandomRanker())

    for name, field_name, rank_descending in args.field_rankers:
        ranker_names.append(name)
        rankers.append(FieldRanker(field_name, rank_descending))

    return ranker_names, rankers


class RankerRunner(Test):
    """
    Main class of Test Ranker - contains main method and arg parsing.
    """
    name = "ranker"
    description = "Test a ranker on a held out test set"

    def arguments(self, parser):
        """
        Add arguments to arg parser - this is called by dresden-test

        :param parser:
        :return:
        """

        parser.add_argument("test", metavar="TEST_F", help="Test file")

        # Metrics, file formats, more
        parser.add_argument(
            "--metric",
            dest="metric",
            default=[],
            action="append",
            choices=('ndcg', 'mrr', 'precision', 'err', 'psndcg',
                     'grouped_auc'),
            help="Which metric to use")

        parser.add_argument(
            "--metric-at",
            dest="k",
            default=None,
            type=int,
            help="metric@K (for ndcg and precision)")

        # We need to figure out that data format at somepoint
        parser.add_argument(
            "--data-format",
            dest="data_format",
            default='pairwise',
            choices=('pairwise', 'flat', 'list'),
            help="Data format for test file.")

        parser.add_argument(
            "--group-field",
            dest="groupField",
            default='query_id',
            help="Field to group on if flat format")

        parser.add_argument(
            "--score-field",
            dest="score_field",
            default='target',
            help="Which field to score")

        parser.add_argument(
            "--action-field",
            dest="action_field",
            default="targets",
            help=
            "Field where the action_to_score (e.g. cart_add, purchase) are stored"
        )

        parser.add_argument(
            "--read-from-dir",
            dest="readFromDir",
            action="store_true",
            help="Read data from a directly in recursive manner.")

        # Document ID field
        parser.add_argument(
            "--score-type",
            dest="scoreType",
            default='label',
            choices=('label', 'contain', 'number'),
            help="Score type.  If Label, binarizes on prefix 'no_'")

        # Score per label
        parser.add_argument(
            "--score-action",
            dest="action_to_score",
            default=[],
            action='append',
            help=
            "Compute the score per action. Actions that do not have the prefix 'no_' are considered separate positive."
            + "If flag passed in, actions not specified are discarded.")

        parser.add_argument(
            "--prop-score-field",
            dest="propScoreField",
            default='prop_score',
            help="Which field to score for propensity evaluation")

        parser.add_argument(
            "--test-only",
            dest="testOnly",
            action="store_true",
            help="Only reports the final metric")

        parser.add_argument(
            "--percentiles",
            dest="percentiles",
            action="store_true",
            help="Computes percentiles of stats in place of mean,std-dev.")
        group = parser.add_mutually_exclusive_group()
        group.add_argument(
            "--sample",
            dest="sample",
            type=float,
            help=
            "Tests only K percent of doc sets if a float.  Samples N doc sets"
            "if N is an integer greater than 1")
        group.add_argument(
            "--first-k",
            dest="firstK",
            type=int,
            help="Takes the first K SERP for experimentation")

        # Define rankers
        parser.add_argument(
            "--ranker",
            dest='rankers',
            nargs=4,
            metavar=('NAME', 'MODULE', 'PATH', 'EXTRAS'),
            action="append",
            default=[],
            help="Rankers to use: name module:class <path> '{EXTRA}'")

        parser.add_argument(
            "--random-ranker",
            dest="random_ranker",
            action="store_true",
            help="Adds a random ranker for comparison")

        parser.add_argument(
            "--field-ranker",
            dest="field_rankers",
            nargs=3,
            metavar=('NAME', 'FIELD_NAME', 'RANK_DESCENDING'),
            action="append",
            default=[],
            help=
            """Field rankers to use. Takes a field name storing a value to rank by.
            This can store the original /reference ordering or any feature to rank on.
            Also indicate whether to rank in ascending or descending order
            RANK_DESCENDING can be (true, false). This is case insensitive. """)

        parser.add_argument(
            "--threads",
            type=int,
            default=cpu_count(),
            help="Number of threads to use")

        parser.add_argument(
            "--partition",
            dest="partition_schemas",
            default=["all"],
            action="append",
            help="""Takes """)

        parser.add_argument(
            "--extra-scorer",
            dest="extra_scorers",
            default=[],
            action="append",
            help="Add additional scorers.")

        parser.add_argument(
            "--destination",
            help="copy scores to a file",
            dest='destination', )

        return parser

    def main(self, args):
        """

        :param args:
        :return:
        """

        setupLogging()
        logArgs()

        scorers = build_scorers(args.action_to_score, args.score_field,
                                args.scoreType, args.extra_scorers)

        metrics = build_metrics(args)

        ranker_names, rankers = load_rankers(args)

        partitions = [
            partition_schema(s, args.action_field, args.action_to_score)
            for s in args.partition_schemas
        ]

        doc_reader = build_readers(args, partitions)

        stat_reporter = PercentileCsvReporter(
            ranker_names) if args.percentiles else SimpleCsvReporter(
                ranker_names)
        batch_reporter = NoopReporter(
            ranker_names) if args.testOnly else stat_reporter

        rank_tester = RankTester(
            rankers,
            metrics,
            scorers,
            partitions,
            args.threads,
            reporter=batch_reporter)

        readerFunc = doc_reader.dr.readFromDir if args.readFromDir else doc_reader.dr.read
        tags, scores, metric_keys = rank_tester.rank(
            doc_reader.read(args.test, readerFunc))

        if hasattr(args, 'destination') and args.destination is not None:
            with open(args.destination, 'w') as out_f:
                stat_reporter.report(tags, scores, metric_keys, out_f)
        else:
            stat_reporter.report(tags, scores, metric_keys, sys.stdout)

    def __call__(self, args):
        random.seed(1)
        self.main(args)
