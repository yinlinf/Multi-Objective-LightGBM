from __future__ import absolute_import
from itertools import groupby, islice

import numpy as np
import os

from d_common.iterutils import sample
from d_common.utils import yieldJson, get_all_files_in_nested_directory_tree


class Reader(object):
    """
    Base Class for document readers.
    """

    def read(self, file_name):
        """

        :param file_name:
        :return: A generator yielding collections of documents.
        """
        raise NotImplementedError()

    def readFromDir(self, dir_path):
        files = get_all_files_in_nested_directory_tree(
            os.path.abspath(dir_path))
        for file_name in files:
            for docs in self.read(file_name):
                yield docs


class PairwiseDocReader(Reader):
    """
    Reader for pairwise document format.
    Assumes each doc contains fields 'd2', 'd1'
    """

    def read(self, file_name):
        """

        :param file_name:
        :return: Generator yielding pairs of documents.
        """
        for docs in yieldJson(file_name):
            yield docs['d2'] + docs['d1']


class ListDocReader(Reader):
    """
    Assumes the file `file_name` consists of an array of json ojects per line.
    [{field1: key1,  field2: key2, ..}, {field1: ..}, ..]\n
    """

    def read(self, file_name):
        """

        :param file_name:
        :return: generator yielding list of documents.
        """
        for docs in yieldJson(file_name):
            yield docs


class FlatDocReader(Reader):
    """
    Reader for a file with one document per line producing a collection
    of documents by grouping contiguous lines sharing the same value in `group_field`.

    Expects a single document (json) per line each with field (key) `group_field`

    NOTE : Will only group together documents sharing the same value in `group_field` when
    they are contiguous (check the test cases for examples).
    """

    def __init__(self, group_field):
        """
        :param group_field: String name of field
        :type group_field: str
        """
        self.groupField = group_field

    def read(self, file_name):
        """
        Read documents from file `file_name`, group by `group_field` and
        return a generator of collections of documents.
        :param file_name:
        :return: generator yielding list of documents.
        """

        def key(x):
            """Key for groupby"""
            return x[self.groupField]

        for _, docs in groupby(yieldJson(file_name), key=key):
            yield list(docs)


class ConstReader(Reader):
    def __init__(self, item):
        self.item = item

    def read(self, file_name):
        while True:
            yield self.item


class LambdaFilter(Reader):
    def __init__(self, doc_reader):
        self.dr = doc_reader

    def read(self, file_name, readerFunc):
        for docs in readerFunc(file_name):
            if not self.predicate(docs):
                continue

            yield docs

    def predicate(self, docs):
        raise NotImplementedError()


class PartitionFilter(LambdaFilter):
    def __init__(self, doc_reader, partitions):
        self.dr = doc_reader
        self.partitions = partitions

    def predicate(self, docs):
        for partition in self.partitions:
            for t in partition(docs):
                if t == "EXCLUDE":
                    return False
        return True


class SubsampleFilter(LambdaFilter):
    def __init__(self, doc_reader, sample, seed=2017):
        self.dr = doc_reader
        self.sample = sample
        self.rs = np.random.RandomState(seed)

    def predicate(self, docs):
        return self.rs.rand() < self.sample


class SampleFilter(Reader):
    """
    Reservoir-sample of size sample_size from input stream.
    """

    def __init__(self, doc_reader, sample_size, seed=2017):
        """

        :param doc_reader: An source document Reader
        :param sample_size: Number of samples
        :param seed:
        """
        self.dr = doc_reader
        self.sample_size = sample_size
        self.seed = seed

    def read(self, file_name):
        """
        Return a an generator of samples read from file.
        :param file_name:
        :return:
        """
        it = self.dr.read(file_name)
        return sample(it, self.sample_size, self.seed)


class HeadFilter(Reader):
    """
    Modify input doc reader to only take the first_k documents.
    """

    def __init__(self, doc_reader, first_k):
        """

        :param doc_reader:
        :type doc_reader: Reader
        :param first_k: Number of samples to take
        :type first_k: int
        """
        self.dr = doc_reader
        self.first_k = first_k

    def read(self, file_name):
        return islice(self.dr.read(file_name), self.first_k)


def build_readers(args, partitions):
    """ Generate readers for samples from arguments.

    :param args:
    :return:
    """
    if args.data_format == 'pairwise':
        doc_reader = PairwiseDocReader()
    elif args.data_format == 'list':
        doc_reader = ListDocReader()
    else:
        doc_reader = FlatDocReader(args.groupField)

    # Read only a sample of the data
    if args.sample is not None:
        if args.sample < 1:
            doc_reader = SubsampleFilter(doc_reader, args.sample)
        elif args.sample > 1:
            doc_reader = SampleFilter(doc_reader, int(args.sample))

    elif args.firstK is not None:
        doc_reader = HeadFilter(doc_reader, args.firstK)

    return PartitionFilter(doc_reader, partitions)
