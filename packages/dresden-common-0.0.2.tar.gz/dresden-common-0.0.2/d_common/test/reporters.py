from __future__ import absolute_import
from collections import defaultdict

import numpy as np
from six.moves import map


class Reporter(object):
    """
    Takes the aggregated results and tags and formats an output.
    """

    def __init__(self, labels):
        self.labels = labels

    def report(self, tags, scores, metrics, out_f):
        """
        tags: [["tag"]]
        scores: [[{"metric": number}]]
        scores: set("metric")
        """
        raise NotImplementedError()


class CsvReporter(Reporter):
    """
    Base class for CSV reporters. To extend write to own csv_row method.
    """

    def group_tags(self, tags):
        """
        [["tag1", "tag2"], ["tag2"]] => {"tag1": [0], "tag2": [0,1]}
        """
        groups = defaultdict(list)
        for i, tagset in enumerate(tags):
            for t in set(tagset):
                groups[t].append(i)

        return groups

    def read_scores(self, idxs, metric, scores):
        """
        idxs: [0,1,...]
        metric: "NDCG"
        score: [0.3, 0.91,...]
        """
        for idx in idxs:
            if metric in scores[idx]:
                yield scores[idx][metric]

    def csv_row(self, tag, metric, ranker, scores):
        """
        String format of rows of csv
        :param tag:
        :param metric:
        :param ranker:
        :param scores:
        :return:
        """
        return NotImplementedError()

    def report(self, tags, scores, metrics, out_f):
        """
        Write CSV rows to file.
        :param tags:
        :param scores:
        :param metrics:
        :param out_f:
        :return:
        """
        tag_idxs = self.group_tags(tags)
        tag_names = sorted({t for ts in tags for t in ts})
        metrics = sorted(list(metrics))
        for tag in tag_names:
            tids = tag_idxs[tag]
            for metric in metrics:
                for i, ranker in enumerate(self.labels):
                    tm_scores = list(self.read_scores(tids, metric, scores[i]))
                    out_f.write(self.csv_row(tag, metric, ranker, tm_scores))


class NoopReporter(Reporter):
    """
    Reporter that does nothing.
    """

    def report(self, tags, scores, metrics, out_f):
        """ No op """
        pass


class SimpleCsvReporter(CsvReporter):
    """
    Reports Simple CSV metrics:
    Tag,Metric,Ranker,DocumentCount,Mean,Std
    """

    def csv_row(self, tag, metric, ranker, scores):
        scores = [score for score in scores if score is not None]
        n = len(scores)
        mean = np.mean(scores)
        std = np.std(scores) / np.sqrt(n - 1)
        record = '{},{},{},{},{},{}\n'.format(tag, metric, ranker, n, mean, std)
        return record


class PercentileCsvReporter(CsvReporter):
    """
    Produce CSV rows
    Tag,Metric,Ranker,DocumentCount,MinScore,5%-score,10%,..
    """

    def csv_row(self, tag, metric, ranker, scores):
        scores = [score for score in scores if score is not None]
        n = len(scores)
        p = np.arange(0, 100.1, 5)
        if (n > 0):
            percentiles = np.percentile(scores, p)
        else:
            percentiles = [0.0] * len(p)
        record = '{},{},{},{},{}\n'.format(tag, metric, ranker, n,
                                           ",".join(map(str, percentiles)))
        return record
