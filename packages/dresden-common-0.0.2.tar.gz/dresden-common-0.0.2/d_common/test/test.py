class Test(object):
    @property
    def name(self):
        raise NotImplementedError()

    @property
    def description(self):
        raise NotImplementedError()

    def arguments(self, subparser):
        raise NotImplementedError()

    def __call__(self, args):
        raise NotImplementedError()
