from __future__ import absolute_import

import argparse
from six.moves import filter


def partition_schema(s, action_field=None, actions_to_score=None):
    """
    Parser for partitions - assumes format

    aggregation_type:partition_name:arg1:arg2:..:argN

    :param s: Input string encoding the partition
    :param action_field: Field encoding user actions wrt document
    :param actions_to_score: Actions that we are scoring in evaluation.
    :return:
    """

    if (s == "all"):
        return AllPartition()

    try:
        args = s.split(":")
        aggregation = args[0]
        name = args[1]

        if (aggregation == "action-only" and action_field is not None
                and actions_to_score is not None):

            def filter_method(doc):
                """ Require that two sets have non-zero overlap """
                return not set(doc[action_field]).isdisjoint(
                    set(actions_to_score))
        else:
            filter_method = None

        if (name == "field"):
            return FieldPartition(
                args[2], aggregation, filter_method=filter_method)
        elif (name == "field-subset"):
            return FieldSubsetPartition(
                args[2],
                args[3].split(","),
                aggregation,
                filter_method=filter_method)

        elif (name == "field-filter"):
            return FieldFilterPartition(
                args[2],
                args[3].split(","),
                aggregation,
                filter_method=filter_method)
        else:
            argparse.ArgumentTypeError("Invalid Partition name")
    except ValueError:
        raise argparse.ArgumentTypeError(
            "Expected format 'aggregation_type:partition_name:arg1:arg2:..")


class Partition(object):
    """
    Base class for functions that partition our samples.
    """

    def __call__(self, doc):
        raise NotImplementedError()


class AllPartition(Partition):
    """
    Trivial partition mapping all documents to `all`
    """

    def __call__(self, doc):
        return ["all"]


class DocBasedPartition(Partition):
    """
    Partition based on labels generated from individual documents.
    """

    def __init__(self, aggregation, filter_method=None):
        self.aggregation = aggregation
        self.filter_method = filter_method

    def label_from_doc(self, doc):
        """
        Generate label from document.
        :param doc:
        :return:
        """
        raise NotImplementedError()

    def __call__(self, doc_list):

        if (self.aggregation == "head"):
            return [self.label_from_doc(doc_list[0])]
        elif (self.aggregation == "distinct"):
            return list(set([self.label_from_doc(doc) for doc in doc_list]))
        elif (self.aggregation == "action-only"):
            filtered_docs = list(filter(self.filter_method, doc_list))
            return list(
                set([self.label_from_doc(doc) for doc in filtered_docs]))
        else:
            raise Exception("Unknown aggregation method in Partition")


class FieldPartition(DocBasedPartition):
    """
    Partition based on the value in a particular field of docs in a document list.
    """

    def __init__(self, field, aggregation, filter_method=None):
        super(FieldPartition, self).__init__(aggregation, filter_method)
        self.field = field

    def label_from_doc(self, doc):
        """
        Extract value from field for single document.
        :param doc:
        :return:
        """
        return str(self.field) + "." + str(doc.get(self.field, "null"))


class FieldSubsetPartition(DocBasedPartition):
    """
    Partition based on the value in a particular field - only retaining the fields
    in `keep` and mapping the others to the bin "other"
    """

    def __init__(self, field, keep, aggregation, filter_method=None):
        super(FieldSubsetPartition, self).__init__(aggregation, filter_method)
        self.field = field
        self.keep = set(keep)

    def label_from_doc(self, doc):
        """
        Extract value from field for single document.
        :param doc:
        :return:
        """
        value = str(doc.get(self.field, "null"))
        if value in self.keep:
            return str(self.field) + "." + value
        else:
            return self.other_label()

    def other_label(self):
        return str(self.field) + ".other"


class FieldFilterPartition(FieldSubsetPartition):
    """
    Partition based on the value in a particular field - only retaining the fields
    in `keep` and filtering out examples with no documents that match. NOTE: this
    will affect stats for all other partitions -- filtered examples will be removed
    from the analysis entirely, as with all Filters.
    """

    def other_label(self):
        return "EXCLUDE"