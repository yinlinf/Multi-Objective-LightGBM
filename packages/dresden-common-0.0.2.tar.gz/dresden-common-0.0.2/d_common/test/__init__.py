from .ranker import RankerRunner as Ranker

tests = [Ranker]
