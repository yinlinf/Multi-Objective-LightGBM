#!/usr/bin/env python
"""
Posting a simple CSV to graphite.
"""
from __future__ import print_function
from __future__ import absolute_import
import socket
import csv


def _post_metrics(sock, stats_file, timestamp_field, metric_columns, namespace):
    metric_lines = []
    with open(stats_file, 'rt') as csvfile:
        stats = csv.DictReader(csvfile)
        for row in stats:
            # Populate metric_columns if not given
            if not metric_columns:
                metric_columns = stats.fieldnames
                metric_columns = [
                    field for field in metric_columns
                    if field != timestamp_field
                ]
            # Format rows in graphite format
            for metric_column in metric_columns:
                metric_column_clean = metric_column.replace(" ", "")
                metric_value = row[metric_column]
                timestamp_value = int(row[timestamp_field])
                new_stat = [
                    '%s.%s %s %d' % (namespace, metric_column_clean,
                                     metric_value, timestamp_value)
                ]
                metric_lines += new_stat
    message = '\n'.join(metric_lines) + '\n'
    print('sending message to graphite:\n%s' % message)
    sock.sendall(message.encode())


def get_graphite_socket(graphite_host, graphite_port):
    """
    Gets a socket to graphite, given the host and port
    :param graphite_host: (string) Graphite host to connect to.
    :param graphite_port: (int) Graphite port to connect to.
    :return: socket.socket object connected to the given location
    """
    sock = socket.socket()
    try:
        sock.connect((graphite_host, graphite_port))
        return sock
    except socket.error as e:
        print("socket error:", e)
        raise SystemExit("Couldn't connect to %(server)s on port %(port)d " %
                         {'server': graphite_host,
                          'port': graphite_port})


def open_close_socket(func):
    def wrapper_open_close_socket(graphite_host, graphite_port, *args,
                                  **kwargs):
        sock = get_graphite_socket(graphite_host, graphite_port)
        func(sock, *args, **kwargs)
        sock.close()

    return wrapper_open_close_socket


@open_close_socket
def post_metrics(sock, stats_file, timestamp_field, metric_columns, namespace):
    """
    Posts metrics to graphite
    :param graphite_host: (string) Graphite host to connect to.
    :param graphite_port: (int) Graphite port to connect to.
    :param stats_file: (string) Filename containing graphite metrics in CSV
                       format.
    :param timestamp_field: (string) Name of CSV column corresponding to
                            the timestamp.
    :param metric_columns: (None or list of strings) Names of the columns in
                           the given data to report to graphite. If None, all
                           data will be reported.
    :param namespace: (string) Graphite namespace to post to.
    """
    return _post_metrics(sock, stats_file, timestamp_field, metric_columns,
                         namespace)
