class AppError(Exception):
    pass


class App(object):
    """
    Application endpoint.  This interface defines how a model or set of models
    is evaluated given a model.  It will get passed the fully initialized models
    as well as any configured options (e.g. thresholds) on startup.

    Apps are expected to be pure and deterministic, to allow for linear scaling
    across clusters.
    """

    def __init__(self, models, opts, logger):
        """
        Params
        ------
        models - dict -  Set of models defined in the schema
        opts - dict - Set of schema specified load options.
        logger - Logger to use.
        """
        self.opts = opts
        self.models = models
        self.logger = logger

    def channels(self):
        """
        Returns a dictionary, mapping expected channels to expected types.

        Params
        ------
        @rtype: dict - {"channel_name": "channel_type"}
        """
        raise NotImplementedError()

    def evaluate(self, context, **query):
        """
        Executes the given context, usually a document, with a set of models.

        Params
        ------
        @param context: Document, usually in the form of a dict.
        @param **query: Query-specific parameters.  These are almost never used
        @rtype: JSONable object, describing the results of the execution
        """
        raise NotImplementedError()
