from d_common.application.app import App, AppError
from d_common.application.basics.ensemble_ranker import EnsembleRanker
from d_common.interfaces import KNNSearcher, EmbeddingGenerator, Regressor


class EnsembleANN(EnsembleRanker):
    """
    Requires 'opts' to specify a 'field_name' and `ensemble_graph` param.

    Schema.json:
    - projects/embeddings/nir_faiss_ensemble.json
    - projects/embeddings/ann/schema.json

    When given a set of documents, it will return the scores of the documents
    in the same order as passed in.

    """

    def _validate_model_instance(self, task_conf):
        return isinstance(self.models[task_conf['model_name']],
                          (KNNSearcher, EmbeddingGenerator, Regressor))

    def execute_dag_ann(self, docs, **kwargs):
        """
        Executes the ensemble list to get the scores
        Output of previous node is input to the current node. 
        :param docs: list of dict, documents
        :return: list of scores
        """
        for node in self.ensemble_dag.ensemble_list:
            model_output = node.model.decision_function(docs, **kwargs)
            docs = model_output

        return model_output

    def evaluate(self, context, **query):
        """
        This evaluates the ensemble models and return result for a given query
        For ANN, ensemble includes combination of embedding generator(eg: fasttext) and faiss
        :param context: docs of type list
        :return: list of ids
        """
        if "query" not in context[0]:
            raise AppError("must include query")

        docs = context[0]["query"]
        optional_args = context[0]
        optional_args.pop("query", None)

        return self.execute_dag_ann(docs=docs, **optional_args)
