from __future__ import absolute_import
from d_common.application.app import App, AppError
from d_common.interfaces import BinaryClassifier as BinaryClassifierI
from d_common.interfaces import MultiLabelClassifier as MultiLabelClassifierI


class BinaryClassifier(App):
    """
    Requires 'opts' to specify a 'model' param, referencing the model name.

    When given a set of documents, it will return the scores of the documents
    in the same order as passed in.
    """

    def __init__(self, models, opts, logger):
        super(BinaryClassifier, self).__init__(models, opts, logger)
        self.model_name = opts.get('model')

        if self.model_name is None:
            raise AppError("Missing parameter 'model' from options")

        elif self.model_name not in self.models:
            raise AppError(
                "Model `{}` has not been defined".format(self.model_name))

        elif not isinstance(self.model, BinaryClassifierI):
            raise AppError("Model `{}` is not a BinaryClassifier!".format(
                self.model_name))

    @property
    def model(self):
        return self.models[self.model_name]

    def channels(self):
        return self.model.channels()

    def evaluate(self, context, **query):
        if not isinstance(context, list):
            raise AppError("Expects a list of documents")

        return self.model.decision_function(context)


class MultiLabelClassifier(App):
    """
    Requires 'opts' to specify a 'model' param, referencing the model name.

    When given a set of documents, it will return the scores of the documents
    in the same order as passed in.
    """

    def __init__(self, models, opts, logger):
        super(MultiLabelClassifier, self).__init__(models, opts, logger)
        self.model_name = opts.get('model')

        if self.model_name is None:
            raise AppError("Missing parameter 'model' from options")

        elif self.model_name not in self.models:
            raise AppError("Model `{}` has not been defined".format(self.model_name))

        elif not isinstance(self.model, MultiLabelClassifierI):
            raise AppError("Model `{}` is not a MultiLabelClassifier!".format(
                self.model_name))

    @property
    def model(self):
        return self.models[self.model_name]

    def channels(self):
        return self.model.channels()

    def evaluate(self, context, **query):
        if not isinstance(context, list):
            raise AppError("Expects a list of documents")

        return self.model.decision_function(context)
