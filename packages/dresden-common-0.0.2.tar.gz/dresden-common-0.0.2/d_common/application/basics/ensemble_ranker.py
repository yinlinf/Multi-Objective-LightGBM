from __future__ import absolute_import
from d_common.application.app import App, AppError
from d_common.interfaces import Ranker
from d_common.ensemble_list import EnsembleList
import six


class EnsembleRanker(App):
    """
    Requires 'opts' to specify a 'field_name' and `ensemble_graph` param.

    Schema.json:

    {
      "models": {
        "vw": {
          "interface": "d_vw.interfaces:VWRanker",
          "path": "<path-to-vw-model-folder>", # In most cases, it is '<path-to-schema.json>/vw'
          "packager": "d_vw.interfaces:Packager",
          "opts": {
            "extra_flags": {
              "sort_features": "true"
            }
          }
        },
        "lgbm": {
          "interface": "d_lgbm.interfaces:Ranker",
          "path": "<path-to-lgbm-model-folder>",  # In most cases, it is '<path-to-schema.json>/lgbm'
          "packager": "d_lgbm.interfaces:Packager",
          "opts": {}
        }
      },
      "application": {
        "entrypoint": {
          "path": "d_common.application.basics:EnsembleRanker",
          "type": "module"
        },
        "opts": {
          "ensemble_dag": {
            "task_1": {
              "model_name": "vw",
              "field_name": "vw_score"
            },
            "task_2": {
              "model_name": "lgbm",
              "upstream_dependency": "task_1",
              "return_score": "True"
            }
          }
        }
      },
      "meta": {
        "name": "CSR Ensemble Ranker"
      }
    }

    Ensemble_dag: In this class we can only define linear dag
    `Task_*`: Keys is used as an identifier to define upstream dependencies
    `model_name`: It is used to retrieve the model from `models` configuration
    `upstream_dependency`: It decides the dependency of model input
    `field_name`: It decides the field name of model score. It should match buzzsaw config
    `return_score`: It decides whether you would want to return prediction score for this model task or not,
    by default we only return score for last task.

    When given a set of documents, it will return the scores of the documents
    in the same order as passed in.

    TODO: Define Graph class to create non-linear ensemble dags
    """

    def __init__(self, models, opts, logger):
        super(EnsembleRanker, self).__init__(models, opts, logger)

        self.models = models
        self.ensemble_dag = EnsembleList()
        self.ensemble_dag.create_dag(
            ensemble_params=self._create_ensemble_params(
                opts.get('ensemble_dag')))

    def _create_ensemble_params(self, ensemble_dag_params):
        """
        Add models in the Graph configuration
        :param ensemble_dag_params: dict
        :return: dict
        """

        if not ensemble_dag_params:
            raise KeyError(
                "`ensemble_dag` field is required in schema file."
                "It creates a dag for executing models and retrieving scores")

        for task, task_conf in six.iteritems(ensemble_dag_params):
            self._validate_model_param(task_conf)
            task_conf['model'] = self.models[task_conf['model_name']]

        return ensemble_dag_params

    def _validate_model_param(self, task_conf):
        """
        It will validate the model configuration
        :param task_conf: dict
        :return: None
        """
        if 'model_name' not in task_conf:
            raise KeyError(
                "Task configuration do not have `model_name` attribute")
        elif task_conf['model_name'] not in self.models:
            raise AppError(
                "Model `{}` has not been defined".format(self.model_name))
        elif not self._validate_model_instance(task_conf):
            raise AppError(
                "Model `{}` is not a Ranker!".format(task_conf['model_name']))
        return

    def _validate_model_instance(self, task_conf):
        return isinstance(self.models[task_conf['model_name']], Ranker)

    def channels(self):
        return self.ensemble_dag.get_channels()

    def evaluate(self, context, **query):
        """
        This evaluates the ensemble models and return prediction score
        if we are returning scores from one model, this function will return
        list of scores [1.0, 2,0, 3.0] etc.
        if we are returning scores from multiple models, this function will return
        dict of scores {'lgbm': [1.0, 2,0, 3.0], 'vw': [1.0, 2,0, 3.0]} etc
        :param context: docs of type list or dict
        :return: list or dict
        """
        if not isinstance(context, (list, dict)):
            raise AppError("Expects a list or dict of documents")

        if isinstance(context, dict):
            return self.ensemble_dag.execute_dag(docs=[context])

        return self.ensemble_dag.execute_dag(docs=context)
