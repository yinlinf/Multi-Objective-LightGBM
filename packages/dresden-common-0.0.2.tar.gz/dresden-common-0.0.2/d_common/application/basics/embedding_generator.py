from __future__ import absolute_import
from d_common.application.app import App, AppError
from d_common.interfaces import EmbeddingGenerator as EmbeddingGeneratorI


class EmbeddingGenerator(App):
    """ 
    Given a doc, generate embedding
    """

    def __init__(self, models, opts, logger):
        super().__init__(models, opts, logger)
        self.model_name = opts.get('model')

        if self.model_name is None:
            raise AppError("Missing parameter 'model' from options")

        elif self.model_name not in self.models:
            raise AppError(
                "Model `{}` has not been defined".format(self.model_name))

        if not isinstance(self.model, EmbeddingGeneratorI):
            raise AppError("Model `{}` is not a Embedding Generator!".
                           format(self.model_name))

    @property
    def model(self):
        return self.models[self.model_name]

    def channels(self):
        raise NotImplementedError

    def evaluate(self, context, **query):
        if not isinstance(context, list):
            raise AppError("Expects a list of documents")

        return self.model.decision_function(context)
