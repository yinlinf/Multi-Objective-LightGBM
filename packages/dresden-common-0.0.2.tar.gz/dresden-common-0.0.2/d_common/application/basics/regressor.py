from __future__ import absolute_import
from d_common.application.app import App, AppError
from d_common.interfaces import Regressor as RegressorI


class Regressor(App):
    """
    Requires 'opts' to specify a 'model' param, referencing the model name.

    When given a set of documents, it will return the scores of the documents
    in the same order as passed in.
    """

    def __init__(self, models, opts, logger):
        super(Regressor, self).__init__(models, opts, logger)
        self.model_name = opts.get('model')

        if self.model_name is None:
            raise AppError("Missing parameter 'model' from options")

        elif self.model_name not in self.models:
            raise AppError(f"Model `{self.model_name}` has not been defined")

        elif not isinstance(self.model, RegressorI):
            raise AppError(f"Model `{self.model_name}` is not a Regressor!")

    @property
    def model(self):
        return self.models[self.model_name]

    def channels(self):
        return self.model.channels()

    def evaluate(self, context, **query):
        if not isinstance(context, list):
            raise AppError(
                f"Expects 'context' to be type list, but got {type(context)}")

        return self.model.decision_function(context)
