from __future__ import absolute_import
import os
import json
import logging
import sys
import re
import six

from d_common.utils import class_loader, file_loader
from d_common.timing import timeit

logging.basicConfig(
    stream=sys.stderr,
    format='%(asctime)s %(levelname)-8s %(message)s',
    level=logging.DEBUG,
    datefmt='%Y-%m-%d %H:%M:%S')
logger = logging.getLogger("schema")


class Schema(object):
    """
    Defines a dresden schema.  A dresden schema is composed of three parts: models, application, and meta.

    Models are required to provide the following fields:

        path      - /to/model    - File path to the model directory
        interface - module:class - A Loadable interface responsible for initializing a model
        packager  - module:class - A Packager class used to copy the underlying data necessary
                                   for loading a model in production.
        opts      - dict         - Initialization options to pass to the Loadable instances.

    Applications are with the following fields:

        entrypoint - dict - Either a module on the python path _or_ an absolute
                            path to a script containing an implementation of the
                            App interface.  Any script referenced is required
                            to be self contained, outside of imports from within
                            dresden.

        opts       - dict   - Application level options, passed in at init

    `Entrypoint` accepts two versions currently:
        ```{"type": "module": "path": "python.module.to:ClassName}```

        or

        ```{"type": "file", "path": "/path/to/pythonfile.py:ClassName}```

    Optionally, schema's can define a 'meta' section.  This provides a set of metadata
    that can be used for informational purposes and is returned with every request.

    A Schema example:

    {
        "models": {
            "my_vw_ranker": {
                "path": "/path/to/ranker",
                "interface": "d_vw.interfaces:VWRanker",
                "packager":  "d_vw.interfaces:VWPackager",
                "opts": {}
            }
        },
        "application": {
            "entrypoint": {
                "type": "module",
                "path": "d_common.application.ranker:Ranker"
            },
            "opts": {
                "model": "my_vw_ranker"
            }
        }
    }
    """

    def __init__(self, path):
        with open(path) as f:
            data = json.load(f)

        self.path = path
        self.models = data['models']
        self.app = data['application']
        self.meta = data.get('meta', None)
        self.post_fork_models = []

    def abs_path(self, path):
        dirname = os.path.dirname(self.path)
        return os.path.join(dirname, path)

    @timeit
    def load_application(self):
        """
        This method load the application and models
        :return: app
        """

        # Load the models
        models = self.load_models()

        # Load the application
        app = self.load_application_class(models)

        return app

    @timeit
    def load_models(self):
        """
        This function loads the model and print out time taken for loading
        :return: dict of model classes
        """
        models = {}

        for model_name, spec in six.iteritems(self.models):
            logger.info("Started Loading interface for %s from %s", model_name,
                        spec['path'])
            interface = class_loader(spec['interface'])
            model = interface.load(self.abs_path(spec['path']), **spec['opts'])
            if hasattr(model, 'post_fork') and model.post_fork:
                self.post_fork_models.append(model_name)
            models[model_name] = model
            logger.info("Completed Loading interface for %s from %s",
                        model_name, spec['path'])
        return models

    @timeit
    def load_application_class(self, models):
        """
        This method loads the application class
        :param models: dict of model classes
        :return: application class
        """
        entrypoint = self.app['entrypoint']

        logger.info("Started Loading application from %s", entrypoint)
        e_type, e_path = entrypoint['type'], entrypoint['path']
        if e_type == 'module':
            app_cls = class_loader(e_path)
        elif e_type == 'file':
            app_cls = file_loader(e_path, rel_path=os.path.dirname(self.path))
        else:
            raise TypeError("Unknown entrypoint `{}`".format(e_type))

        app = app_cls(models, self.app['opts'], logger)
        logger.info("Completed Loading application from %s", entrypoint)

        return app

    def get_fixture_path(self):
        """
        Returns path to the fixture data.

        Params
        ------
        @rtype: /path/to/fixture
        """
        dirname = os.path.dirname(self.path)
        return os.path.join(dirname, 'fixture.json')

    def packagers(self):
        for model_name, spec in six.iteritems(self.models):
            pkg_cls = class_loader(spec['packager'])
            yield model_name, pkg_cls, spec['path']

    def dump(self):
        return {
            "models": self.models,
            "application": self.app,
            "meta": self.meta
        }

    def split_destination_path(self, gcs_path):
        """
        This methods divides the gcs_path into bucket_name, directory_path, model_namespace
        :param gcs_path: str
        :return: tuple
        """
        bucket_prefix_match = re.match('gs://[^/]+/', gcs_path)
        if not bucket_prefix_match:
            raise Exception(
                'Passed package_destination_paths `{}` is not a gcs path, we only support GCS paths'.
                format(gcs_path))

        gcs_prefix = "gs://"
        gcs_path_without_prefix = gcs_path.replace(gcs_prefix, '')
        gcs_path_list = gcs_path_without_prefix.split('/')
        bucket_name, blob_path, blob_name = gcs_path_list[0], "/".join(
            gcs_path_list[1:-1]), gcs_path_list[-1]
        return bucket_name, blob_path, blob_name

    def override_gcs_path_in_schema(self, destination_paths):
        """
        This method override/add gcs path in schema file
        :param destination_paths: dict
        :return: None
        """
        for model_name, model_gcs_path in destination_paths.items():
            bucket_name, directory_path, model_namespace = self.split_destination_path(
                model_gcs_path)
            if model_name not in self.models:
                raise Exception("model: `{}` does not exist in Schema.json".
                                format(model_name))
            gcs_path = {
                'bucket': bucket_name,
                'path': directory_path,
                'model': model_namespace
            }
            self.models[model_name]['path'] = {'gcs': gcs_path}

    def override_local_path_in_schema(self, destination_paths):
        """
        This method overrides local path in schema file
        :param destination_paths: str
        :return: None
        """
        for model_name, model_path in destination_paths.items():
            if model_name not in self.models:
                raise Exception("model: `{}` does not exist in Schema.json".
                                format(model_name))
            self.models[model_name]['path'] = model_path

    def validate_schema_file(self):
        """
        It loads the schema and validates the arguments
        :param schema: dict
        :return: None
        """
        MODEL_REQUIRED_KEYS = {'packager', 'interface', 'path'}
        GCS_REQUIRED_KEYS = {'bucket', 'path', 'model'}

        for model, model_conf in six.iteritems(self.models):
            if not set(model_conf.keys()).issuperset(MODEL_REQUIRED_KEYS):
                raise KeyError(
                    "`models` configuration does not have required fields: `packager, interface, path`"
                )

            if type(model_conf['path']) == dict and model_conf['path'].get(
                    'gcs'):
                gcs_conf = model_conf['path']['gcs']
                if type(gcs_conf) != dict:
                    raise TypeError(
                        "Type of gcs parameters are expected `dict` but passed `{}`".
                        format(type(gcs_conf)))
                if set(gcs_conf.keys()) != GCS_REQUIRED_KEYS:
                    raise KeyError(
                        "The GCS configuration does not include all required keys:"
                        " required keys: `bucket, path, model`")
