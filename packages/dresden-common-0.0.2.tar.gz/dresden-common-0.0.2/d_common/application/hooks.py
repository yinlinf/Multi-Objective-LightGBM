from __future__ import absolute_import
import logging
import os
import six
import sys

from d_common.application.schema import Schema
from d_common.application.fixture import Fixture
from d_common.timing import time_metrics, timeit

logging.basicConfig(
    stream=sys.stderr,
    format='%(asctime)s %(levelname)-8s %(message)s',
    level=logging.DEBUG,
    datefmt='%Y-%m-%d %H:%M:%S')
logger = logging.getLogger("fixture")


class HookBase(object):
    pass


class Hook(HookBase):
    __name__ = "Dresden"

    def __init__(self, path):
        self.schema = Schema(path)

        logger.info("Loading schema from %s...", path)
        self.app = self.schema.load_application()

        # We run the fixture test `post-fork` if application consists of post-fork model
        # Running the fixture test pre-fork will load the `post-fork` model in memory and will hang
        # because thread lock.
        if not self.schema.post_fork_models:
            self.run_fixture_test()

    @property
    def meta(self):
        if self.schema.meta is not None:
            return self.schema.meta

        return {}

    @property
    def extras(self):
        return {"fields": self.app.channels()}

    def batch(self, request):
        with time_metrics('prediction', tags=('interface:hook', 'step:deserializeJson')):
            jdata = request.get_json()

        keys = six.viewkeys(jdata)

        values = [jdata[k] for k in keys]

        # self.app.evaluate returns list of scores [1.0, 2.0] in case of single model
        # and returns dict of scores {'lgbm': [1.0, 2.0], 'vw': [1.0, 2.0]} in case of
        # ensemble models
        results = self.app.evaluate(values)
        response = {}
        if isinstance(results, dict):
            for idx, key in enumerate(keys):
                response[key] = {
                    model_name: pred_scores[idx]
                    for model_name, pred_scores in results.items()
                }
        else:
            response = {key: results[idx] for idx, key in enumerate(keys)}

        return response

    def get_or_post(self, request):
        if request.get_data():
            return request.get_json()

        return {k: request.args[k] for k in six.iterkeys(request.args)}

    @timeit
    def run_fixture_test(self, num_test_samples=sys.maxsize):
        """
        This functions tests the application against fixture data stored in the package
        :param: num_test_samples: int
        :return: None
        """
        # If fixtures exist, use them to check if the model is behaving
        # as expected.
        logger.info("Started running fixture test...")
        fixtures_path = self.schema.get_fixture_path()
        if os.path.lexists(fixtures_path):
            with time_metrics('fixture_test'):
                Fixture.test(self.app, fixtures_path, num_test_samples)
        logger.info("Completed running fixture test...")

    def __call__(self, request):
        if request.args.get("batch", False):
            resp = self.batch(request)
        else:
            jdata = self.get_or_post(request)
            resp = self.app.evaluate([jdata])
            if isinstance(resp, list):
                # single request only has one prediction score in the list as a response
                resp = resp[0]
            elif isinstance(resp, dict):
                resp = {
                    model_name: results[0]
                    for model_name, results in resp.items()
                }
        return "results", resp
