from __future__ import print_function
from __future__ import absolute_import
import json
import sys
import time

from itertools import islice
from d_common.utils import yieldJson

MAX_FIXTURE_TEST_TIME = 30  # allow 30s for the fixture test to run
MIN_FIXTURE_SAMPLES = 10  # minimum number of fixture data points that must be run for the fixture test to be considered acceptable


class FixtureError(Exception):
    def __init__(self, input, expected, received):
        self.input = input
        self.expected = expected
        self.received = received


class Fixture(object):
    """
    Defines the set of functions for building and testing fixtures against apps.
    """

    @staticmethod
    def generate(app, in_file, out_file):
        """
        Generates testdata given a set of inputs.

        Params
        ------
        @param app: d_common.application.app:App
        @param in_file: basestring - Path to context data to be passed into the model
        @param out_file: basestring - Path to location for storing fixture data
        @rtype: None
        """
        with open(out_file, 'w') as out:
            for ctx in yieldJson(in_file):
                output = app.evaluate(ctx)
                print(json.dumps({"input": ctx, "expected": output}), file=out)

    @staticmethod
    def _check_time_limit(start, fixture_sample_thresh, num_proc_fixtures):
        if (time.time() - start) >= MAX_FIXTURE_TEST_TIME:
            if num_proc_fixtures < fixture_sample_thresh:
                raise Exception(
                    "Only {} fixture samples processed in {} ms.".format(
                        num_proc_fixtures, MAX_FIXTURE_TEST_TIME))
            print(
                "Not all fixture data was processed. {} data points were processed out of a minimum of {}".
                format(num_proc_fixtures, fixture_sample_thresh))
            return True

        return False

    @staticmethod
    def test(app, fixture_file, num_test_samples=sys.maxsize):
        """
        Evaluates fixture data against a given app

        Params
        ------
        @param num_test_samples: int
        @param app: d_common.application.app:App
        @param fixture_file: Path to pre-built fixture data
        @rtype: Bool or throws FixtureError
        """
        num_proc_fixtures = 0
        fixture_sample_thresh = min(num_test_samples, MIN_FIXTURE_SAMPLES)
        start = time.time()
        for test in islice(yieldJson(fixture_file), num_test_samples):
            if Fixture._check_time_limit(start, fixture_sample_thresh,
                                         num_proc_fixtures):
                return True

            evaled = app.evaluate(test['input'])
            if not test.get('ignore_expected', None):
                if evaled != test['expected']:
                    raise FixtureError(test['input'], test['expected'], evaled)
            num_proc_fixtures += 1
        return True
