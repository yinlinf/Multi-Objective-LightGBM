class Registry(object):
    def __init__(self, tcls, wrapper):
        self.tcls = tcls
        self.registry = {}
        self.wrapper = wrapper

    def register(self, name, pcls=None):
        if pcls is None:
            return lambda rpcls: self.register(name, rpcls)

        if not issubclass(pcls, self.tcls):
            raise TypeError("Class %s is not a subclass of %s" % (pcls,
                                                                  self.tcls))

        if name in self.registry:
            raise TypeError("Namespace %s is alredy registered" % name)

        self.registry[name] = self.wrapper(pcls)

        return pcls

    def __getattr__(self, name):
        return self.registry[name]

    __getitem__ = __getattr__
