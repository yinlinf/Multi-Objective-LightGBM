from __future__ import absolute_import
import contextlib
import time
import sys
from six.moves import range

from multiprocessing import cpu_count, Queue, Process
from multiprocessing.queues import Full, Empty
from threading import Thread
import traceback
from six.moves import zip


def safe_execute(sentinel, f, *args, **kwargs):
    try:
        return f(*args, **kwargs)
    except Exception:
        traceback.print_exc(file=sys.stderr)

    return sentinel


class Pipeline(object):
    def add(self, f, workers=None):
        raise NotImplementedError()

    def __lshift__(self, f):
        raise NotImplementedError()

    def __rshift__(self, f):
        raise NotImplementedError()

    def __or__(self, f):
        raise NotImplementedError()

    def __call__(self, f):
        raise NotImplementedError()


def lift(f, cls):
    """
    If f is instance of class P return f, else
    :param f:
    :param cls:
    :return:
    """
    return f if isinstance(f, P) else cls(f)


class Done(object):
    pass


class ParPipeline(Pipeline):
    """
    Creates K processes per function.
    """

    def __init__(self, ps=None, threads=cpu_count()):
        self.ps = [] if ps is None else ps
        self.threads = threads

    def add(self, p, workers=None):
        return ParPipeline(self.ps + [(p, workers)], self.threads)

    def __lshift__(self, p):
        """
        << Operator. Add FlatMap to pipeline.
        :param p:
        :return:
        """
        return self.add(lift(p, FlatMap))

    def __rshift__(self, p):
        """
        >> Operator. Add Map to pipeline.
        :param p:
        :return:
        """
        return self.add(lift(p, Map))

    def __or__(self, p):
        return self.add(lift(p, Reduce))

    def _build_queues(self, max_queue):
        return [Queue(max_queue) for _ in range(len(self.ps) + 1)]

    def __call__(self, xs, max_queue=10):
        # Create the queues
        with self._execute(max_queue, xs) as out:
            # Read and yield
            v = out.get()
            while not isinstance(v, Done):
                yield v
                v = out.get()

    @contextlib.contextmanager
    def _execute(self, max_queue, xs):
        sentinel = Done()

        qs = self._build_queues(max_queue)

        # spin up each of the processes
        procs = []
        for i, (p, threads) in enumerate(self.ps):
            if threads is None and i == len(self.ps) - 1 and isinstance(
                    p, Reduce):
                threads = 1
            elif threads is None:
                threads = self.threads

            procs.append(p.run(qs[i], qs[i + 1], sentinel, threads))

        resultQ = qs[-1]

        # feed the beast
        feeder = Thread(target=self.feed, args=(xs, procs, qs))
        feeder.start()

        yield resultQ

        # Done!  Join
        feeder.join()

        # Close the queues
        for q in qs:
            q.close()

    def feed(self, xs, procs, qs):
        inpQ, resultQ = qs[0], qs[-1]
        for x in xs:
            while True:
                try:
                    inpQ.put(x)
                except Full:
                    time.sleep(0.0001)
                    pass
                else:
                    break

        # Go through each stage, ensuring each proc is finished
        for q, procSet in zip(qs, procs):
            for _ in range(len(procSet)):
                q.put(Done())

            for p in procSet:
                p.join()

        resultQ.put(Done())


class IDone(object):
    pass


class IterableQueue(object):
    def __init__(self, maxsize):
        self.q = Queue(maxsize)

    def put(self, d):
        self.q.put(d)

    def __iter__(self):
        while True:
            v = self.q.get()
            if isinstance(v, IDone):
                break

            yield v

    def close(self):
        self.q.put(IDone())


class Function(object):
    def setup(self):
        pass

    def __call__(self):
        raise NotImplementedError()


# Spinlock
def spin_get(inpQ, sleep=None):
    while True:
        try:
            x = inpQ.get() if sleep is None else inpQ.get_nowait()
        except Empty:
            time.sleep(sleep)
        else:
            return x


def _map(f, inpQ, outQ, sent):
    if isinstance(f, Function):
        f.setup()

    sentinel = object()
    while True:
        x = spin_get(inpQ)
        if isinstance(x, Done):
            break

        ret = safe_execute(sentinel, f, x)
        if ret is not sentinel:
            outQ.put(ret)


def yieldData(inpQ, state):
    while True:
        x = spin_get(inpQ)
        if isinstance(x, Done):
            state['finished'] = True
            break

        yield x


def _reduce(f, inpQ, outQ, sent):
    if isinstance(f, Function):
        f.setup()

    sentinel = object()
    state = {"finished": False}
    while True:
        it = yieldData(inpQ, state)
        ret = safe_execute(sentinel, f, it)
        if ret is not sentinel:
            outQ.put(ret)

        if state['finished']:
            break


def finto(f, x, outQ):
    for y in f(x):
        outQ.put(y)


def _flatmap(f, inpQ, outQ, sent):
    if isinstance(f, Function):
        f.setup()

    sentinel = object()
    while True:
        x = spin_get(inpQ)
        if isinstance(x, Done):
            break

        ret = safe_execute(sentinel, finto, f, x, outQ)


class P(object):
    _runner = None

    def __init__(self, f):
        self.f = f

    def run(self, inpQ, outQ, sent, proc_count):
        procs = [
            Process(target=self._runner, args=(self.f, inpQ, outQ, sent))
            for _ in range(proc_count)
        ]

        for i, p in enumerate(procs):
            p.start()

        return procs


class Map(P):
    "x -> y"
    _runner = staticmethod(_map)


class Reduce(P):
    "[x] -> y"
    _runner = staticmethod(_reduce)


class FlatMap(P):
    "x -> [y]"
    _runner = staticmethod(_flatmap)


def batch_map(f):
    def _f(xs):
        return [f(x) for x in xs]

    return _f


def compose(*fs):
    fs = list(reversed(fs))

    def _f(x):
        for f in fs:
            x = f(x)

        return x

    return _f


@FlatMap
def flatten(xs):
    return xs


def Filter(f):
    @FlatMap
    def f2(x):
        return [x] if f(x) else []

    return f2
