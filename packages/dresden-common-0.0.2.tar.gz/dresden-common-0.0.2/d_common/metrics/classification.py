from __future__ import absolute_import
from sklearn.metrics import accuracy_score, roc_auc_score, zero_one_loss, log_loss, hinge_loss
from six.moves import range


def precision(result_set, k=None):
    if k is None:
        k = len(result_set)

    scores = 0.0
    for i in range(min(k, len(result_set))):
        if result_set[i] > 0:
            scores += 1

    return scores / k
