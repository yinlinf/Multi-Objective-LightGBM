from __future__ import absolute_import
from itertools import combinations
import sklearn.metrics as metricsSkLearn
import numpy as np
import math
from six.moves import zip
from six.moves import range


def mrr(result_set):
    for i, d in enumerate(result_set):
        if d:
            return 1 / float(i + 1)

    return 0.0


def log2(n):
    return math.log(n) / math.log(2)


def dcg1(rel_scores):
    rdcg = 0.0
    for i, s in enumerate(rel_scores):
        value = (2 ** s - 1) / log2(i + 2)

        rdcg += value

    return rdcg


def psdcg(rel_scores, prop_scores):
    rdcg = 0.0
    for i, (s, p) in enumerate(zip(rel_scores, prop_scores)):
        value = (2 ** s - 1) / (p * log2(i + 2))
        rdcg += value
    return rdcg


def precision(result_set, k=None):
    if k is None:
        k = len(result_set)

    scores = 0.0
    for i in range(min(k, len(result_set))):
        if result_set[i] > 0:
            scores += 1

    return scores / k


def dcg2(rel_scores):
    score = 0.
    for i, s in enumerate(rel_scores):
        score += s / math.log(i + 2)

    return score


def ndcg(rel_scores, k=None, f=dcg1):
    # Get dcg
    oscores = rel_scores
    if k is not None:
        rel_scores = rel_scores[:k]

    dcg = f(rel_scores)

    true_order = sorted(oscores, reverse=True)
    if k is not None:
        true_order = true_order[:k]

    # get ideal
    idcg = f(true_order)

    return dcg / idcg if idcg > 0 else 0.0


def psndcg(rel_scores, k=None, f=psdcg, prop_scores=None):
    oscores = rel_scores
    if prop_scores is None:
        prop_scores = [1 for i in range(len(rel_scores))]

    if k is not None:
        rel_scores = rel_scores[:k]
        prop_scores = prop_scores[:k]

    psdcg = f(rel_scores, prop_scores)

    true_order = sorted(oscores, reverse=True)
    prop_scores_unity = [1 for i in range(len(oscores))]
    if k is not None:
        true_order = true_order[:k]
        prop_scores_unity = prop_scores_unity[:k]

    idcg = f(true_order, prop_scores_unity)

    return psdcg / idcg if idcg > 0 else 0.0


def kendall(r1, r2):
    if len(r1) < 2 or len(r2) < 2:
        return 1.0

    s = set()
    for i, (c1,
            c2) in enumerate(zip(combinations(r1, 2), combinations(r2, 2))):
        for c in (c1, c2):
            if c in s:
                s.remove(c)
            else:
                s.add(c)

    discordant = set()
    for id1, id2 in s:
        if id1 < id2:
            id1, id2 = (id2, id1)

        discordant.add((id1, id2))

    return len(discordant) / float(i + 1)


def ndcg_tag(ranked_tags, tags, k=None):
    stags = set(tags)
    order = []
    for t in ranked_tags:
        if t in stags:
            order.append(1)
            stags.remove(t)
        else:
            order.append(0)

    if stags:
        order.extend([1] * len(stags))

    return ndcg(order, k)


def err_r(yi, grades):
    return (2 ** yi - 1) / float(grades - 1) ** 2


def err(rel_scores, k=None, grades=2):
    k = len(rel_scores) if k is None else k
    e = 0
    rolling_rel = 1.0
    for i, rs in enumerate(rel_scores):
        i += 1
        rel = err_r(rs, grades)

        e += (1 / float(i)) * rel * rolling_rel
        rolling_rel *= (1 - rel)

    return e


def grouped_auc(results):
    if all([result == results[0] for result in results]):
        return None

    max_rank = len(
        results)  # equals the maximum number of listings we recommended
    results_pred = np.linspace(start=1, stop=1 / float(max_rank), num=max_rank)

    # Say we ranked listings 1,2,3,4 as 4,2,3,1. Then the scores of each listing
    # 4,2,3,1 is given by the array results_pred. For this example, the predictions will be
    # equal to [1 0.75 0.5 0.25]

    return metricsSkLearn.roc_auc_score(
        y_true=results, y_score=results_pred)  # use sklearn to get auc.
