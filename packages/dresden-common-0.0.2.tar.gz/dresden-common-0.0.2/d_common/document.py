from __future__ import absolute_import
import six
class LazyField(object):
    cached = False
    value = None

    def __init__(self, f):
        assert callable(f), "f needs to be a function"
        self.f = f

    def __call__(self):
        if not self.cached:
            self.cached = True
            self.value = self.f()

        return self.value


class Document(object):
    """
    Can't change the type of a channel.
    """

    def __init__(self, **kwargs):
        self.fields = kwargs

    def __getitem__(self, key):
        v = self.fields[key]
        if isinstance(v, LazyField):
            v = v()

        return v

    def get(self, key, default=None):
        if key in self:
            return self[key]

        return default

    def __contains__(self, key):
        return key in self.fields

    def update(self, key, value):
        newItems = self.fields.copy()
        newItemType = type(newItems[key])
        if key in newItems and not isinstance(value, newItemType):
            if not isinstance(newItems[key], LazyField):
                # Lazy fields are allowed to be overwritten
                raise TypeError("Cannot change types: %s -> %s" % (newItemType,
                                                                   type(value)))

        newItems[key] = value
        return Document(**newItems)

    def __unicode__(self):
        res = []
        for k, v in six.iteritems(self.fields):
            res.append(u"%s: %s" % (k, type(v).__name__))

        return u"Document(%s)" % ', '.join(sorted(res))

    def __repr__(self):
        return six.text_type(self)
