from __future__ import print_function
from __future__ import absolute_import
from d_common.iterutils import batch
from itertools import takewhile

import multiprocessing
import os
import re
import signal
import subprocess
import shlex
import sys
import time
from six.moves import map


class GCSStreamer(object):
    DEFAULT_NUM_FILES_PER_PROC = 50
    MAX_NUM_STREAM_PROCS = 4

    def __init__(self, bucket, path, file_regexes, subdirs_to_walk,
                 num_stream_procs, num_files_per_proc):

        if num_files_per_proc:
            self.num_files_per_proc = num_files_per_proc
        else:
            self.num_files_per_proc = self.DEFAULT_NUM_FILES_PER_PROC

        if num_stream_procs:
            self.num_stream_procs = num_stream_procs
        else:
            # default to number of hyperthreads to maximize throughput
            self.num_stream_procs = min(self.MAX_NUM_STREAM_PROCS,
                                        multiprocessing.cpu_count() * 2)

        self.file_regexes = list(map(re.compile, file_regexes))

        if subdirs_to_walk:
            self.paths = [
                "%s%s/%s/**" % (bucket, path, d) for d in subdirs_to_walk
            ]
        else:
            self.paths = ["%s%s/**" % (bucket, path)]

    def list_files(self):
        command = "gsutil ls %s" % " ".join(self.paths)

        self._log_debug("list_files running command '%s'" % command)

        process = subprocess.Popen(
            shlex.split(command),
            stdout=subprocess.PIPE,
            stderr=sys.stderr,
            universal_newlines=True)

        for (n,
             path) in enumerate(takewhile(lambda l: l != ' ', process.stdout)):

            path = path.strip()
            if self._path_should_be_streamed(path):
                yield path

        returncode = process.wait()

        if returncode != 0:
            self._log_debug(
                "list_files error: command exited with nonzero status code: %d"
                % (returncode))

            sys.exit(returncode)

        self._log_debug("list_files command completed")

    def stream_files_to_stdout(self):
        """
        Stream file contents to stdout using GNU parallel for concurrency.

        # GNU parallel options
          `--delay` ensure an n second gap between job starts to avoid
              thundering herd
          `--jobs` how many processes to run concurrently
          `-N` number of files per gsutil command to reduce overhead
          `-X` insert as many arguments as the command line length permits
          `--line-buffer` ensures that parallel writes full lines when merging
              output from the various subjobs.
          `gsutil cp {} -` job command run by each subprocess. It copies the
              file `{}` to stdout
          `--halt now,fail=1` immediately terminate if a job failed. gsutil has
              its own built-in retry logic, and we should not add additional 
              retries in order to avoid emitting the same data multiple times.
        """
        command = "parallel --delay 0.5 --jobs %s -N %s -X --line-buffer --halt now,fail=1 gsutil cp {} -" % (
            self.num_stream_procs, self.num_files_per_proc)

        self._log_debug("stream_files_to_stdout running command '%s'" %
                        (command))

        process = subprocess.Popen(
            shlex.split(command),
            stdin=subprocess.PIPE,
            stdout=sys.stdout,
            stderr=sys.stderr)

        for (n, path) in enumerate(self.list_files()):
            if n % 5000 == 0:
                self._log_debug(
                    "stream_files_to_stdout piped %d files to gnu parallel. The next one is %s"
                    % (n, path))

            try:
                process.stdin.write("%s\n" % path)
            except IOError as e:
                self._log_debug(
                    "stream_files_to_stdout IOError while writing files to stream. %s"
                    % (e))
                sys.exit(1)

        # closing stdin so that parallel terminates upon completion
        process.stdin.close()
        self._log_debug(
            "stream_files_to_stdout done piping files to gnu parallel")

        returncode = process.wait()

        if returncode != 0:
            self._log_debug(
                "stream_paths_to_stdout error: command exited with nonzero status code: %d"
                % (returncode))

            sys.exit(returncode)

        self._log_debug("stream_files_to_stdout command completed")

    def _log_debug(self, *args, **kwargs):
        print(self.__class__.__name__, *args, file=sys.stderr, **kwargs)

    def _path_should_be_streamed(self, path):
        # If the path ends with a `/`, then it is a directory.
        path_is_file = re.compile('/$').search(path) is None

        # If the path contains this value, it is a tmp file from dataproc
        path_is_nontemporary = re.compile('/_temporary/').search(path) is None

        return path_is_file and path_is_nontemporary and self._path_matches_user_regex(
            path)

    def _path_matches_user_regex(self, path):
        rxs = self.file_regexes
        if len(rxs) == 0:
            filter_fn = lambda x: True
        else:
            filter_fn = lambda x: all(rx.search(x) is not None for rx in rxs)

        return filter_fn(path)
