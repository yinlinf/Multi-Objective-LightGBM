"""
The terrible and effective world of Python metaprogramming.
"""
from __future__ import print_function
from __future__ import absolute_import
import shutil
import errno
import os
import subprocess
import json
import gzip
import six.moves.cPickle as pickle
import numpy as np
import datetime

from functools import partial, wraps

from d_common.iterutils import batch
from .registry import Registry
from .storage import SerialFileStore, ZlibSerializer, PickleSerializer, IdentitySerializer
import six
from io import open


def ensure_dirs(path):
    dname = os.path.dirname(os.path.abspath(path))
    if not os.path.exists(dname):
        os.makedirs(dname)


def EnsureFS(f):
    @wraps(f)
    def _f(self, *args, **kwargs):
        if not os.path.isdir(self.path):
            os.makedirs(self.path)

        return f(self, *args, **kwargs)

    return _f


class FileType(object):
    def load(self, path, *args, **kwargs):
        raise NotImplementedError()

    def save(self, path, payload, *args, **kwargs):
        raise NotImplementedError()

    def exists(self, path):
        return os.path.exists(path)

    def name(self, path):
        return path

    @staticmethod
    def copy(oldPath, newPath):
        shutil.copyfile(oldPath, newPath)


class NamedFileType(FileType):
    def __init__(self, ft, name):
        self.ft = ft
        self.fname = name

    def _path(self, base):
        return os.path.join(base, self.fname)

    def load(self, path, *args, **kwargs):
        return self.ft.load(self._path(path), *args, **kwargs)

    def save(self, path, *args, **kwargs):
        new_path = self._path(path)
        ensure_dirs(new_path)
        return self.ft.save(new_path, *args, **kwargs)

    def exists(self, path, *args, **kwargs):
        return self.ft.exists(self._path(path))

    def name(self, path):
        return self.ft.name(self._path(path))

    def copy(self, oldPath, newPath):
        return self.ft.copy(oldPath, newPath)


def wrapper(ftc):
    def _f(path, *args, **kwargs):
        return NamedFileType(ftc(*args, **kwargs), path)

    return _f


File = Registry(FileType, wrapper)


class FTWrapper(object):
    def __init__(self, f, evaluate=False):
        self.f = f
        self.ev = evaluate

    def __get__(self, inst, inst_cls):
        if self.ev:
            return self.f(inst.path)

        return partial(self.f, inst.path)


class FileSystemMeta(type):
    def __new__(cls, name, bases, attrs):
        fts = []
        ft_set = {}
        for attrName, ft in list(attrs.items()):
            if not isinstance(ft, FileType):
                continue

            # capitalize
            uName = attrName[0].upper() + attrName[1:]
            attrs['load%s' % uName] = FTWrapper(ft.load)
            attrs['save%s' % uName] = FTWrapper(ft.save)
            attrs[attrName] = FTWrapper(ft.name, True)
            fts.append(attrName)
            ft_set[attrName] = ft

        attrs['__copyfields__'] = fts
        attrs['__fieldtypes__'] = ft_set

        return super(FileSystemMeta, cls).__new__(cls, name, bases, attrs)


class FileSystem(six.with_metaclass(FileSystemMeta, object)):
    def __init__(self, path):
        self.path = path

    def __unicode__(self):
        return u'%s[%s]' % (type(self).__name__, self.path)

    __repr__ = __unicode__

    @classmethod
    def copy(cls, from_path, to_path, skip=set()):
        fFS = cls(from_path)
        tFS = cls(to_path)
        for name in cls.__copyfields__:
            if name in skip:
                continue

            from_file, to_file = [getattr(fs, name) for fs in (fFS, tFS)]
            if os.path.exists(from_file):
                ensure_dirs(to_file)
                cls.__fieldtypes__[name].copy(from_file, to_file)
            else:
                raise IOError(errno.ENOENT, 'No such file', from_file)


@File.register('dir')
class DirFT(FileType):
    def load(self, path):
        raise NotImplementedError("Can't load a directory")

    def save(self, path, payload):
        raise NotImplementedError("Can't save a directory")

    def copy(self, oldPath, newPath):
        shutil.copytree(oldPath, newPath)


@File.register('raw')
class RawFT(FileType):
    def load(self, path):
        return open(path, encoding='utf-8').read()

    def save(self, path, payload):
        with open(path, 'w', encoding='utf-8') as out:
            out.write(payload)


@File.register('raw_stream')
class RawStreamFT(FileType):
    def load(self, path):
        with open(path, encoding='utf-8') as f:
            for line in f:
                yield line[:-1]

    def save(self, path, payload):
        with open(path, 'w', encoding='utf-8') as out:
            for line in payload:
                print(six.text_type(line), file=out)


@File.register('gzip')
class GzipFT(FileType):
    def load(self, path):
        return gzip.open(path, 'rb').read()

    def save(self, path, payload):
        with gzip.open(path, 'wb') as out:
            out.write(six.ensure_binary(payload, encoding='utf-8'))


@File.register('gzip_stream')
class GzipSFT(FileType):
    def __init__(self, compress_level=9):
        self.comp_level = compress_level

    def load(self, path):
        with gzip.open(path, 'rb') as f:
            for line in f:
                yield line[:-1]

    def save(self, path, payload):
        with gzip.open(path, 'wb', compresslevel=self.comp_level) as out:
            for data in payload:
                # gzip.open in python2 can only open in binary mode;
                # gzip.open in python3 can open in both binary and text mode, taking
                # bytes and str in each of those respectively.
                # To make this compatible with both, we gzip.open in binary mode;
                # that means that we cannot use python 3's print function, as that expects
                # a text stream. Instead, lines are writtend via the file object directly,
                # encoded via utf-8 if needed, with a newline added (like what print would do).
                out.write(six.ensure_binary(data, encoding='utf-8') + b"\n")


@File.register('json')
class JsonFT(FileType):
    def load(self, path):
        with open(path) as f:
            return json.load(f)

    def save(self, path, payload):
        with open(path, 'w', encoding='utf-8') as out:
            out.write(six.text_type(json.dumps(payload)))


@File.register('json_stream')
class JsonSFT(FileType):
    def load(self, path):
        with open(path) as f:
            for line in f:
                yield json.loads(line)

    def save(self, path, payload):
        with open(path, 'w') as out:
            for data in payload:
                print(json.dumps(data), file=out)


@File.register('pickle')
class PickleFT(FileType):
    def load(self, path):
        with open(path, 'rb') as f:
            return pickle.load(f)

    def save(self, path, payload):
        with open(path, 'wb') as out:
            return pickle.dump(payload, out, pickle.HIGHEST_PROTOCOL)


@File.register('numpy')
class NumpyFT(FileType):
    def __init__(self, compressed=True):
        self.comp = compressed

    def load(self, path, *names):
        with open(path) as f:
            z = numpy.load(f)
            if not names or self.comp:
                return z

            try:
                d = {n: z[n] for n in names}
            finally:
                z.close()

            return d

    def save(self, path, payload):
        with open(path, 'w') as out:
            if self.comp:
                assert isinstance(payload, dict), \
                        "compressed numpy requires a dictionary"
                return np.savez_compressed(out, **payload)

            return np.save(out, payload)


@File.register('record_stream')
class RecordSFT(FileType):
    def __init__(self, compress_level=9, isString=False, proc=False):
        self.compress_level = compress_level
        self.isString = isString
        self.proc = proc

    def sfs(self, path, mode):
        s = IdentitySerializer() if self.isString else PickleSerializer()

        # We handle the case where we want to fork out a proc
        if self.proc and mode == 'w':
            inf = open(path, mode)
            proc = subprocess.Popen(
                ['gzip', '-%s' % self.compress_level],
                bufsize=4096 * 4096,
                stdin=subprocess.PIPE,
                stdout=inf)

            sfs = SerialFileStore(proc.stdin, s)
            sfs.proc = proc
            sfs.inf = inf

            return sfs

        else:
            f = gzip.open(path, mode, self.compress_level)

        return SerialFileStore(f, s)

    def load(self, path):
        with self.sfs(path, 'r').reader() as reader:
            for record in reader:
                yield record

    def save(self, path, payload):
        sfs = self.sfs(path, 'w')
        with sfs as r:
            for record in payload:
                r.add(record)

        if self.proc:
            sfs.proc.wait()
            sfs.inf.close()


# Conveniences
@property
@EnsureFS
def testFeatures(self):
    return self.features + '.test'


@property
@EnsureFS
def trainFeatures(self):
    return self.features + '.train'


@EnsureFS
def getLogFile(self, prefix):
    t = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    return os.path.join(self.path, "%s-%s.log" % (prefix, t))
