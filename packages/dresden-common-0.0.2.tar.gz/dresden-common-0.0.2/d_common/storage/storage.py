from __future__ import absolute_import
import mmap
import os
from six.moves import range

from contextlib import closing
import struct
import six.moves.cPickle as P
import zlib

import numpy as np

from d_common.iterutils import unfold
import six
from six.moves import zip


class StreamStore(object):
    def __enter__(self):
        self.open()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def open(self):
        raise NotImplementedError()

    def add(self, feature):
        raise NotImplementedError()

    @classmethod
    def merge(cls, infs, tof):
        raise NotImplementedError()

    def close(self):
        raise NotImplementedError()


class RecordWriter(object):
    def __init__(self, filename):
        if isinstance(filename, six.string_types):
            self.f = open(filename, 'w')
        else:
            self.f = filename

    def write(self, record):
        rLen = struct.pack('I', len(record))
        self.f.write(rLen)
        self.f.write(record)

    def close(self):
        self.f.close()

    @classmethod
    def merge(cls, infs, tof):
        with open(tof, 'w') as out:
            for inf in infs:
                with open(inf) as f:
                    while True:
                        data = f.read(4096)
                        if data:
                            out.write(data)
                        else:
                            break


class RecordReader(object):

    _headerSize = struct.calcsize('I')
    _locs = None
    _f = None

    def __init__(self, filename, use_mmap=True):
        if isinstance(filename, six.string_types):
            self.f = open(filename, buffering=4096 * 4096)

            self.use_mmap = use_mmap
            if self.use_mmap and isinstance(self.f.fileno(), int):
                self._f = self.f
                self.f = mmap.mmap(self.f.fileno(), 0, prot=mmap.PROT_READ)
        else:
            self.f = filename
            self.use_mmap = False

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def _readHeader(self):
        h = self.f.read(self._headerSize)
        if len(h) != self._headerSize:
            return None

        size, = struct.unpack('I', h)
        return size

    def _read(self, size):
        return self.f.read(size)

    def _read_record(self):
        size = self._readHeader()
        if size is None:
            return size, ''

        return size, self._read(size)

    def read(self):
        return self._read_record()[1]

    def __iter__(self):
        self.f.seek(0)

        records = unfold(self._read_record, lambda x: x[0] is not None)
        for _, record in records:
            yield record

    def close(self):
        self.f.close()
        if self.use_mmap:
            self._f.close()

    @property
    def locs(self):
        if self._locs is None:
            cur_pos = self.f.tell()
            self.f.seek(0)
            locs = []
            while True:
                size = self._readHeader()
                if size is None:
                    break

                locs.append((self.f.tell(), size))
                self.f.seek(size, os.SEEK_CUR)

            self.f.seek(cur_pos)
            self._locs = locs

        return self._locs

    def __getitem__(self, idx):
        loc, size = self.locs[idx]
        self.f.seek(loc)
        return self._read(size)

    def __len__(self):
        return len(self.locs)

    def __unicode__(self):
        return u'RandomRR[%s]' % self.f.name


class SerializedRR(RecordReader):
    def __init__(self, filename, serializer):
        super(SerializedRR, self).__init__(filename)
        self.serializer = serializer

    def _read(self, size):
        d = super(SerializedRR, self)._read(size)
        return self.serializer.loads(d)


class SerialFileStore(StreamStore):
    def __init__(self, filename, serializer):
        self.filename = filename
        self.serializer = serializer

    def open(self):
        self.rw = RecordWriter(self.filename)

    def add(self, document):
        self.rw.write(self.serializer.dumps(document))

    def close(self):
        self.rw.close()

    def stream(self):
        return iter(self.reader())

    def reader(self):
        return SerializedRR(self.filename, self.serializer)

    @classmethod
    def merge(cls, infs, ofs):
        RecordWriter.merge(infs, ofs)


class CompositeRandomRecordReader(object):
    def __init__(self, rrrs):
        self.rrrs = rrrs

    def __len__(self):
        return len(self.rrrs[0])

    def __getitem__(self, idx):
        return self.__getattr__('__getitem__')(idx)

    def __getattr__(self, k):
        f = lambda *a, **kws: tuple(getattr(r, k)(*a, **kws) for r in self.rrrs)
        return f


class CompositeSerialFileSystem(StreamStore):
    def __init__(self, filename, serializer, num_channels=None):
        self.filename, self.serializer = filename, serializer

        # Read from disk
        if num_channels is None:
            num_channels = self._readChannels(filename)

        self.num_channels = num_channels

    @property
    def names(self):
        return self._genNames(self.filename, self.num_channels)

    @staticmethod
    def _channelFile(fn):
        return fn + '._'

    @staticmethod
    def _genNames(filename, num_channels):
        for i in range(num_channels):
            yield '%s.%s' % (filename, i)

    @classmethod
    def _readChannels(cls, filename):
        with open(cls._channelFile(filename)) as f:
            return int(f.read())

    @classmethod
    def _writeChannels(cls, filename, num_channels):
        with open(cls._channelFile(filename), 'w') as f:
            f.write(str(num_channels))

    def open(self):
        self.rws = []
        for n in self.names:
            sfs = SerialFileStore(n, self.serializer)
            sfs.open()
            self.rws.append(sfs)

    def add(self, document):
        assert len(document) == self.num_channels
        for rw, d in zip(self.rws, document):
            rw.add(d)

    def close(self):
        for rw in self.rws:
            rw.close()

        self._writeChannels(self.filename, self.num_channels)

    def stream(self):
        rrs = [SerialFileStore(n, self.serializer) for n in self.names]
        for c in zip(*(rr.stream() for rr in rrs)):
            yield c

    @classmethod
    def merge(cls, infs, tof):
        # One channel at a time
        nc = cls._readChannels(infs[0])
        onames = cls._genNames(tof, nc)
        inames = zip(*(cls._genNames(f, nc) for f in infs))
        for cnames, of in zip(inames, onames):
            SerialFileStore.merge(cnames, of)

        cls._writeChannels(tof, nc)

    @classmethod
    def purge(cls, fn):
        nc = cls._readChannels(fn)
        for name in cls._genNames(fn, nc):
            os.unlink(name)

        os.unlink(cls._channelFile(fn))

    def reader(self):
        return CompositeRandomRecordReader(self.readers())

    def readers(self):
        return [
            SerialFileStore(n, self.serializer).reader() for n in self.names
        ]


class NumpyFileSystem(StreamStore):
    def __init__(self, filename, num_channels=None, prefix='c'):
        self.filename = filename
        self.num_channels = num_channels
        self.prefix = prefix

    def open(self):
        assert self.num_channels is not None, \
                "num_channels cannot be None when writing"
        self.channels = [[] for _ in range(self.num_channels)]

    def add(self, document):
        assert len(document) == self.num_channels
        for d, c in zip(document, self.channels):
            c.append(d)

    def _names(self, n):
        if n == 1:
            return (self.prefix, )

        return ('%s_%s' % (self.prefix, i) for i in range(n))

    def close(self):
        data = {
            n: np.vstack(d)
            for n, d in zip(self._names(self.num_channels), self.channels)
        }

        data['_'] = self.num_channels
        np.savez_compressed(self.filename, **data)

    def raw(self):
        with open(self.filename + '.npz') as f:
            data_z = np.load(f)
            cs = [data_z[n] for n in self._names(data_z['_'])]

        return cs

    def stream(self):
        for d in zip(*self.raw()):
            yield d

    def readers(self):
        return self.raw()


class RecordSerializer(object):
    def dumps(self, record):
        raise NotImplementedError()

    def loads(self, data):
        raise NotImplementedError()


class IdentitySerializer(object):
    def dumps(self, record):
        return record

    def loads(self, data):
        return data


class PickleSerializer(RecordSerializer):
    def dumps(self, s):
        return P.dumps(s, P.HIGHEST_PROTOCOL)

    def loads(self, s):
        return P.loads(s)


class ZlibSerializer(RecordSerializer):
    def __init__(self, complevel=9, converter=PickleSerializer()):
        self.complevel = complevel
        self.converter = converter

    def dumps(self, s):
        raw = self.converter.dumps(s)
        return zlib.compress(raw, self.complevel)

    def loads(self, data):
        raw = zlib.decompress(data)
        return self.converter.loads(raw)
