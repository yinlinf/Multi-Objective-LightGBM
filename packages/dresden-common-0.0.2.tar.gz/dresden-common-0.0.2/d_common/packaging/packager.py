from __future__ import absolute_import
import sys
import os
import json
import re
import shutil
import subprocess
import hashlib
import datetime
import logging
from io import open

import six

from d_common.application.schema import Schema
from d_common.application.fixture import Fixture
from d_common.packaging.repository import Version, GcsRepository
from d_common.logger import setupLogging
from d_common.utils import class_loader
from six.moves import map
from six.moves import input
import tarfile
import shutil
import tempfile
"""
Ensemble Schema Example

schema = {
    "models": {
        "vw": {
            "interface": "d_vw.interfaces:VWRanker",
            "path": {
                'gcs': {
                    'bucket': 'etsy-mlinfra-prod-trained-models-tb26',
                    'path': '/data/shared/dresden/models',
                    'model': 'csr-dresden-prod_csr_gms_shop_stats_pyspark_prelim_v1-package'
                }
            },
          "packager": "d_vw.interfaces:Packager",
          "opts": {
            "extra_flags": {
              "sort_features": "true"
            }
          }
        },
        "lgbm": {
          "interface": "d_lgbm.interfaces:Ranker",
          "path": "lgbm"
          },
          "packager": "d_lgbm.interfaces:Packager",
          "opts": {}
        }
      }
"""


def package(args, should_log=True):
    if should_log:
        setupLogging()

    repository = load_repository(args)
    version = build_version(repository, args.name, args.version)
    model_name = get_file_name(version)
    output = create_output_directory(args, model_name)
    repository.output_dir = output

    schema = copy_schema(args, output)
    dir_hash = hash_models(output)
    logging.info("Generating new schema with dir hash")
    update_schema(schema, version, dir_hash, args.comment)
    schema = save_schema(schema, output)

    # Attach model config to output directory
    if os.environ.get('ETSY_LIBRARIES'):
        logging.info("Attaching model runtime config")
        create_model_config(os.environ['ETSY_LIBRARIES'], output)

    if args.fixture_input_path or args.raw_fixture_input_path:
        logging.info("Generating fixtures...")
        process_fixtures(schema, args.fixture_input_path,
                         args.raw_fixture_input_path)

    repository.upload(version, output)


def unpack_gcs_models(model_local_path, blob_name, output):
    """
    Unpack downloaded gcs models from local path
    :param model_local_path: str
    :param blob_name: str gcs object
    :param output: str output directory
    :return: None
    """
    tempdir, model = model_local_path.rsplit('/', 1)
    logging.info("extracting {}".format(model))

    tf = tarfile.open(model_local_path)
    tf.extractall(path=tempdir)

    logging.info("moving extracted model {} to output dir".format(model))
    # fetch the package name from the gcs object name
    # example :
    #    /data/shared/dresden/models/csr-dresden-loc_domestic_shop_stats_pyspark-package-0.1.tar.gz ->
    #    csr-dresden-loc_domestic_shop_stats_pyspark-package-0.1
    extract_path = '{}/tmp/{}/{}'.format(tempdir,
                                         blob_name.rsplit('.', 2)[0].rsplit(
                                             '/', 1)[1], model)
    shutil.move(extract_path, output)


def copy_models_from_gcs(args, model, model_path, output):
    """
    download and extract model from gcs to output directory
    :param model: str model name
    :param model_path: dict input path of model
    :param output: str
    :return: None
    """
    bucket_name = json.loads(args.repository[1]).get('bucket')
    repo = GcsRepository(bucket_name, model_path['path'])
    gcs_uri = repo.get_gcs_full_path(model_path)

    logging.info("downloading model {} from gcs".format(model))
    _, blob_name = gcs_uri[5:].split('/', 1)

    tempdir = tempfile.mkdtemp()
    try:
        model_local_path = '{}/{}'.format(tempdir, model)
        repo.download(blob_name, model_local_path)
        unpack_gcs_models(model_local_path, blob_name, output)
    finally:
        shutil.rmtree(tempdir)


def copy_models(args, schema, output):
    """
    Copy model as per schema into output location.
    :param args: dict input arguments
    :parama schema: schema object
    :param output: str output directory
    :return meta: dict model metadata
    """
    meta = {}

    # Copy the model to the new modelset dir
    for model_name, pkg_cls, model_path in schema.packagers():
        output_path = os.path.join(output, model_name)

        if isinstance(model_path, dict) and model_path.get('gcs'):
            copy_models_from_gcs(args, model_name, model_path['gcs'],
                                 output_path)
        else:
            pkg_cls.copy(model_path, output_path)

        # Grab metadata from the model
        meta[model_name] = pkg_cls.extract_meta(output_path)

        # Update schema's model path to point to new location
        schema.models[model_name]['path'] = model_name

    return meta


def copy_application(schema, output):
    entrypoint = schema.app['entrypoint']
    e_type = entrypoint['type']

    # If it's a file, we need to copy it to the schema directory.
    if e_type == 'file':
        path, cls = entrypoint['path'].split(':')
        new_path = os.path.join(output, 'application.py')
        shutil.copyfile(path, new_path)
        entrypoint['path'] = 'application.py:{}'.format(cls)


def prepare_schema_with_overrides(args, schema):
    """
    prepares schema with overrides
    :param args:dict input arguments
    :return None
    """
    if hasattr(args, 'override_gcs_model_paths'
               ) and args.override_gcs_model_paths is not None:

        logging.info("overriding model path to gcs in schema")
        schema.override_gcs_path_in_schema(args.override_gcs_model_paths)
        with open(args.schema, 'w') as f:
            json.dump(schema.dump(), f)

    if hasattr(args, 'override_local_model_paths'
               ) and args.override_local_model_paths is not None:

        logging.info("overriding model path to local in schema")
        schema.override_local_path_in_schema(args.override_local_model_paths)
        with open(args.schema, 'w') as f:
            json.dump(schema.dump(), f)


def copy_schema(args, output):
    """
    creates schema object from the path and prepare model, apps as per schema
    :param args: dict input arguments
    :param output: str output directory
    :return schema object
    """
    schema = Schema(args.schema)
    schema.validate_schema_file()

    prepare_schema_with_overrides(args, schema)

    meta = copy_models(args, schema, output)

    # Update the metadata from the models
    schema.meta = schema.meta if schema.meta is not None else {}
    for model_name, details in six.iteritems(meta):
        for meta_name, value in six.iteritems(details):
            meta_key = '{}:{}'.format(model_name, meta_name)
            schema.meta[meta_key] = value

    # Copy application
    copy_application(schema, output)

    return schema


def save_schema(schema, output):
    new_schema = os.path.join(output, 'schema.json')
    with open(new_schema, 'w', encoding='utf-8') as out:
        data = schema.dump()
        # Python2's json produces a generic `str` type, while
        # Python3's json always returns a unicode str.
        # To handle that and ensure proper encoding in the ouutput file
        # 1. we open the file with encoding=utf-8, ensuring that it will
        # require a unicode object (unicode in py2, str in py3)
        # 2. beause json.dump behaves differently/has different parameters,
        # first we fully dump it to a string object, which is then transformed
        # to the appropriate unicode type by six.text_type.
        # TODO: Once we are running on Python 3 this should be just:
        # json.dump(data, out)
        out.write(six.text_type(json.dumps(data)))
    return Schema(os.path.join(output, 'schema.json'))


def hash_models(output):
    """
    Hash the models for consistency.
    """
    logging.info("Hashing models...")
    md5 = hashlib.md5()
    for curDir, dirs, files in os.walk(output):
        for fname in files:
            with open(os.path.join(curDir, fname), "rb") as f:
                md5.update(f.read())

    hexdigest = md5.hexdigest()
    logging.info("Model hash is: %s" % hexdigest)
    return hexdigest


def update_schema(schema, version, model_hash, comment):
    now = datetime.datetime.utcnow()

    meta = {
        "modelset-version": str(version),
        "modelset-hash": model_hash,
        "package-date": now.strftime('%Y/%m/%d %H:%M')
    }

    if comment is not None:
        meta["comment"] = comment

    schema.meta.update(meta)


def get_current_version(repository, namespace):
    versions = list(repository.list(namespace))
    if versions:
        return max(versions)

    return None


VALID_VERSION_RX = re.compile('^\d+\.\d+$')


def input_version(default, rel_type):
    version = None
    while version is None:
        version = input("`%s` version [Default: %s]: " % (rel_type, default))
        if not version:
            version = default

        if VALID_VERSION_RX.match(version) is None:
            logging.error("Invalid version number: %s", version)
            version = None

    return version


def build_version(repository, name, version):
    if version == "next":
        version = get_current_version(repository, name)
        if version is None:
            version = Version(name, 0, 0)
        version = version.next_version()
    else:
        major, minor = version.split('.')
        version = Version(name, int(major), int(minor))

    return version


def create_model_config(etsy_libraries, output):
    output_config_path = os.path.join(output, "model_runtime_config.json")

    libraries = list(map(str.strip, etsy_libraries.split(',')))
    json_data = {
        name + '_version': version
        for name, version in [l.split('==') for l in libraries]
    }

    write_model_config(json_data, output_config_path)


def write_model_config(json_data, output_path):
    # Python2's json produces a generic `str` type, while
    # Python3's json always returns a unicode str.
    # To handle that and ensure proper encoding in the ouutput file
    # 1. we open the file with encoding=utf-8, ensuring that it will
    # require a unicode object (unicode in py2, str in py3)
    # 2. beause json.dump behaves differently/has different parameters,
    # first we fully dump it to a string object, which is then transformed
    # to the appropriate unicode type by six.text_type.
    # TODO: Once we are running on Python 3 this should be just:
    # json.dump(data, out)
    with open(output_path, 'w', encoding="utf-8") as f:
        f.write(six.text_type(json.dumps(json_data)))


def get_file_name(version):
    return '{}-{}.{}'.format(version.name, version.major, version.minor)


def process_fixtures(schema, fixture_path, raw_fixture_path):
    fix_out = schema.get_fixture_path()

    # Build the expected results
    if fixture_path:
        app = schema.load_application()
        Fixture.generate(app, fixture_path, fix_out)

        # Test it
        Fixture.test(app, fix_out)
    elif raw_fixture_path:
        shutil.copyfile(raw_fixture_path, fix_out)
    else:
        raise RuntimeError(
            "One of `fixture_path` or `raw_fixture_path` must be provided.")


def create_output_directory(args, model_name):
    output = os.path.join(args.tmpDir, model_name)
    if os.path.exists(output):
        shutil.rmtree(output)
    logging.info("Making directory %s" % output)
    os.mkdir(output)
    return output


def load_repository(args):
    rep_cls = class_loader(args.repository[0])
    args_for_constructor = json.loads(args.repository[1])
    args_for_constructor['destination_path'] = args.destination_path
    repository = rep_cls(**args_for_constructor)
    return repository
