from __future__ import print_function
from __future__ import absolute_import
import shutil
import os
import re
import sys
import logging
import subprocess

import pywebhdfs.webhdfs
from google.cloud import storage
from google.cloud.exceptions import GoogleCloudError
from six.moves import map
from six.moves import range

GCS_RETRY_COUNT = 5


class Version(object):
    """
    Describes a version of a modelset.  Contains the model name, major,
    and minor version.
    """

    def __init__(self, name, major, minor):
        self.name = name
        self.major = major
        self.minor = minor

    def __eq__(self, other):
        return self.name == other.name and \
               self.major == other.major and \
               self.minor == other.minor

    def __ne__(self, other):
        return not (self == other)

    def __lt__(self, other):
        if self.major < other.major:
            return True

        elif self.major == other.major and self.minor < other.minor:
            return True

        return None

    def __str__(self):
        return '{}-{}.{}'.format(self.name, self.major, self.minor)

    def next_version(self):
        return Version(self.name, self.major, self.minor + 1)


class Repository(object):
    """
    A Repository is a place the stores models.  Right now, only two methods
    are implemented: getting versions for a model name and uploading a model
    to the repository.
    """

    def list(self, name):
        """
        Lists all models in a given repository with the provided name.

        Params
        ------
        @param name: str - Name of the model
        @rtype: list of Versions
        """
        raise NotImplementedError()

    def upload(self, version, path, compress=True):
        """
        Uploads a model to the repository.

        Params
        ------
        @param version: Version - Version of the model
        @param path: path - /path/to/model.tar.gz
        @param compress: Whether to compress the model before uploading or not
        @rtype: None
        """
        raise NotImplementedError()

    def get_base_name(self, version, suffix=".tar.gz"):
        return '{}-{}.{}{}'.format(version.name, version.major, version.minor,
                                   suffix)

    def _compress_file(self, output, cleanup):
        """
        Compresses a file/directory (i.e. before being uploaded)

        Params
        ------
        @param cleanup: If true, removes the source after compressing
        @rtype: str - Name of the compressed file
        """
        logging.info("Compressing...")
        filename = "%s.tar.gz" % output
        return_code = subprocess.call(['tar', 'cvzf', filename, output])
        if return_code == 0:
            if cleanup:
                shutil.rmtree(output)
            else:
                logging.info("Cleanup disabled for the repository object.")
        else:
            logging.error("Unable to tar.gz file!")
            raise IOError("Unable to tar.gz file!")
        return filename


class FileRepository(Repository):
    """
    Example usage:
    dresden-package.py "/repo/projects/listing-price-codelab-kgaan/schema.json"
    --name listing-price-codelab --version next
    --repository d_common.packaging.repository:FileRepository
    '{"path":"/codelab"}' --destination-path /codelab --comment
    "This is a demonstration" --auto-overwrite --retries 10
    """

    def __init__(self, path, destination_path):
        #destination_path is just provided to maintain consistency
        assert os.path.isdir(path)

        self.path = path
        self.cleanup = True

    def get_dir(self, name):
        return os.path.join(self.path, name)

    def list(self, name):
        name_dir = self.get_dir(name)
        versions = []
        if os.path.isdir(name_dir):
            for fname in os.listdir(name_dir):
                # split out
                if '.tar.gz' in fname:
                    fname = fname.rsplit('.', 2)[0]
                model_name, version = fname.rsplit('-', 1)
                major, minor = list(map(int, version.split('.')))
                versions.append(Version(model_name, major, minor))

        return versions

    def upload(self, version, path, compress=True):
        base_dir = os.path.join(self.path, version.name)
        if not os.path.isdir(base_dir):
            os.makedirs(base_dir)

        if compress:
            path = self._compress_file(path, self.cleanup)

        model = os.path.basename(path)
        dest = os.path.join(base_dir, model)
        if os.path.exists(dest):
            raise OSError("Model already exists: {}".format(dest))

        if compress:
            # Copy the single, compressed file
            shutil.copy(path, dest)
        else:
            # Copy the entire model directory
            shutil.copytree(path, dest)


class GcsRepository(Repository):
    """
    Models in the GCS repository can either be stored as:
        - model_name/model_name-major.minor.tar.gz (compressed)
        - model_name/model_name-major.minor/ (uncompressed)

    Example usage:
    dresden-package.py "/repo/projects/listing-price-codelab-kgaan/schema.json"
    --name listing-price-codelab --version next
    --repository d_common.packaging.repository:GcsRepository
    '{"bucket":"test-hmeena"}' --destination-path /codelab
    --comment "This is a demonstration" --auto-overwrite --retries 10
    """

    def __init__(self, bucket, destination_path):
        self.path = destination_path.lstrip('/')
        self.bucket = storage.Client().get_bucket(bucket)
        self.bucket_name = bucket
        self.cleanup = True

    def list(self, name):
        blobs = self.bucket.list_blobs(
            prefix=(self.path + '/%s/' % name), delimiter='/')

        # Gather all model versions together (compressed and uncompressed)
        models = set()
        for page in blobs.pages:
            # Prefixes for a given page contain the "directory" names (i.e.
            # the uncompressed models)
            models.update(page.prefixes)
            for blob in page:
                # This adds in the compressed models
                models.add(blob.name)

        # Filter out all files that don't match the expected format
        rx = re.compile(name + r'/((?:\w+-)*\w+)-(\d+)\.(\d+).*$')
        versions = []
        for model in models:
            match = re.search(rx, model)
            if match is not None:
                name, major, minor = match.groups()[:3]
                versions.append(Version(name, int(major), int(minor)))

        return versions

    def _upload_file(self, version, path):
        """Upload a single file to GCS."""
        file_name = self.get_base_name(version)
        full_path = os.path.join(self.path, version.name, file_name)
        if '//' in full_path:
            raise OSError(
                'Invalid output gcs path %s found with //.' % full_path)

        if version in self.list(version.name):
            raise OSError("Model already exists: {}".format(full_path))

        for attempt_number in range(GCS_RETRY_COUNT):
            try:
                self.bucket.blob(full_path).upload_from_filename(path)
                return
            except GoogleCloudError as e:
                print(e, file=sys.stderr)

        raise OSError("Failed to upload after %s retries" % GCS_RETRY_COUNT)

    def _upload_directory(self, version, path):
        """
        Upload a directory to GCS. Note that as of now (2020-07-22), the GCP
        API for Python does not support uploading entire directories, so this
        function employs a system call with gsutil to accomplish this task.
        """
        folder_name = self.get_base_name(version, suffix='')
        relative_path = os.path.join(self.path, version.name, folder_name)
        full_path = self.create_full_path(
            prefix='gs://',
            suffix='',
            delimiter='/',
            directory_paths=(self.bucket_name, self.path, version.name,
                             folder_name)
        )

        if '//' in relative_path:
            raise OSError(
                'Invalid output gcs path %s found with //.' % relative_path)

        if version in self.list(version.name):
            raise OSError("Model already exists: {}".format(full_path))

        for attempt_number in range(GCS_RETRY_COUNT):
            subprocess_command = ['gsutil', '-m', 'cp', '-r', path, full_path]
            return_code = subprocess.call(subprocess_command)
            if return_code != 0:
                logging.error('Uploading to GCS returned code %s' % return_code)
            else:
                return

        raise OSError('Failed to copy directory to GCS after %s retries' %
                      GCS_RETRY_COUNT)

    def upload(self, version, path, compress=True):
        """
        Upload a model to GCS.
        :param version: The version of the model, as a Version object
        :param path: The local path to the model
        :param compress: If True, compresses the model before uploading to GCS
        :return: None
        """
        if compress:
            path = self._compress_file(path, self.cleanup)
            self._upload_file(version, path)
        else:
            self._upload_directory(version, path)

    def download(self, blob_name, output_path):
        """
        download object from gcs
        :param blob_name: gcs object to download
        :param output_path: str
        :return: None
        """

        for attempt_number in range(GCS_RETRY_COUNT):
            try:
                self.bucket.blob(blob_name).download_to_filename(output_path)
                return
            except GoogleCloudError as e:
                print(e, file=sys.stderr)

        raise OSError("Failed to download after %s retries" % GCS_RETRY_COUNT)

    def get_latest_version(self, model):
        """
        It retrieves the name of the latest model version from gcs
        :param model: str, Name of the model (csr-dresden-prod_fixed_hp-package)
        :return: Version object -> str(Version)=(csr-dresden-prod_fixed_hp-package-0.131)
        """
        versions = self.list(model)
        return max(versions)

    def create_full_path(self, prefix, suffix, delimiter, directory_paths):
        """
        It creates gcs path to the object
        :param prefix: str
        :param suffix: str
        :param delimiter: str
        :param directory_paths: tuple of str; joins all paths with delimiter in same order
        :return: str
        """

        path = prefix + delimiter.join(
            [path.strip('/') for path in directory_paths]) + suffix
        return path

    def get_gcs_full_path(self, path):
        """
        It creates gcs path to the object from dict
        :param path: dict with
            'bucket': str bucket_name,
            'path': str directory_path,
            'model': str model_namespace
        :return: str gcs uri
        """
        version = self.get_latest_version(path['model'])
        return self.create_full_path(
            prefix='gs://',
            suffix=".tar.gz",
            delimiter="/",
            directory_paths=(path['bucket'], path['path'], path['model'],
                             str(version)))


class FilestoreRepository(GcsRepository):
    """
    We assume two types of structure
    - model_name/model_name-major.minor for gcs models
    - model_name/model_name-major.minor for models mounted on filestore.

    Example usage:
    dresden-package.py "/repo/projects/listing-price-codelab-kgaan/schema.json"
    --name listing-price-codelab --version next
    --repository d_common.packaging.repository:FilestoreRepository
    '{"bucket":"test-hmeena", "filestore_prefix":"/filestore"}'
    --destination-path /codelab --comment "This is a demonstration"
    --auto-overwrite --retries 10
    """

    def __init__(self, bucket, destination_path, filestore_prefix):
        super(FilestoreRepository, self).__init__(bucket, destination_path)
        self.filestore_prefix = filestore_prefix

        # disabled cleanup will help with direct access to untarred model
        self.cleanup = False

    def upload(self, version, path, compress=True):
        """
        upload object to gcs and filestore
        :param version: model verion object
        :param path: location on gcs for upload
        :param compress: Whether to compress the model before uploading or not.
                         This applies to both GCS and Filestore.
        :return: None
        """
        if not os.path.exists(self.filestore_prefix):
            raise IOError("Filestore instance is not mounted at %s",
                          self.filestore_prefix)

        super(FilestoreRepository, self).upload(version, path, compress)
        full_path = os.path.join(self.filestore_prefix, self.path, version.name)
        model_name = self.get_base_name(version, suffix="")
        self.copy_to_mounted_filestore_location(path, full_path, model_name, False)
        logging.info("Model uploaded to filestore location %s",
                     os.path.join(full_path, model_name))

    def copy_to_mounted_filestore_location(self, model_source, filestore_dest,
                                           model_name, compress):
        """
        copies/moves model to filestore location
        :param model_source: tarred model location locally.
        :param filestore_dest: filestore location to copy the model.
        :param model_name: name of model (with version)
        :param compress: Whether to compress the model before copying or not
        :return: None
        """
        # check if a model-x.y exist at *DEST*, to avoid overrides.
        versioned_filestore_dest = os.path.join(filestore_dest, model_name)
        if os.path.exists(versioned_filestore_dest):
            err_msg = "Model %s already exist on filestore location : %s"\
                      % (model_name, versioned_filestore_dest)
            raise IOError(err_msg)

        os.makedirs(filestore_dest, exist_ok=True)
        if compress:
            # Optionally compress the model before copying to Filestore
            model_source = self._compress_file(model_source, self.cleanup)

        shutil.move(model_source, filestore_dest)
