"""
Module for additional iterator utilities
"""
from __future__ import absolute_import
import random
from itertools import islice
from functools import wraps
from collections import Iterator, deque
from six.moves import zip
from six.moves import range


def require_iter(f):
    @wraps(f)
    def _f(it, *args, **kwargs):
        if not isinstance(it, Iterator):
            it = iter(it)

        return f(it, *args, **kwargs)

    return _f


@require_iter
def unique(it, key=lambda x: x):
    seen = set()
    for i in it:
        k = key(i)
        if k not in seen:
            yield i
            seen.add(k)


@require_iter
def group_with(it, key=lambda x: x):
    items = {}
    for i in it:
        k = key(i)
        try:
            items[k].append(i)
        except KeyError:
            items[k] = [i]

    return items


@require_iter
def batch(it, size):
    _batch = lambda: list(islice(it, size))
    data = _batch()
    while data:
        yield data
        data = _batch()

@require_iter
def batch_with(it, batch_id_func):
    """
    :param it: An iterator
    :param batch_id_func: Function which takes an item from the iterator and extracts a grouping ID
    :return: An iterator which batches successive items together by their group ID, creating new batches
        when there is a switch in group ID

    Example:
        >>> print(list(batch_with([(1,4),(1,5),(2,5),(3,2),(3,5)], lambda tup:tup[0])))
        [[(1,4), (1,5)], [(2,5)], [(3,2), (3,5)]]
    """
    last_id = None
    batch = []
    for x in it:
        x_id = batch_id_func(x)
        if x_id != last_id and last_id is not None:
            yield batch
            batch = []
        batch.append(x)
        last_id = x_id

    if len(batch)>0:
        yield batch


@require_iter
def sliding(it, window):
    x = deque(islice(it, window))
    try:
        if len(x) == window:
            while True:
                yield list(x)
                x.append(next(it))
                x.popleft()

    except StopIteration:
        pass


@require_iter
def exhaust(it):
    for _ in it:
        pass


@require_iter
def unpeek(it, item):
    yield item
    for i in it:
        yield i


@require_iter
def peek(it, sentinel):
    for item in it:
        return item, unpeek(it, item)

    return sentinel, iter(())


@require_iter
def has_next(it):
    sentinel = object()
    item, it2 = peek(it, sentinel)
    return (item is not sentinel), it2


@require_iter
def ibatch(it, batch_size):
    sent = object()

    def f():
        sit = islice(it, batch_size)
        fitem = next(sit, sent)
        return fitem, sit

    fitem, sit = f()
    while fitem is not sent:
        yield unpeek(sit, fitem)
        exhaust(sit)
        fitem, sit = f()


@require_iter
def shuffle(it, buckets, seed=None):
    "Resevoir shuffling"
    rand = random.Random(seed)
    xs = list(islice(it, buckets))
    tb = buckets - 1
    if len(xs) == buckets:
        for item in it:
            idx = rand.randint(0, tb)
            yield xs[idx]
            xs[idx] = item

    rand.shuffle(xs)
    for x in xs:
        yield x


@require_iter
def sample(it, N, seed=None):
    """
    Resevoir sampling
    """
    for item, keep in sample_split(it, N, seed):
        if keep:
            yield item


def sample_split(it, N, seed=None):
    """
    """
    rand = random.Random(seed)

    bins = list(islice(it, N))

    count = len(bins)
    for item in it:
        count += 1
        r = rand.randint(0, count)
        if r < N:
            yield bins[r], False
            bins[r] = item
        else:
            yield item, False

    for item in bins:
        yield item, True


def round_robin(*iters):
    """
    Round robin read over all the iterators in the set
    """
    iters = list(iters)
    while iters:
        niters = []
        for it in iters:
            try:
                yield next(it)
            except StopIteration:
                pass
            else:
                niters.append(it)

        iters = niters


def merge2(a, b, cmp, sent=object()):

    lt = next(a, sent)
    if lt is sent:
        for x in b:
            yield x
    else:
        done = False
        while not done:
            for i2 in b:
                if cmp(i2, lt) <= 0:
                    yield i2
                else:
                    yield lt
                    lt = i2
                    a, b = b, a
                    break
            else:
                yield lt
                for i1 in a:
                    yield i1

                done = True


def merge(its, cmp):
    xs = [iter(s) for s in its]
    while len(xs) > 1:
        nxs = []
        for i in range((len(xs) / 2)):
            nxs.append(merge2(xs[i * 2], xs[i * 2 + 1], cmp))

        if len(xs) % 2 == 1:
            nxs.append(xs[-1])

        xs = nxs

    return xs[0] if xs else xs


@require_iter
def identical(it):
    try:
        first = next(it)
    except StopIteration:
        return True

    return all(item == first for item in it)


def unfold(data_f, check_f):
    """
    While check_f(x) is true, yield out data_f.  Stop when it's false
    """
    data = data_f()
    while check_f(data):
        yield data
        data = data_f()


@require_iter
def dsu_sort(it, key, reverse=False):
    """
    Uses decorate, sort, undecorate sorting paradigm
    """
    keys = []
    items = []
    for i, item in enumerate(it):
        keys.append((key(item), i))
        items.append(item)

    keys.sort(reverse=reverse)
    for _, i in keys:
        yield items[i]


@require_iter
def sort_with_keys(it, keys, reverse=False):
    """
    Given a set of items and matching keys, sorts items by keys
    """
    for item, _ in dsu_sort(zip(it, keys), lambda x: x[1], reverse=reverse):
        yield item
