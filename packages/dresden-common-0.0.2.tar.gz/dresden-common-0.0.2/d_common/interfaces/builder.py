class Builder(object):
    """
    This is a generic dataset builder.  Given 
    """

    def __init__(self, dataset):
        """
        @dataset: path/to/dataset/directory
        """

        self.dataset = dataset

    def fit(self, sample_stream, grouped, args):
        """
        This is responsible for preprocessing a set of sample data.

        @sample_stream: iterator of documents
        @grouped: whether or not it's a grouped document stream
        @extras: Extra parameters for building out builders
        """
        raise NotImplementedError()

    def build(self, input_stream, grouped, args):
        """
        Given that a dataset was already fitted, build the features needed for
        training from the given input_stream.  

        @sample_stream: iterator of documents
        @grouped: whether or not it's a grouped document stream
        @extras: Extra parameters for building out builders
        """
        raise NotImplementedError()

    @classmethod
    def add_args(cls, parser):
        """
        Adds arguments to a commandline parser.
        """
        raise NotImplementedError
