class Packager(object):
    """
    The Packager interface is responsible for copying one dataset to another for
    packaging purposes.  It is required to provide an implementation for 'copy'.
    """

    @classmethod
    def copy(cls, dataset, new_dataset):
        """
        Copy an original dataset, which might include superfluous data, into
        a new directory for use in packaging.

        Params
        ------
        @param dataset: An already existing directory containing the model
        @param new_dataset: Destination directory to copy data.  Calling methods
                            will guarantee that the directory exists.
        @rtype: None
        """
        raise NotImplementedError()

    @classmethod
    def extract_meta(cls, dataset):
        """
        Given a dataset, extracts metadata to be added to the schema.  

        Params
        ------
        @param dataset: /path/to/dataset
        @rtype: Dictionary.
        """
        return {}


class FSPackager(object):
    """
    Convenience implementation for packaging FileSystem.
    """
    file_system = None
    skip = ()

    @classmethod
    def copy(cls, dataset, new_dataset):
        if cls.file_system is None:
            raise NotImplementedError()

        cls.file_system.copy(dataset, new_dataset, skip=cls.skip)

    @classmethod
    def extract_meta(cls, dataset):
        return {}
