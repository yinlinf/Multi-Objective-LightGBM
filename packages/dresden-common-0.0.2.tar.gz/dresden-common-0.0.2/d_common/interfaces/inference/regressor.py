from .base import Base


class Regressor(Base):
    """
    Loads up a regressor for basic regression tasks.
    """

    def predict(self, docs, **opts):
        """
        Given a set of documents, returns predicted scores in the same order as given.

        @rtype: [float]
        """
        raise NotImplementedError()


class MultiRegressor(Base):
    """
    This is the interface for regressors which return multiple values per document.
    """

    def predict(self, docs, **opts):
        """
        Given a set of documents, returns a set of scores in original document order.
        @rtype: [[float]]
        """
        raise NotImplementedError()
