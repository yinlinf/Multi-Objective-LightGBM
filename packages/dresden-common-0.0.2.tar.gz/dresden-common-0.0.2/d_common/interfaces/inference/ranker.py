from .base import Base


class Ranker(Base):
    def rank(self, docs, **opts):
        """
        Takes a set of documents and returns them in ranked order.  Ordering
        is in the form of [best..worst]
        """
        raise NotImplementedError()

    def decision_function(self, docs, **opts):
        """
        Takes a set of documents and returns their scores in the same order received.

        Scores are required to sort with higher is better semantics.  They are not 
        required to be positive.

        Note: these scores are not guaranteed to be global scores!
        """
        raise NotImplementedError()
