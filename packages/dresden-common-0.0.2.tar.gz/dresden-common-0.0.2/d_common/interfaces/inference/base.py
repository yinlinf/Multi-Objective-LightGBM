class Base(object):
    @classmethod
    def load(cls, path, **opts):
        """
        This takes a path and loads the underlying class
        """
        raise NotImplementedError()

    def channels(self):
        """
        Returns a mapping of channels => channel types.
        """
        raise NotImplementedError()
