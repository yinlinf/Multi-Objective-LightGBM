from .base import Base


class Classifier(Base):
    """
    1-of-K classifier.
    """

    def labels(self):
        """
        Returns the total label set for a classifier
        """
        raise NotImplementedError()

    def classify(self, docs, **opts):
        """
        Takes a set of documents and returns the single best label for each document.

        label is required to be json-able

        @rtype: [label]
        """
        raise NotImplementedError()

    def decision_function(self, docs, **opts):
        """
        Takes a set of documents and returns the single best label and score for each
        document.

        label is required to be json-able

        @rtype: [(label, float)]
        """


class BinaryClassifier(Base):
    """
    Binary classifier.
    """

    def classify(self, docs, **opts):
        """
        Takes a set of documents and returns a boolean whether it's a positive or negative class

        @rtype: [bool]
        """
        raise NotImplementedError()

    def decision_function(self, docs):
        """
        Takes a set of documents and returns the raw score for each document document.

        @rtype: [float]
        """


class MultiLabelClassifier(Classifier):
    def classify(self, docs, **opts):
        """
        Takes a set of documents and returns an ordered list of labels for each document.

        Note: each document can return a different number of labels, including None

        @rtype: [[label]]
        """
        raise NotImplementedError()

    def decision_function(self, docs, **opts):
        """
        Takes a set of documents and returns an ordered pair of labels and scores

        @rtype: [[(label, float)]]
        """
