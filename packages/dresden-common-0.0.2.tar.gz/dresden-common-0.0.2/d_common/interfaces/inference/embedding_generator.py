from .base import Base


class EmbeddingGenerator(Base):
    """
    This is the interface for embedding generator.
    """

    def decision_function(self, docs, **opts):
        """
        Given a set of docs returns embeddings for the docs

        @rtype: [[float]]
        """
        raise NotImplementedError()
