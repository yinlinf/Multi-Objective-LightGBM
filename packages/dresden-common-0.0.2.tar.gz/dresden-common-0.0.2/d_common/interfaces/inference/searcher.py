from .base import Base


class KNNSearcher(Base):
    """
    This is the interface for nearest neighbors search.
    """

    def search(self, docs, num_k_neighbors, **opts):
        """
        Given a set of docs and num_k_neighbors, `returns num_k_neighbors` nearest neighbors by IDs.

        @rtype: [string]
        """
        raise NotImplementedError()
