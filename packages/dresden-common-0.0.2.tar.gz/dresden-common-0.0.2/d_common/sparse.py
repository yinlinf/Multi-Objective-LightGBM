from __future__ import absolute_import
import re

import scipy.sparse as sp
from collections import namedtuple
from six.moves import zip
from six import ensure_binary

def feat_to_csr(feats, n_features=None):
    """
    Takes a sparse string: '1:0.351 17:4513' and converts it into a a csr_matrix.
    """
    split_feats = feats.rstrip().split()
    if len(split_feats) > 0:
        fs = (x.split(b':') for x in split_feats)
        idx, vals = list(zip(*((int(idx), float(v)) for idx, v in fs)))
    else:
        idx, vals = [], []
        if n_features is None:
            n_features = 1

    shape = (1, n_features) if n_features is not None else None
    return sp.csr_matrix((vals, ([0] * len(idx), idx)), shape=shape)


def feat_to_dict(feats):
    fs = (x.split(':') for x in feats.rstrip().split())
    return {int(idx): float(val) for idx, val in fs}


def split_tsv(feat, has_weight, has_label, train=True, score_type=int):
    fields = ensure_binary(feat).split(b'\t')
    if train:
        score = score_type(fields[0])
        i = 1
        if has_weight:
            weight = float(fields[i])
            i += 1
        else:
            weight = 1.0

        if has_label:
            label = fields[i]
            i += 1
        else:
            label = ''
    else:
        score, weight, label = '', '', ''
        i = 1 + has_weight + has_label

    feats = fields[i:][0]

    return score, weight, label, feats


INDEX_RX = re.compile(r'(\d+):')


class Record(object):
    def __init__(self, y, weight, label, feats):
        self.y = y
        self.weight = weight
        self.label = label
        self.feats = feats

    def sparse_X(self, n_features=None):
        return feat_to_csr(self.feats, n_features)

    def _compute_feats(self):
        if not self.feats:
            return 0

        nz = 0
        mf = 0
        for match in INDEX_RX.finditer(self.feats):
            nz += 1
            mf = max(int(match.groups()[0]), mf)

        self._max_feature = 1 + mf
        self._nonzero = nz

    def max_feature(self):
        """
        figures out the max feature by parsing the string
        """
        if not hasattr(self, '_max_feature'):
            self._compute_feats()

        return self._max_feature

    def nonzero(self):
        """
        figures out the max feature by parsing the string
        """
        if not hasattr(self, '_nonzero'):
            self._compute_feats()

        return self._nonzero


def split_record(*args, **kwargs):
    score, weight, label, feats = split_tsv(*args, **kwargs)
    return Record(score, weight, label, feats)
