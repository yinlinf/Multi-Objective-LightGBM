from __future__ import absolute_import
from collections import defaultdict
from itertools import combinations, islice

from scipy.stats import beta

import numpy as np
from merlin.labs.ai.iterutils import merge, round_robin
import six
from six.moves import range


class Sorter(object):
    "Strategy pattern lives long and prospers!"

    def __init__(self, cmp):
        self.cmp = cmp

    def sort(self, docs):
        raise NotImplementedError()


class Default(Sorter):
    def sort(self, docs):
        return sorted(docs, cmp=self.cmp)


class Tournament(Sorter):
    @staticmethod
    def tournament(docs, cmp):
        """
        Tallies scores for a tournament
        """
        counts = [0] * len(docs)
        for i1, i2 in combinations(range(len(docs)), 2):
            v = cmp(docs[i1], docs[i2])
            if v > 0:
                counts[i1] += 1
            elif v < 0:
                counts[i2] += 1

        return counts

    def sort(self, docs):
        counts = self.tournament(docs, self.cmp)

        # Now sort
        sids = sorted(enumerate(counts), key=lambda x: (x[1], -x[0]))
        return [docs[i] for i, _ in sids]


def randomSet(N, K, size):
    idxs = list(range(N))
    for _ in range(K):
        np.random.shuffle(idxs)
        i = -1
        for i in range(N / size):
            b = []
            offset = i * size
            for j in range(size):
                b.append(idxs[offset + j])

            yield b

        # Get remainder
        b = idxs[(i + 1) * size:]
        if b:
            yield b


def ktourny(docs, K, cmp_):
    scores = [0] * len(docs)
    compares = [0] * len(docs)
    for iset in randomSet(len(docs), K, 2):
        if len(iset) < 2:
            continue

        i1, i2 = iset
        v = cmp_(docs[i1], docs[i2])
        if v > 0:
            scores[i1] += 1
        elif v < 0:
            scores[i2] += 1

        compares[i1] += 1
        compares[i2] += 1

    return scores, compares


class SamplingTournament(Sorter):
    """
    This is a probablistic sorter.  That means it very likely will not
    sort exactly.
    
    Each document plays a total of K games.  If K is None, it uses the log(N)
    to determine K.
    We then estimate the lower confidence based on the beta CI
    """

    def __init__(self, cmp, K=None, CI=0.8, est=True):
        super(SamplingTournament, self).__init__(cmp)
        self.K = K
        self.CI = CI
        self.est = est
        self.tournament = Tournament(cmp)

    def score(self, N, scores, compares):
        # Build a beta distribution
        lbs = []
        bcache = {}
        for i in range(N):
            if not self.est:
                lbs.append((scores[i], i))
                continue

            key = (scores[i], compares[i])
            if key not in bcache:
                if scores[i] == 0:
                    bcache[key] = 0
                else:
                    bcache[key] = beta.interval(self.CI, scores[i],
                                                compares[i] - scores[i] + 1)[0]

            lbs.append((bcache[key], i))

        return lbs

    def sort(self, docs):
        if len(docs) < self.K:
            return self.tournament.sort(docs)

        scores, compares = ktourny(docs, self.K, self.cmp)

        lbs = self.score(len(docs), scores, compares)

        return [docs[idx] for _, idx in sorted(lbs)]


class MergeSort(Sorter):
    def sort(self, docs):
        idocs = [(d, ) for d in docs]
        return list(merge(idocs, self.cmp))


class TournaMerge(Sorter):
    """
    Runs a series of K-sized tournaments, then merges them.
    """

    def __init__(self, cmp, K=6):
        super(TournaMerge, self).__init__(cmp)
        self.K = K
        self.ms = MergeSort(cmp)
        self.tournament = Tournament(cmp)

    def _sortRows(self, docs):
        rows = []
        for idxs in randomSet(len(docs), 1, self.K):
            data = [docs[i] for i in idxs]
            rows.append(self.tournament.sort(data))

        return rows

    def sort(self, docs):
        if len(docs) <= self.K:
            return self.tournament.sort(docs)

        return list(merge(self._sortRows(docs), self.cmp))


class SampleMerge(Sorter):
    """
    Runs a series of K-sized tournaments, then merges them.
    """

    def __init__(self, cmp, K=6):
        super(SampleMerge, self).__init__(cmp)
        self.K = K
        self.ms = MergeSort(cmp)
        self.tournament = Tournament(cmp)

    def sort(self, docs):
        if len(docs) <= self.K:
            return self.tournament.sort(docs)

        scores, _compares = ktourny(docs, self.K, self.cmp)

        s = defaultdict(list)
        for i, c in enumerate(scores):
            s[c].append(docs[i])

        n = []
        for k, ds in sorted(six.iteritems(s), key=lambda x: x[0]):
            n.extend(self.ms.sort(ds))

        return n


class KTournament(Sorter):
    def __init__(self, cmp, K=6, winners=1):
        super(KTournament, self).__init__(cmp)
        self.K = K
        self.tournament = Tournament(cmp)
        self.winners = winners

    def sort(self, docs):
        remaining = [d for d in docs]
        losers = []
        while len(remaining) > self.winners:
            cur_losers = []
            winners = []
            for idxs in randomSet(len(remaining), 1, self.K):
                data = [remaining[i] for i in idxs]
                it = iter(self.tournament.sort(data))

                winners.extend(islice(it, self.winners))

                cur_losers.append(it)

            remaining = winners
            losers.extend(reversed(list(round_robin(*cur_losers))))

        losers.extend(reversed(remaining))

        return list(reversed(losers))


SORTS = {
    "default": Default,
    "merge": MergeSort,
    "tournament": Tournament,
    "sampling_tournament": SamplingTournament,
    "tournamerge": TournaMerge,
    "samplemerge": SampleMerge,
    "ktournament": KTournament
}
