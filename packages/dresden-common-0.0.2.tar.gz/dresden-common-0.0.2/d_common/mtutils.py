import tempfile
import shutil
import logging

from .iterutils import batch
from .mt import ParPipeline, Map, Reduce, batch_map


class ParWriter(object):
    def __init__(self, feature_threads, write_threads, batch_size=100):
        self.feature_threads = feature_threads
        self.write_threads = write_threads
        self.batch_size = batch_size

    def run(self, it, featurizer, writer, merger):
        pipeline = ParPipeline()
        pipeline = pipeline.add(
            Map(batch_map(featurizer)), self.feature_threads)
        pipeline = pipeline.add(
            Reduce(self.reducer(writer)), self.write_threads)
        pipeline = pipeline.add(Reduce(self.merger(merger)), 1)
        return pipeline(batch(it, self.batch_size))

    def reducer(self, writer):
        def write(it):
            temp_dir = tempfile.mkdtemp()
            logging.info("Creating new temp directory %s" % temp_dir)
            new_it = (k for ks in it for k in ks)
            writer(temp_dir, new_it)
            return temp_dir

        return write

    def merger(self, merger):
        def merge(it):
            paths = list(it)
            try:
                return merger(paths)
            finally:
                for p in paths:
                    print("Deleting", p)
                    shutil.rmtree(p)

        return merge
