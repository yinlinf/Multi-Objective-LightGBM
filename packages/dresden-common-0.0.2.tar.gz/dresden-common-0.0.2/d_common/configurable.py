from __future__ import absolute_import
from .registry import Registry
import six


class ValidationError(Exception):
    pass


class FieldType(object):
    """
    Must raise ValidationError on validation failure
    """

    def __init__(self, help):
        self.help_text = help

    def help(self):
        return self.help_text

    def evaluate(self, v):
        raise NotImplementedError()


Field = Registry(FieldType, lambda x: x)


class OptionalField(FieldType):
    def __init__(self, field, default):
        assert isinstance(field, FieldType)
        ht = "Optional - %s.  Default is `%s`" % (field.help(), default)
        super(OptionalField, self).__init__(ht)
        self.field = field
        self.default = default

    def evaluate(self, v):
        if v is None:
            if callable(self.default):
                return self.default()

            return self.default

        return self.field.evaluate(v)


class FieldTypeO(FieldType):
    def optional(self, default):
        return OptionalField(self, default)


class TypeableField(FieldTypeO):
    FTYPE = object

    def evaluate(self, v):
        if not isinstance(v, self.FTYPE):
            raise ValidationError("%s is not a %s" % (v, self.FTYPE))

        return v


@Field.register("Bool")
class BoolField(TypeableField):
    FTYPE = bool


@Field.register("Int")
class IntField(TypeableField):
    FTYPE = int

    def __init__(self, help, lbound=float('-inf'), ubound=float('inf')):
        super(IntField, self).__init__(help)
        self.lbound = lbound
        self.ubound = ubound

    def evaluate(self, v):
        v = super(IntField, self).evaluate(v)
        if v < self.lbound or v > self.ubound:
            raise ValidationError("value must be between %s and %s" %
                                  (self.lbound, self.ubound))

        return v

    def help(self):
        return "%s <= Int <= %s: %s" % (self.lbound, self.ubound,
                                        self.help_text)


@Field.register("String")
class StringField(TypeableField):
    FTYPE = six.string_types


@Field.register("Float")
class StringField(TypeableField):
    FTYPE = float


@Field.register('List')
class ListField(FieldType):
    def __init__(self, ftype, help):
        super(ListField, self).__init__(help)
        self.ftype = ftype

    def evaluate(self, v):
        isList = isinstance(v, (list, tuple))
        if not isList or not all(isinstance(k, self.ftype) for k in v):
            raise ValidationError("%s needs to be a list of %s" %
                                  (v, self.ftype.__name__))

        return v

    def optional(self, default):
        return OptionalField(self, default)


@Field.register("Choice")
class ChoiceField(FieldTypeO):
    def __init__(self, choices, help):
        super(ChoiceField, self).__init__(help)
        self.choices = choices

    def evaluate(self, v):
        if not any(k == v for k in self.choices):
            choices = ', '.join(self.choices)
            raise ValidationError("%s is not a valid choice of `%s`" %
                                  (v, choices))

        return v


class ConfigurableMeta(type):
    def __new__(cls, name, bases, attrs):
        fields = []
        for k, v in list(attrs.items()):
            if isinstance(v, FieldType) or isinstance(v, type) and issubclass(
                    v, FieldType):
                fields.append((k, v))
                del attrs[k]

        attrs['fields'] = fields

        return super(ConfigurableMeta, cls).__new__(cls, name, bases, attrs)


class Configurable(six.with_metaclass(ConfigurableMeta, FieldType)):
    def __init__(self, settings):
        for k, v in self.fields:
            try:
                setattr(self, k, v.evaluate(settings.get(k)))
            except ValidationError as e:
                raise ValidationError("Error processing %s: %s" % (k,
                                                                   e.message))

    @classmethod
    def help(cls):
        docs = []
        for k, v in cls.fields:
            docs.append("`%s`: %s" % (k, v.help()))

        return '\n'.join(docs)

    @classmethod
    def evaluate(cls, v):
        return cls(v)
