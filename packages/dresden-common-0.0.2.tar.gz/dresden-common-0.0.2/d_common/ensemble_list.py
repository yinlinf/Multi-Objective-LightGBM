from __future__ import absolute_import
import six
from six.moves import zip


class EnsembleNode:
    def __init__(self,
                 model_name,
                 model,
                 task_name,
                 return_score=False,
                 field_name=None,
                 upstream_dependency=None):
        self.model = model
        self.model_name = model_name
        self.field_name = field_name
        self.task_name = task_name
        self.return_score = bool(return_score)
        self.upstream_dependency = upstream_dependency

    def __repr__(self):
        ensemble_nodes = {
            "model_name": self.model_name,
            "model": self.model,
            "field_name": self.field_name,
            "task_name": self.task_name,
            "return_score": self.return_score,
            "upstream_dependency": self.upstream_dependency
        }
        return str(ensemble_nodes)


class EnsembleList:
    """
    - Creates the ensemble list
    - Validates the ensemble list
    - Executes the ensemble list to get the score

    Limitations: This class can only create DAG with one root model and linear structure.
    """

    def __init__(self, ensemble_list=[]):
        self.ensemble_list = ensemble_list
        self.ensemble_validator = EnsembleValidator()

    def create_dag(self, ensemble_params):
        """
        Create linear DAG using ensemble list
        :param ensemble_params: dict, ensemble dag configuration
        :return: None
        """
        self.ensemble_validator.validate_ensemble_params(ensemble_params)
        self.ensemble_list = self._create_ensemble_nodes(ensemble_params)
        self.ensemble_validator.validate_ensemble_dag_is_linear(
            self.ensemble_list)
        self._make_return_score_true_in_last_task_node()
        return self.ensemble_list

    def _create_ensemble_nodes(self, ensemble_params):
        """
        Function creates sorted list of Ensemble Nodes
        :param ensemble_params: dict, ensemble graph configuration
        :return: ordered list of EnsembleNodes
        """
        ensemble_nodes = []

        for task, task_conf in six.iteritems(ensemble_params):
            ensemble_nodes.append(
                EnsembleNode(
                    task_name=task,
                    model_name=task_conf.get('model_name'),
                    model=task_conf.get('model'),
                    field_name=task_conf.get('field_name'),
                    upstream_dependency=task_conf.get('upstream_dependency'),
                    return_score=task_conf.get('return_score', False), ))
        ensemble_nodes = self._ordered_list(ensemble_nodes)
        return ensemble_nodes

    def _ordered_list(self, ensemble_nodes):
        """
        It will arrange the nodes in the order of execution sequence
        :param ensemble_nodes: list of EnsembleNodes
        :return: ordered list of EnsembleNodes
        """
        sorted_ensemble_nodes = []
        ensemble_nodes_map = self._create_ensemble_nodes_map(ensemble_nodes)
        if not ensemble_nodes_map.get('root'):
            raise ValueError(
                "Please specify a root node in dag configuration. "
                "Root node is one which does not has any upstream_dependency")

        current_node = ensemble_nodes_map.pop('root')
        sorted_ensemble_nodes.append(current_node)
        while ensemble_nodes_map:
            if current_node.task_name not in ensemble_nodes_map:
                raise ValueError(
                    "`{0}` task is not an upstream dependency of any low-stream tasks"
                    .format(current_node.task_name))
            current_node = ensemble_nodes_map.pop(current_node.task_name)
            sorted_ensemble_nodes.append(current_node)

        return sorted_ensemble_nodes

    def _create_ensemble_nodes_map(self, ensemble_nodes):
        """
        Create { upstream_dependency -> EnsembleNode }
        :param ensemble_nodes: list of ensemble nodes
        :return: dict
        """
        ensemble_nodes_map = {}
        for node in ensemble_nodes:
            if not node.upstream_dependency:
                if 'root' in ensemble_nodes_map:
                    raise ValueError(
                        "There are multiple nodes with no upstream dependencies. "
                        "We currently do not support this use case")
                ensemble_nodes_map['root'] = node
            elif node.upstream_dependency in ensemble_nodes_map:
                raise ValueError(
                    "We only support linear DAGs, no two task can be depended on same upstream task. "
                    "In current configuration multiple tasks are dependent on this task `{0}`"
                    .format(node.upstream_dependency))
            else:
                ensemble_nodes_map[node.upstream_dependency] = node
        return ensemble_nodes_map

    def _make_return_score_true_in_last_task_node(self):
        last_task_node = self.ensemble_list[-1]
        if not last_task_node.return_score:
            last_task_node.return_score = True

    def execute_dag(self, docs):
        """
        Executes the ensemble list to get the scores
        if we are returning scores from one model, this function will return
        list of scores [1.0, 2,0, 3.0] etc.
        if we are returning scores from multiple models, this function will return
        dict of scores {'lgbm': [1.0, 2,0, 3.0], 'vw': [1.0, 2,0, 3.0]} etc
        :param docs: list of dict, documents
        :return: list/dict, scores
        """
        model_scores = {}
        for node_index, node in enumerate(self.ensemble_list):
            scores = node.model.decision_function(docs)
            if node.return_score:
                model_scores[node.model_name] = scores
            if node_index != len(self.ensemble_list) - 1:
                field_name = node.field_name
                if not field_name:
                    raise KeyError(
                        '`field_name` argument is required in `{0}` to use scores for training '
                        'in next step'.format(node.task_name))
                for doc, score in zip(docs, scores):
                    doc[field_name] = score
        return scores if len(model_scores) == 1 else model_scores

    def get_channels(self):
        """
        Returns Union of all the channels in the ensemble_dag
        :return: dict
        """
        channels = {}
        field_names = []
        for ensemble_node in self.ensemble_list:
            node_channels = ensemble_node.model.channels()
            if ensemble_node.field_name:
                field_names.append(ensemble_node.field_name)
            if len(channels) == 0:
                channels = node_channels
            elif 'features' in channels and node_channels is not None:
                channels['features'].update(node_channels['features'])

        for field_name in field_names:
            if 'features' in channels and field_name in channels['features']:
                channels['features'].pop(field_name)

        return channels


class EnsembleValidator:
    def __int__(self):
        pass

    def validate_ensemble_dag_is_linear(self, ensemble_list):
        """
        Since we only support linear DAG in this class
        This functions validates that and throws error if the enseble_dag is non linear
        :param ensemble_list: list of ensemble nodes
        :return: None
        """
        previous_node = ensemble_list[0]
        for ensemble_node in ensemble_list[1:]:
            if ensemble_node.upstream_dependency != previous_node.task_name:
                raise ValueError(
                    "The ensemble dag is non linear or upstream task is not executed,"
                    " Task `{0}` should be dependent and executed before on Task `{1}`"
                    .format(ensemble_node.task_name, previous_node.task_name))
            previous_node = ensemble_node
        return

    def validate_ensemble_params(self, ensemble_params):
        """
        Validates the ensemble graph arguments
        :param emsemble_params: dict
        :return: None
        """
        if not isinstance(ensemble_params, dict):
            raise TypeError(
                "Expected type of `Ensemble dag params` is dict but "
                "passed `{}`".format(type(ensemble_params)))

        for task, task_conf in six.iteritems(ensemble_params):
            if not isinstance(task, six.string_types):
                raise TypeError(
                    "Expected type of `task` is string but passed `{}`".format(
                        type(task)))

            if "model" not in task_conf:
                raise KeyError(
                    "There is no `model` argument in the model config."
                    "This arguments consists of model class module for predicting scores"
                )
        return
