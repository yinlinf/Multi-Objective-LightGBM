from __future__ import print_function

from __future__ import absolute_import
import sys
import time
import os

from datadog import DogStatsd
from contextlib import contextmanager

statsd = DogStatsd(
    host='localhost', port=int(os.environ.get('STATSD_PORT', '8125')))
statsd.get_socket()


class STATSD:
    """
    This class is being used to add functions to add different metrics in Statsd
    """

    def __init__(self, metric_prefix):
        self.statsd = statsd
        self.metric_prefix = metric_prefix

    def increment_statsd(self, value, step_name, tags):
        self.statsd.timing(self.metric_prefix % step_name, value, tags=tags)


class Timer(object):
    def __init__(self):
        self.start = time.time()

    def elapsed(self):
        return time.time() - self.start


@contextmanager
def timer(msg):
    timer = Timer()
    yield
    print(msg, timer.elapsed())


@contextmanager
def time_metrics(step_name, tags=None):
    timer = Timer()
    yield
    if os.environ.get('dogstatsd_server_is_available', "False") == "True":
        statsd = STATSD("time_elapsed_to_perform_%s")
        elapsed_time_in_ms = timer.elapsed() * 1000
        statsd.increment_statsd(
            value=elapsed_time_in_ms, step_name=step_name, tags=tags)
    else:
        pass


def timeit(f):
    def timed(*args, **kwargs):
        timer = Timer()
        try:
            return f(*args, **kwargs)
        finally:
            print(
                '{0} function took {1} ms'.format(f.__name__, timer.elapsed()),
                file=sys.stderr)

    return timed
