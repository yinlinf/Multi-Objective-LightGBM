from __future__ import absolute_import
import os
import sys
import gzip
import json
import importlib
import imp
import hashlib
import ntpath
import subprocess

# This is here for compatibility with python 3 IO
# NOTE: this changes the behavior of open;
# see https://portingguide.readthedocs.io/en/latest/strings.html#file-i-o
# for more details.
# The TL; DR is that io.open opens files as either unicode text (using the system
# or passed encoding) or as bytes; because system encoding is unreliable it is
# recommended to set encoding='utf-8' when opening.
from io import open

from d_common.iterutils import unfold


def cat(ofs, nfs):
    with open(nfs, 'wb') as out:
        for fn in ofs:
            with open(fn, 'rb') as f:
                chunker = unfold(lambda: f.read(4096), bool)
                for data in chunker:
                    out.write(data)


def _jsonSafeLoad(v):
    try:
        return True, json.loads(v)
    except ValueError:
        return False, None


def _jsonLoad(v):
    return True, json.loads(v)


def yieldLines(file_name, postdelete=False):
    if file_name == '-':
        f = open_stdin()
    elif file_name.endswith('.gz'):
        f = gzip.open(file_name)
    else:
        f = _open_file(file_name)

    try:
        for line in f:
            yield line
    finally:
        if file_name != '-':
            _close_file(f)
            if postdelete:
                os.remove(file_name)


def yieldLinesFromDirectory(dir_path, sort=True, postdelete=False):
    files = get_all_files_in_nested_directory_tree(os.path.abspath(dir_path))
    if sort:
        files = sorted(files)
    for file in files:
        for line in yieldLines(file, postdelete):
            yield line


def get_all_files_in_nested_directory_tree(dir_name):
    files = os.listdir(dir_name)
    allFiles = []

    for file in files:
        full_path = os.path.join(dir_name, file)
        if os.path.isdir(full_path):
            allFiles += get_all_files_in_nested_directory_tree(full_path)
        else:
            allFiles.append(full_path)
    return allFiles


def _close_file(f):
    f.close()


def _open_file(file_name):
    return open(file_name, encoding='utf-8')


def open_stdin(encoding='utf-8'):
    """
    Utility function to portably open stdin across Python 2 and 3
    in text mode.
    """
    # Python 3's stdin exposes a buffer attribute, whereas Python 2 does not
    # (and is itself the file-like object).
    # In both cases we want to open the buffer via io.open and set the encoding
    # appropriately.
    try:
        stdin_buffer = sys.stdin.buffer
    except AttributeError:
        stdin_buffer = sys.stdin

    return open(stdin_buffer.fileno(), encoding=encoding)


def yieldJson(fn, ignore_errors=False):
    func = _jsonSafeLoad if ignore_errors else _jsonLoad
    for line in yieldLines(fn):
        success, data = func(line)
        if success:
            yield data


def exit_running_processes(process_name, e):
    subprocess.run(
        'pkill -9 ' + ntpath.basename(process_name) + ' | echo ' + str(e),
        shell=True)


def class_loader(path):
    """
    Imports a class from a given module given string:

    module.to.load:ClassName OR /path/to/file.py:ClassName

    If a /path/to/file is provided, the module name will be the md5 hash of the
    path to prevent collisions in sys.modules and prevent reloading of module
    if used multiple times.

    """
    module_path, cls_name = path.split(':')
    mod = importlib.import_module(module_path)

    return getattr(mod, cls_name)


def file_loader(path, rel_path=None):
    module_path, cls_name = path.split(':')

    # Join the file with a provided rel_path
    if rel_path is not None:
        module_path = os.path.join(rel_path + '/', module_path)

    # Load the file, hashing the name for sys.modules
    name = hashlib.md5(module_path.encode("utf-8")).hexdigest()
    if name not in sys.modules:
        imp.load_source(name, module_path)

    mod = sys.modules[name]

    return getattr(mod, cls_name)


class ImConfig(object):
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

    def __setattr__(self, key):
        raise Exception("Can't update ImConfig!  They're immutable!")

    def __unicode__(self):
        return u'ImConfig({})'.format(
            ', '.join('{}={}'.format(k, v) for k, v in self.__dict__.items()))

    __repr__ = __unicode__
