from __future__ import absolute_import
import sys
import logging
import time


def setupLogging(fn=None, sout=sys.stdout, loglevel=logging.INFO):
    # To a file and to stdout
    fmt = "%(asctime)s %(name)s %(levelname)s %(process)d-%(threadName)s %(module)s : %(lineno)s - %(message)s"

    kwargs = dict(format=fmt, level=loglevel)
    if fn is not None:
        kwargs['filename'] = fn

    logging.basicConfig(**kwargs)
    if sout is not None:
        logging.root.addHandler(logging.StreamHandler(sout))


def logArgs():
    logging.info("Parameters: %s", ' '.join(sys.argv[1:]))


def lps(it, N=10000, msg="Processed {N} docs, DPS: {DPS}"):
    sTime = time.time()
    for i, d in enumerate(it):
        if i % N == 0:
            t = time.time() - sTime
            dps = round(i / t, 3)
            logging.info(msg.format(N=i, DPS=dps))

        yield d
