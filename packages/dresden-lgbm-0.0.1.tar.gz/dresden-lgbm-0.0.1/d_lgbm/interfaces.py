from __future__ import absolute_import
import scipy.sparse as sp

from buzzsaw import Buzzsaw
from lightgbm import Booster

from d_common.interfaces import Regressor, Ranker, FSPackager
from d_common.iterutils import sort_with_keys
from d_common.timing import time_metrics

from .processor import Processor
from .utils import LGBMFileSystem


class Evaluator(object):
    def __init__(self, proc, path, lgbm_prediction_params):
        self.proc = proc
        self.path = path
        self._lgbm_prediction_params = lgbm_prediction_params

        # `num_threads` default is equal to `1` because lightGBM
        # model is loaded in uWSGI pre-fork for performance
        # and `num_threads` > 1 does not work in uWSGI if loaded pre-fork
        if 'num_threads' not in self._lgbm_prediction_params:
            self._lgbm_prediction_params['num_threads'] = 1

    def decision_function(self, docs):

        with time_metrics(
                'prediction', tags=('interface:lightgbm', 'step:buzzsaw')):
            feats = self.proc.features(
                docs, grouped=False, raw=False, n_feats=self.n_feats)

        with time_metrics(
                'prediction', tags=('interface:lightgbm', 'step:model')):
            pred = self.model.predict(
                sp.vstack(feats), **self._lgbm_prediction_params)

        return pred

    # Loading model lazily to avoid memory issue
    @property
    def model(self):
        if hasattr(self, '_model'):
            return self._model
        else:
            with time_metrics('model_load', tags=('interface:lightgbm')):
                self._model = Booster(
                    model_file=LGBMFileSystem(self.path).model)
        return self._model

    @property
    def n_feats(self):
        if hasattr(self, '_n_feats'):
            return self._n_feats
        else:
            self._n_feats = len(self.model.feature_name())
        return self._n_feats

    def channels(self):
        return self.proc.channels()


def load_processor(lgfs):
    with time_metrics('buzzsaw_load', tags=('interface:lightgbm')):
        bz = Buzzsaw.from_file(lgfs.buzzsaw)
    return Processor.load(bz, **lgfs.loadProcessor())


def load(path, lgbm_prediction_params):
    if lgbm_prediction_params is None:
        lgbm_prediction_params = {}
    lgfs = LGBMFileSystem(path)
    proc = load_processor(lgfs)
    return Evaluator(proc, path, lgbm_prediction_params)


class Base(object):
    """
    We lazy load our lightgbm models because post-forking causes weird locking
    issues within lightgbm, resulting in deadlocks.
    """

    def __init__(self, evaluator):
        self.evaluator = evaluator

    @classmethod
    def load(cls, path, lgbm_prediction_params=None):
        return cls(load(path, lgbm_prediction_params))

    def channels(self):
        return self.evaluator.channels()


class Ranker(Base, Ranker):
    def rank(self, docs, **opts):
        scores = self.decision_function(docs)
        return list(sort_with_keys(docs, scores, reverse=True))

    def decision_function(self, docs, **opts):
        return self.evaluator.decision_function(docs).tolist()


class Regressor(Base, Regressor):
    def predict(self, docs, **opts):
        return self.evaluator.decision_function(docs).tolist()


class Packager(FSPackager):
    """
    Packages lightgbm models.
    """
    file_system = LGBMFileSystem
    skip = ('features', 'task', 'tsvFeatures')
