from .create import Create
from .train import Train

commands = [Create, Train]
