from __future__ import print_function
from __future__ import absolute_import
import logging
from multiprocessing import cpu_count
import numpy as np
import os
import re
import six
import shutil

from .command import Command
from d_common.logger import setupLogging, logArgs, lps
from d_hp.runners import HPConfigFileSearcher
from d_hp.searcher import RandomSearch, GridSearch
from d_lgbm.train_valid_file_combiner import LightGBMTrainValidFileCombiner
from d_lgbm.utils import LGBMFileSystem, PairwiseFeatureParser, PointwiseFeatureParser

class TrainingDataWriter:
    W_SUFFIX = '.weight'

    def __init__(self, fname):
        self.fname = fname

    def __enter__(self):
        fname = self.fname
        self._features_file = open(fname, 'w')
        self._weight_file = open(fname + self.W_SUFFIX, 'w')
        return self

    def __exit__(self, *args):
        self._features_file.close()
        self._weight_file.close()

    def write(self, parsed_train_example):
        """
        :param parsed_train_example: A ParsedTrainExample
        """
        print(
            '%s %s' % (parsed_train_example.label,
                       parsed_train_example.features),
            file=self._features_file)
        print('%f' % parsed_train_example.weight, file=self._weight_file)


def split_parsed_examples_from_dataset(lgfs, split_amount, seed, parser, loadFeatures):
    '''
        This function splits data into training and validation sets
        for hyper-parameter search. Hps with minimum validation error
        is selected
        args:
            lgfs - lightgbm file system which contains model, features, fitted_buzzsaw_config
            split_amount - percentage of data to be split between train and validation
            seed - to replicate randomization
            parser - A RawFeatureParser instance
            loadFeatures - This is part of lgfs. lgfs can store features in two formats.
                                1) JSON 2) TSV
                            JSON is used for Pairwise modeling
                            TSV is used for pointwise modeling
    '''
    rs = np.random.RandomState(seed)

    with TrainingDataWriter(
            lgfs.trainFeatures) as train_writer, TrainingDataWriter(
                lgfs.testFeatures) as test_writer:
        last_query_id = -1
        writer = train_writer

        for data_line in lps(loadFeatures()):
            for training_instance in parser.parse_data_line(data_line):
                query_id = training_instance.query_id
                #Randomly choose writer upon either:
                # i) New query group
                # ii) New instance (when query group is not included)
                if query_id is None or query_id != last_query_id:
                    if rs.rand() < split_amount:
                        writer = train_writer
                    else:
                        writer = test_writer

                writer.write(training_instance)
                last_query_id = query_id


def train(lgfs, query_id_column, weight_column, config_path, n_trials, threads, seed,
          lowerIsBetter):

    scorer = lambda x: re.search('valid_1', six.text_type(x)) is not None

    TOP_K = 1

    def searcher(hps, is_discrete):
        if is_discrete:
            return GridSearch(hps, lowerIsBetter, TOP_K)

        else:
            return RandomSearch(hps, lowerIsBetter, TOP_K, seed, n_trials)

    command_parts = [
        "lightgbm", "task=train",
        "data=%s" % lgfs.trainFeatures,
        "valid_data=%s" % lgfs.testFeatures,
        "output_model=%s.<TRIAL>" % lgfs.model, "config=<CONFIG>"
    ]

    if query_id_column is not None:
        command_parts.append("query_id={}".format(query_id_column))
    if weight_column is not None:
        command_parts.append("weight={}".format(weight_column))

    logging.info("command_parts")
    logging.info(command_parts)
    command = " ".join(command_parts)

    hcfs = HPConfigFileSearcher(command, None, config_path, threads, scorer,
                                searcher)

    trial_results = hcfs.run({})
    best_key, best_score = trial_results[-1]
    best_trial = best_key[0]
    logging.info(
        'Results for best trial: {}: {}'.format(best_trial, best_score))
    shutil.move('{}.{}'.format(lgfs.model, best_trial), lgfs.model)

    def get_trial_config_path(trial_no):
        return '{}.{}'.format(config_path, trial_no)

    with open(get_trial_config_path(best_trial)) as f:
        logging.info("Best Configuration settings:")
        for line in f:
            logging.info(line.rstrip())

    for trial_no in six.moves.range(n_trials):
        #Clean up temp config file
        trial_config_path = get_trial_config_path(trial_no)
        logging.info("Deleting trial configuration file %s...",
                     trial_config_path)
        if os.path.exists(trial_config_path):
            os.unlink(trial_config_path)

def split_data_example_parsing(lgfs,args):
    task = lgfs.loadTask()
    if task == 'lambdarank' and (args.query_id_column is None
                                 or args.keep_empty):
        raise ValueError(
            "In lambdarank mode, must pass in query ID column argument and data must have query ID column."
        )
    if task == 'pairwise':
        feature_parser = PairwiseFeatureParser()
        features_func = lgfs.loadFeatures
    elif task in ('pointwise', 'lambdarank'):
        processor = lgfs.loadProcessor()
        has_weight = processor['settings']['has_weight']
        feature_parser = PointwiseFeatureParser(
            has_weight, args.query_id_column, args.keep_empty)
        features_func = lgfs.loadTsvFeatures
    else:
        raise Exception("task is not defined")

    split_parsed_examples_from_dataset(lgfs, args.split, args.seed, feature_parser, features_func)

def split_data_with_file_combiner(lgfs,
                                  args,
                                  input_files_dir,
                                  input_files_regex):

    task = lgfs.loadTask()
    if task != 'lambdarank':
        raise ValueError("Data splitting with file combiner only supported in Lambdarank")

    processor = lgfs.loadProcessor()
    has_weight = processor['settings']['has_weight']
    if has_weight:
        raise ValueError("Data splitting with file combiner not supported with instance weights")

    logging.info("Creating training and validation files using file combiner")
    file_combiner = LightGBMTrainValidFileCombiner(args.split,
                                                   args.query_id_column,
                                                   input_files_regex,
                                                   lgfs.trainFeatures,
                                                   lgfs.testFeatures)

    file_combiner.create_train_valid_files(input_files_dir)

def trainer(args):

    # load the fs
    lgfs = LGBMFileSystem(args.dataset)
    setupLogging(lgfs.getLogFile('train'))
    logArgs()

    if not args.trainOnly:
        split_data_args = args.data_splitter
        split_data_method = split_data_args[0]

        if split_data_method == "example_parsing_pipeline":
            split_data_example_parsing(lgfs, args)
        elif split_data_method == "raw_file_combiner":
            if len(split_data_args) != 3:
                raise ValueError("If using raw_file_combiner, must provide <input_path> and <file_regex>")
            input_files_dir,input_files_regex = split_data_args[1:]
            split_data_with_file_combiner(lgfs, args, input_files_dir, input_files_regex)

    logging.info("weight_column:"+str(args.weight_column))
    train(lgfs, args.query_id_column, args.weight_column, args.config, args.trials, args.threads,
          args.seed, args.higherIsBetter)


class Train(Command):
    name = "train"
    description = "Train a LightGBM model"

    def arguments(self, parser):
        parser.add_argument("dataset", help="Dataset")
        parser.add_argument("config", help="lightgbm config")
        parser.add_argument(
            "--seed", dest="seed", default=0, type=int, help="Random Seed")
        parser.add_argument(
            "--split",
            dest="split",
            default=0.9,
            type=float,
            help="Amount to split train and test")
        parser.add_argument(
            "--data-splitter",
            nargs="+",
            default=["example_parsing_pipeline"],
            help="""
                Method to use for creating training/validation data. You can either use:
                1) 'example_parsing_pipepline': this is currently required for non-Lambdarank models and for training data with
                    instance weights. It requires `lgbm.py create` to have run without `--skip-feature-creation`
                2) 'raw_file_combiner <input_dir> <input_file_regex>': this is an optimized method that works 
                    for Lambdarank (without weights). It combines the raw partition files outputted by PySpark Buzzsaw. 
                    This allows you to run `lgbm.py create` with `--skip-feature-creation` 
                    
                    It is assumed that <input_dir> is a directory containing buzzsaw TSV files matching the pattern
                    <input_file_regex>, where this regex has one capture group which captures an integer, e.g
                    "part-(\d+)" 
            """
        )
        parser.add_argument(
            "--threads",
            dest="threads",
            default=cpu_count(),
            type=int,
            help="Threads to use for writes and grid search")
        parser.add_argument(
            "--trials",
            dest="trials",
            default=20,
            type=int,
            help="When using random search, maximum number of iterations to use"
        )
        parser.add_argument(
            '--keep-sparse-empty',
            dest="keep_empty",
            action="store_true",
            help="keep empty instances, i.e all zero imputed feature instances")
        parser.add_argument(
            "--query-id-column",
            type=int,
            help="Column index within features to be used to determine query ID"
        )
        parser.add_argument(
            "--weight-column",
            type=int,
            help="Column index within features to be used to determine importance weighting"
        )
        parser.add_argument("--final-full-retrain", dest="finalFullRetrain",
                action="store_true",
                help="If set, performs a final retrain based on all the data "\
                     "without splitting.  There will be no 'test' run following "\
                     "as that split won't exist"
                )

        # External
        parser.add_argument(
            "--higher-is-better",
            dest="higherIsBetter",
            action="store_true",
            help="If set, higher scores are better."
        )
        parser.add_argument(
            "--train-only",
            dest="trainOnly",
            action="store_true",
            help="Features already exists, just start training."
        )

        return parser

    def __call__(self, args):
        return trainer(args)
