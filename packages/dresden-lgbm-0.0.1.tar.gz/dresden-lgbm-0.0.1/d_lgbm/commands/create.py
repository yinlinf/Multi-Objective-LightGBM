from __future__ import absolute_import
from itertools import islice, chain
import json
import logging
import multiprocessing

from buzzsaw import Buzzsaw

from d_common.iterutils import shuffle, batch, batch_with
from d_common.logger import setupLogging, logArgs, lps
from d_common.utils import yieldLines, yieldLinesFromDirectory
from d_common.mt import ParPipeline, Map, flatten

from d_lgbm.utils import LGBMFileSystem, sparse_vector_string_extract_column, PointwiseFeatureParser
from d_lgbm.processor import Processor

from .command import Command
from six.moves import map


def setupLogger(args):
    lgfs = LGBMFileSystem(args.dataset)
    setupLogging(lgfs.getLogFile('create'))
    logArgs()


def fit_buzzsaw(config_file, p_settings, docs, grouped):
    # Open buzzsaw config
    with open(config_file) as f:
        raw_config = f.read()
        config = json.loads(raw_config)

    logging.info("Config:")
    for line in raw_config.split('\n'):
        logging.info(line.rstrip())

    logging.info("Fitting buzzsaw...")
    docs = Processor.fit_set(docs, grouped, p_settings)

    return json.loads(Buzzsaw.fit(config, docs, raw=True))


def create_features_file(method, lgfs, doc_stream, proc, threads, grouped):
    if method == 'pairwise':

        def it():
            def f(bs):
                return list(proc.train(bs, grouped, raw=True))

            pipe = ParPipeline(threads=threads).add(Map(f)).add(flatten)
            return pipe(batch(doc_stream, 100))
        lgfs.saveFeatures(lps(it()))
    else:
        raise TypeError("Unknown task: {}".format(method))

def create_tsv_features_file(args, lgfs):
    read_func = get_read_func(args)
    doc_stream = read_func(args.file, postdelete=args.delete_after_copy)
    t_type = args.tType

    def features_pipeline():

        strip_batches_pipe = ParPipeline(threads=args.threads).add(
            Map(lambda doc_batch: list(map(lambda x: x.strip(), doc_batch))))

        if t_type == 'lambdarank':
            #For lambdarank, need to keep queries together, so batch in that manner
            feature_parser = PointwiseFeatureParser(args.has_weight,
                                                    args.query_id_column)

            def get_doc_query_id(doc):
                parsed_train_example = next(feature_parser.parse_data_line(doc))
                return sparse_vector_string_extract_column(
                    parsed_train_example.features, args.query_id_column)

            batched_doc_stream = batch_with(doc_stream, get_doc_query_id)
            #Unlike for pointwise, we don't want flattening to be done within ParPipeline, because
            # this will interleave documents from different batches
            return (doc
                    for doc_batch in strip_batches_pipe(batched_doc_stream)
                    for doc in doc_batch)
        else:
            batched_doc_stream = batch(doc_stream, args.batch_size)
            strip_flatten_pipe = strip_batches_pipe.add(flatten)
            return strip_flatten_pipe(batched_doc_stream)

    lgfs.saveTsvFeatures(features_pipeline())

def save_metadata(args, lgfs):

    t_type = args.tType
    p_settings = {
        "method": t_type,
        "has_weight": args.has_weight,
        "seed": args.seed
    }

    with open(args.fitted_config, encoding="utf-8") as f:
        fitted_config = json.load(f)

    fitted_processor = Processor.fit(fitted_config, "no_subsample", p_settings,
                                     False)
    lgfs.saveBuzzsaw(fitted_config)
    lgfs.saveProcessor(fitted_processor)
    lgfs.saveTask(args.tType)

def create_preprocessed(args):
    '''
        This function `_preprocessed` assumes that the input data
        is output of buzzsaw create.
        Example of Input data: 1   25  1:23 23:0.42 789:423
        This functions stores features from gcs to DATASET
    '''
    setupLogger(args)
    lgfs = LGBMFileSystem(args.dataset)
    t_type = args.tType

    if t_type == 'lambdarank' and args.query_id_column is None:
        raise ValueError(
            "In lambdarank mode, must pass in query ID column argument.")

    if not args.skip_feature_creation:
        create_tsv_features_file(args, lgfs)
    save_metadata(args, lgfs)

def create(args):
    setupLogger(args)
    read_func = get_read_func(args)

    lgfs = LGBMFileSystem(args.dataset)

    # Get subsample
    it = shuffle(
        read_func(args.file, postdelete=args.delete_after_copy), args.shuffle,
        args.seed)
    subsample = list(islice(it, args.docs_to_fit))

    # Build processor settings
    p_settings = {
        "method": args.tType,
        "has_weight": args.has_weight,
        "seed": args.seed
    }

    # Fit buzzsaw
    buzz_config = fit_buzzsaw(args.config, p_settings, subsample, args.grouped)
    lgfs.saveBuzzsaw(buzz_config)

    # Fit the postprocessor
    bz = Buzzsaw.from_config(buzz_config)
    fitted = Processor.fit(bz, subsample, p_settings, args.grouped)

    # Re-constitute the data
    it = chain(subsample, it)

    # Build features
    proc = Processor.load(bz, **fitted)
    if not args.skip_feature_creation:
        create_features_file(args.tType, lgfs, it, proc, args.threads, args.grouped)

    lgfs.saveProcessor(fitted)
    lgfs.saveTask(args.tType)

def get_read_func(args):
    read_func = yieldLines
    if args.read_from_directory:
        read_func = yieldLinesFromDirectory
    return read_func

class Create(Command):
    name = 'create'
    description = 'Builds dataset for LightGBM'

    def arguments(self, parser):
        parser.add_argument("file", metavar="DOCUMENT",
                            help="Training data",
                            nargs="?")

        parser.add_argument(
            "dataset",
            metavar="DATASET",
            help=
            "dataset directory contains trained_model, fitted_buzzsaw_config, processor, task, features after processed from buzzsaw_create"
        )

        parser.add_argument(
            "--read_from_directory",
            action="store_true",
            help="If present, the create will read data from the directory path"
        )

        parser.add_argument(
            "--delete_after_copy",
            action="store_true",
            help=
            "delete the original data after creating processed data to save on disk space"
        )

        parser.add_argument(
            "--threads",
            type=int,
            default=multiprocessing.cpu_count(),
            help="Number of threads to use in the processor pool")

        parser.add_argument(
            "--batch-size",
            dest="batch_size",
            type=int,
            default=100,
            help="batch size of docs to use in Parpipeline")

        parser.add_argument(
            "--query-id-column",
            type=int,
            help="Column index within features to be used to determine query ID"
        )

        parser.add_argument(
            "--skip-feature-creation",
            action='store_true',
            help="If specified, skip feature creation step (assume later stages will provide their own data)"
        )

        parser.add_argument(
            "--task-type",
            dest="tType",
            default='pairwise',
            choices=('pairwise', 'pointwise', 'lambdarank'),
            help="Task type to learn")

        parser.add_argument(
            "--has-weight",
            dest="has_weight",
            action="store_true",
            help="Gives we're including a weight field")

        parser.add_argument(
            "--seed", dest="seed", type=int, default=2017, help="Random seed")

        subparsers = parser.add_subparsers(
            dest='dataType', help='sub-command help')

        parser_raw_data = subparsers.add_parser(
            'rawData',
            help=
            'Assumes raw json training data. Fit and features using buzzsaw create is generated.'
        )
        parser_raw_data.add_argument("config", metavar="CONFIG", help="CONFIG")

        parser_raw_data.add_argument(
            "--docs-to-fit",
            dest="docs_to_fit",
            type=int,
            default=1000,
            help="Uses first N docs for fitting buzzsaw")

        parser_raw_data.add_argument(
            "--grouped",
            action="store_true",
            help="Indicates the format is grouped")

        parser_raw_data.add_argument(
            "--shuffle",
            type=int,
            default=10000,
            help="Buffer size for shuffling")

        parser_preprocessed = subparsers.add_parser(
            'preprocessed',
            help=
            'assume buzzsaw fit and features using buzzsaw create is already done using pyspark'
        )
        parser_preprocessed.add_argument(
            "--fitted-config", dest="fitted_config", help="store fitted config")

    def __call__(self, args):

        if  args.file is not None and args.skip_feature_creation:
            logging.warning("Passed in input file, but we are skipping feature creation")

        if args.file is None and not args.skip_feature_creation:
            raise ValueError("File must be specified when creating features")

        if args.dataType == 'rawData':
            create(args)

        elif args.dataType == 'preprocessed':
            create_preprocessed(args)
