import logging
import numpy as np
from pathlib import Path
import re
import shutil
from typing import List, Tuple

import d_common.logger as dlogger
from d_lgbm.utils import sparse_vector_string_extract_column

class LightGBMTrainValidFileCombiner:
    def __init__(self,
                 train_ratio:float,
                 query_id_column:int,
                 input_files_regex:str,
                 output_train_file:str,
                 output_valid_file:str):
        """
        :param train_ratio: What percentage of output examples are allocated to training examples
            (rest are validation examples)
        :param query_id_column: In the Buzzsaw TSV features, column number of the query ID. This is used
            to ensure that queries are kept together for LambdaRank

            If None, assume that queries don't need to be kept together
        :param input_files_regex: Regular expression to match input files to combine.
            Regular expression must have one capture group which captures a number. This number is used to
            Order the input files properly. For instance, regex r"part-(\d+)" will ensure that input files
            part-01,part-02,part-03 are ordered in increasing order

            Input files assumed to be in Buzzsaw TSV format
        :param output_train_file: Output file path for the training examples file.
        :param output_valid_file: Output file path for the validation examples file.
        """
        self._train_ratio = train_ratio
        self._query_id_column = query_id_column
        self._input_files_regex = input_files_regex
        self._output_train_file = output_train_file
        self._output_valid_file = output_valid_file

    def _get_ordered_files_list(self, directory:str) -> List[Path]:
        """
        :param directory: Directory containing input files
        :return: List of Path, input files ordered by the number extracted by regex
        """
        path = Path(directory)
        idx2file = {}
        for file in path.iterdir():
            pat_match = re.match(self._input_files_regex, file.name)
            if not pat_match:
                continue
            idx = int(pat_match.group(1))
            idx2file[idx] = file
        return [idx2file[idx] for idx in sorted(idx2file)]


    def _split_file_at_closest_listing_boundary(self,
                                                file:Path,
                                                desired_split_point_bytes:int) -> Tuple[str,str]:
        """
        :param file: File to split into two parts, containing Buzzsaw TSV formatted example lines
        :param desired_split_point_bytes: File offset in bytes we want split to be close to
        :return: Tuple of strings (left_content,right_content) of the split file, each containing
            Buzzsaw TSV formatted example lines
        """
        with file.open() as fid:
            lines = fid.readlines()

        cum_size = 0

        line_idx = 0
        for line_idx, line in enumerate(lines):
            cum_size += len(line)

            if cum_size > desired_split_point_bytes:
                # Keep going until we've reach our desired split point and have seen at least one query
                break

        # Split at last line
        left_content = "".join(lines[:line_idx])
        right_content = "".join(lines[line_idx:])

        return left_content, right_content

    def _split_file_at_closest_query_boundary(self,
                                              file:Path,
                                              desired_split_point_bytes:int) -> Tuple[str,str]:
        """
        :param file: File to split into two parts, containing Buzzsaw TSV formatted example lines
        :param desired_split_point_bytes: File offset in bytes we want split to be close to
        :return: Tuple of strings (left_content,right_content) of the split file, each containing
            Buzzsaw TSV formatted example lines
        """

        with file.open() as fid:
            lines = fid.readlines()

        last_query_id = None
        last_query_start_idx = None
        cum_size = 0
        found_boundary = False

        for line_idx,line in enumerate(lines):
            line_query_id = int(sparse_vector_string_extract_column(line, self._query_id_column))
            cum_size += len(line)

            if last_query_id != line_query_id:
                if last_query_id is not None:
                    found_boundary = True
                #on this line we switch to a new query
                last_query_start_idx = line_idx
                last_query_id = line_query_id

            if cum_size > desired_split_point_bytes and found_boundary:
                #Keep going until we've reach our desired split point and have seen at least one query
                break

        if not found_boundary:
            """
            This can happen if the file being split has only one query
            It is possible that this query extends into previous or subsequent files, and will be broken apart.
            However, this should be inconsequential if training data is large enough.
            """
            logging.warning(f"No query boundary found in {file}")
            left_content = "".join(lines)
            right_content = ""
        else:
            # Split at the last query starting point
            left_content = "".join(lines[:last_query_start_idx])
            right_content = "".join(lines[last_query_start_idx:])


        return left_content, right_content


    def _create_train_valid_from_input_files(self,
                                             files_list:List[Path]) -> None:
        """
        :param files_list: Ordered list of input files to combine
        :return: Create training examples / validation examples files
        """
        file_sizes_bytes = [f.stat().st_size for f in files_list]

        total_size_bytes = sum(file_sizes_bytes)
        logging.info(f"Total size of input files in GB: {total_size_bytes/(1024**3)}")

        overall_split_point_bytes = total_size_bytes * self._train_ratio
        cum_size_bytes = np.cumsum(file_sizes_bytes)

        #Index of the file where the split will occur
        file_to_split_idx = np.searchsorted(cum_size_bytes, overall_split_point_bytes)
        logging.info(f"File where split will occur: {files_list[file_to_split_idx]}")

        if file_to_split_idx == 0:
            #Split point lies within the first file
            within_file_split_point = overall_split_point_bytes
        else:
            #Find byte offset within the file to be split
            within_file_split_point = overall_split_point_bytes - cum_size_bytes[file_to_split_idx - 1]

        if self._query_id_column is not None:
            split_func = self._split_file_at_closest_query_boundary
        else:
            split_func = self._split_file_at_closest_listing_boundary

        left_content, right_content = split_func(files_list[file_to_split_idx],
                                                        within_file_split_point)

        with open(self._output_train_file,'w') as train_fid:
            logging.info("Writing training file...")
            for inp_file in dlogger.lps(files_list[:file_to_split_idx], N=50):
                with inp_file.open() as inp_fid:
                    shutil.copyfileobj(inp_fid, train_fid)
            train_fid.write(left_content)

        with open(self._output_valid_file,'w') as valid_fid:
            logging.info("Writing validation file...")
            valid_fid.write(right_content)
            for inp_file in dlogger.lps(files_list[(file_to_split_idx+1):], N=50):
                with inp_file.open() as inp_fid:
                    shutil.copyfileobj(inp_fid, valid_fid)

    def create_train_valid_files(self,
                                 input_files_directory:str):
        """
        :param input_files_directory: Directory with individual input files to merge into train/validation
        :return: Create trainining examples and validation examples files
        """
        input_files = self._get_ordered_files_list(input_files_directory)
        self._create_train_valid_from_input_files(input_files)