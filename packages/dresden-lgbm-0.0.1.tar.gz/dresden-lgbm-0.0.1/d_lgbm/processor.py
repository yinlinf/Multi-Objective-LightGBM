from __future__ import absolute_import
import json

import numpy as np

from d_common.sparse import split_tsv, feat_to_csr
from d_common.timing import time_metrics

class Processor(object):
    """
    Basic processor for building LightGBM compatible features
    """

    @classmethod
    def fit(cls, bz, sample, settings, grouped):
        method = settings['method']
        fit = cls._get_method(method).fit(bz, sample, settings, grouped)
        return {"method": method, "settings": fit}

    @classmethod
    def load(cls, bz, method, settings):
        return cls._get_method(method).load(bz, **settings)

    @classmethod
    def fit_set(cls, docs, grouped, settings):
        return cls._get_method(settings['method']).fit_set(
            docs, grouped, settings)

    @staticmethod
    def _get_method(method):
        if method == 'pairwise':
            return PairwiseProcessor
        elif method in ('pointwise', 'lambdarank'):
            return PointwiseProcessor
        else:
            raise NotImplementedError(method)

    def train(self, docs, grouped, raw):
        """
        Responsible for building the train dataset
        """
        raise NotImplementedError()

    def features(self, docs, grouped, raw):
        """
        Responsible for producing inference features
        """
        raise NotImplementedError()

    def channels(self):
        """
        Retrieves the channels required for producing features.
        """


class PointwiseProcessor(Processor):
    '''
       This is currently used for inference. 
        For features, this expects a list of json docs. 
    '''

    def __init__(self, bz, has_weight=True, has_label=True):
        self.bz = bz
        self.has_weight = has_weight
        self.has_label = has_label

    @classmethod
    def fit(cls, bz, sample, settings, grouped):
        return {
            "has_weight": settings["has_weight"],
            "seed": settings.get("seed", 2017)
        }

    @classmethod
    def load(cls, bz, has_weight, seed):
        return cls(bz, has_weight, seed)

    def features(self, docs, grouped=False, raw=False, n_feats=None):
        with time_metrics('prediction', tags=('interface:lightgbm', 'step:buzzsawFeaturization')):
            tsvs = self.bz.features(docs, grouped=False, raw=raw)
        res = []

        with time_metrics('prediction', tags=('interface:lightgbm', 'step:csrSparseMatrix')):
            for tsv in tsvs:
                feats = split_tsv(tsv, self.has_weight, False, False)[-1]
                res.append(feat_to_csr(feats, n_feats))

        return res

    def channels(self):
        return self.bz.channels()


class PairwiseProcessor(Processor):
    """
    Expects [doc1, doc2] for train
    Expects doc for features
    """

    def __init__(self, bz, has_weight, seed=2017):
        self.bz = bz
        self.has_weight = has_weight
        self.rs = np.random.RandomState(seed)

    @classmethod
    def fit(cls, bz, sample, settings, grouped):
        return {
            "has_weight": settings["has_weight"],
            "seed": settings.get("seed", 2017)
        }

    @classmethod
    def load(cls, bz, has_weight, seed):
        return cls(bz, has_weight, seed)

    def channels(self):
        return self.bz.channels()

    def train(self, docs, grouped=False, raw=False):
        assert not grouped, "Not implemented yet"
        if raw:
            docs = [json.loads(di) for di in docs]

        # Grouped in pairs
        for pair in self.bz.train(docs, True, False):
            d = []
            for p in pair:
                t, w, _, f = split_tsv(p, self.has_weight, False, True)
                d.append({"target": t, "weight": w, "feats": f})

            yield d

    def features(self, docs, grouped=False, raw=False, n_feats=None):
        with time_metrics('prediction', tags=('interface:lightgbm', 'step:buzzsawFeaturization')):
            tsvs = self.bz.features(docs, False, raw)
        res = []

        with time_metrics('prediction', tags=('interface:lightgbm', 'step:csrSparseMatrix')):
            for tsv in tsvs:
                feats = split_tsv(tsv, self.has_weight, False, False)[-1]
                res.append(feat_to_csr(feats, n_feats))

        return res

    @classmethod
    def fit_set(cls, docs, grouped, settings):
        nd = []
        for d in docs:
            for di in json.loads(d):
                if grouped:
                    nd.extend(dis for dis in di)
                else:
                    nd.append(di)

        return [json.dumps(d) for d in nd]
