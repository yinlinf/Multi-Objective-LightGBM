from __future__ import absolute_import
from abc import ABCMeta, abstractmethod
from collections import namedtuple
import os
import re
import datetime

from d_common.storage.filesystem import FileSystem, File, EnsureFS
import six


class LGBMFileSystem(FileSystem):
    buzzsaw = File.json('buzzsaw')
    processor = File.json('processor')
    task = File.json('task')
    model = File.raw('model')
    features = File.json_stream('features')
    tsvFeatures = File.raw_stream('tsvFeatures')

    @property
    @EnsureFS
    def trainFeatures(self):
        return self.features + '.train'

    @property
    @EnsureFS
    def testFeatures(self):
        return self.features + '.test'

    @property
    @EnsureFS
    def trainFeatures(self):
        return self.features + '.train'

    @property
    @EnsureFS
    def testFeatures(self):
        return self.features + '.test'

    @EnsureFS
    def getLogFile(self, prefix):
        t = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        return os.path.join(self.path, "%s-%s.log" % (prefix, t))


def sparse_vector_string_extract_column(sparse_vector_string, column_id):
    """
    :param sparse_vector_string: A string representation of a sparse vector in space separated
        index:value format e.g. "0:3.44 1:9.44 34:344.554"
    :param column_id: Integer, column ID to extract value for
    :return: float, value of sparse vector for this column
    """
    ptn = "(^|\s)%d:(.+?)($|\s)" % column_id
    match = re.search(ptn, sparse_vector_string)
    if match is None:
        return None
    return float(match.group(2))


"""
Represents a parsed training example read from a features file
label: integer, represents the class of this instance
weight: float, the weight assigned to this training instance.
features: string. A string representation of a sparse vector in space separated
        index:value format e.g. "0:3.44 1:9.44 34:344.554"
query_id: string. The query ID of this training example if it exists, or None  
"""
ParsedTrainExample = namedtuple('RawTrainExample',
                                'label weight features query_id')


class RawFeatureParser(six.with_metaclass(ABCMeta)):
    @abstractmethod
    def parse_data_line(self, data_line):
        """
        :param data_line: object, represents an unparsed training instance or instances read from
            one line of a file
        :return: An iterable of ParsedTrainExample
        """
        pass


class PairwiseFeatureParser(RawFeatureParser):
    def __init__(self):
        self._query_id = 0

    def parse_data_line(self, data_line):
        """
        :param data_line: A python list extracted from a JSON array, in which:
            - The array contains all instances from one query
            - Each instance has a field "target" which is an integer , and a field "feats"
                which is a string representation of a sparse vector in space separated index:value format
        :return: An iterable of ParsedTrainExample
        """
        assert (isinstance(data_line, list))
        self._query_id += 1
        for d in data_line:
            yield ParsedTrainExample(
                int(d['target']), 1, d['feats'], self._query_id)


class PointwiseFeatureParser(RawFeatureParser):
    def __init__(self, has_weight, query_id_column=None, keep_empty=False):
        """
        :param has_weight: If True, data lines includefor training instances
        :param query_id_column: Column index for a feature that specifies query ID if it exists, or None
        """

        self._has_weight = has_weight
        self._query_id_column = query_id_column
        self._keep_empty = keep_empty

    def parse_data_line(self, data_line):
        """
        :param data_line: A line of TSV outputted by buzzsaw which either contains:
            <target>\t<weight>\t<features>, or
            <target>\t<features>
            Where <features> is a string representation of a sparse vector
                with index:value format e.g. "0:3.44 1:9.44 34:344.554"
        :return: An interable of ParsedTrainExample
        """
        data_list = data_line.strip().split("\t")
        query_id = None
        _EMPTY_FEATURES = '0:0.0'
        if self._has_weight:

            if self._keep_empty and len(data_list) == 2:
                # Empty instances behavior
                label, weight = data_list
                features = _EMPTY_FEATURES
                weight = float(weight)
            else:
                assert len(
                    data_list
                ) == 3, "format of data should be `label weight features`. got data_line: %s" % data_list
                label, weight, features = data_list
                weight = float(weight)
        else:
            if self._keep_empty and len(data_list) == 1:
                # Empty instances behavior
                label = data_list[0]
                features = _EMPTY_FEATURES
                weight = 1.0
            else:
                assert len(
                    data_list
                ) == 2, "format of data should be `label features`. got data_line: %s" % data_list
                label, features = data_list
                weight = 1.0

        if self._query_id_column is not None:
            query_id = sparse_vector_string_extract_column(
                features, self._query_id_column)
            query_id = int(query_id)

        yield ParsedTrainExample(label, weight, features, query_id)
