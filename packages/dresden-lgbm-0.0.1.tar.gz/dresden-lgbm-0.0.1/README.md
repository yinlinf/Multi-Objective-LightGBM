

How to use tree models in d_lgbm ?
----------------------------------


Prerequisites:
-------------

As of now, `d_lgbm` models take as input:
- Features outputted by buzzsaw in tsv format (`label	weight	{feat_num:feat_value}`)
- A fit configuration outputted by buzzsaw.

We can use `pyspark_buzzsaw_driver` to generate features and a buzzsaw fit configuration.


Create:
-------

Creates a dataset for LGBM. 
After running this command the new dataset will contain training features in a format that LGBM can read (for the train command),
and a buzzsaw fit configuration (which can later be used for evaluation on raw unprocessed features).

```console
$ lgbm.py create -h
usage: lgbm.py create [-h] [--threads THREADS]
                      [--task-type {pairwise,pointwise}] [--has-weight]
                      [--seed SEED]
                      DOCUMENT DATASET {rawData,preprocessed} ...

positional arguments:
  DOCUMENT              Training data
  DATASET               Dumps data to disk
  {rawData,preprocessed}
                        sub-command help
    rawData             raw parser help
    preprocessed        pyspark parser help

optional arguments:
  -h, --help            show this help message and exit
  --threads THREADS     Number of threads to use in the processor pool
  --task-type {pairwise,pointwise}
                        Task type to learn
  --has-weight          include a weight field
  --seed SEED           Random seed
```

- `DOCUMENT` refers to training data. For pointwise learning, currently supports features that have already been processed (for eg: features already generated from `pyspark_buzzsaw_driver`).
- `DATASET` Is the path for the dataset to be created. 

refers to a location where we store buzzsaw\_fit\_config, processor, features and model. 

Currently `preprocessed` is only supported for pointwise learning. 

Train:
------

```console
$ lgbm.py train -h
usage: lgbm.py train [-h] [--seed SEED] [--split SPLIT] [--threads THREADS]
                     [--trials TRIALS] [--final-full-retrain]
                     [--higher-is-better] [--keep-sparse-empty]
                     dataset config

positional arguments:
  dataset               Dataset
  config                lightgbm config. This config inclues hyper-parameters for training tree models

optional arguments:
  -h, --help            show this help message and exit
  --seed SEED           Random Seed
  --split SPLIT         Amount to split train and test
  --threads THREADS     Threads to use for writes and grid search
  --trials TRIALS       When using random search, maximum number of iterations
                        to use
  --final-full-retrain  If set, performs a final retrain based on all the data
                        without splitting. There will be no 'test' run
                        following as that split won't exist
  --higher-is-better    If set, higher scores are better.
  --keep-sparse-empty   Keeps empty instances, when data is in sparse format
```

- `dataset` is the same location which is mentioned in create step. Use the same location so that train used features/processor/config from create
- `config` Is a path to a template for a LightGBM configuration file, 
whose full list of parameters can be seen [here](https://lightgbm.readthedocs.io/en/latest/Parameters.html).
This template can specify distributions of hyper-parameters in the same manner as `param-search.py`. 
We use random search to pick one set of hyperparamters on each trial.  
[Here](https://github.etsycorp.com/Engineering/dresden/blob/master/dresden-lightgbm/examples/pairwise/train.conf) is an example config. 
Consult [documentation for param-search.py](../dresden-hp/README.md) for more detail on how to specify random 
distributions, like `{s:randint:10:50}` in this example. 


Please refer to the production train and test scripts for end-to-end pipeline

 Train - projects/ranking/csr/prod-scripts/dresden_csr_train_lgbm_fixed_gcp_etl_prod.sh
 Test  - projects/ranking/csr/prod-scripts/lgbm_dresden_test_ranker_prod.sh

Example Code:
-------------

Please refer to following snippet for usage of create and train commands 


```sh
# buzzsaw fit config
GCSP_PYSPARK_FIT_CONFIG="gs://etldata-prod-search-ranking-data-hkwv8r/user/kchakka/oozie-adhoc/pyspark_fit_configs/fit_config_test-libsvm.json"

# features generated using buzzsaw fit config
GCS_PYSPARK_FEATURES_PATH="/user/kchakka/oozie-adhoc/pyspark_output/testing_libsvm"


GCS_TRAINING_DATA_PATH="/data/shared/ranking/static_ranking_dresden"
GCS_BUCKET_NAME="gs://etldata-prod-search-ranking-data-hkwv8r"

# new directory where the new trained model, fitted config, processor, task is stored. 
# This path can be in local or gcs
DATASET=/home/kchakka/dresden/projects/ranking/csr/prod-scripts/lgbm_dataset
mkdir -p $DATASET

# get the fitted buzzsaw config and store it in temporary location
gsutil cat $GCSP_PYSPARK_FIT_CONFIG > /tmp/buzzsaw_config

# streams features and stores in DATASET. 
# `lgbm.py create` also stores the fitted buzzsaw config that is downloaded to /tmp to DATASET
gcs-stream.sh \
"$GCS_BUCKET_NAME" \
"$GCS_PYSPARK_FEATURES_PATH" | head -n 200 | \
lgbm.py create - $DATASET --task-type pointwise --has-weight preprocessed --fitted-config /tmp/buzzsaw_config

#Training tree models. This trains multiple tree models for hp search and selects the model with best validation score. 
#Data is split into training and validation, and we select best hps based on best validation score. 
lgbm.py train $DATASET /home/kchakka/dresden/projects/ranking/csr/prod-scripts/train.conf \
 --trials 15 \  # number of hyper-parameter config searches
 --split 0.5    # proportion of data used for training (rest for validation)

#Run test ranker to get ndcg scores

gsutil cat gs://etldata-prod-search-ranking-data-hkwv8r/data/shared/ranking/static_ranking_dresden/2019-04-01/results/part-00000 | \
 dresden-test.py ranker \
--metric ndcg \
--metric-at 10 \
--data-format list \
--ranker "LGBMRanker" "d_lgbm.interfaces:Ranker" $DATASET '{}' \
- --threads 1 \
--field-ranker order queryPos false \
--random-ranker \
--test-only \
--score-action purchase \
--score-action click

```



#### [Description about hyper-parameters for trees](https://lightgbm.readthedocs.io/en/latest/Parameters.html)

* `boosting_type`: support gbdt for now, alias: boosting, boost.
  * `gbdt`, traditional Gradient Boosting Decision Tree, aliases: `gbrt`
  * `rf`, Random Forest, aliases: `random_forest`
  * `dart`, [Dropouts meet Multiple Additive Regression Trees](https://arxiv.org/abs/1505.01866)
  * `goss`, Gradient-based One-Side Sampling

* `objective`: objective function to optimize
  * Possible values are  `regression`, `regression_l1`, `huber`, `fair`, `poisson`, `quantile`, `mape`, `gamma`, `tweedie`, `binary`, `multiclass`, `multiclassova`, `xentropy`, `xentlambda`, `lambdarank`

* `metric`: metric(s) to be evaluated on the evaluation set(s). support multiple metrics, separated by `,`
  * `l1`, absolute loss, aliases: `mean_absolute_error`, `mae`, `regression_l1`
  * `l2`, square loss, aliases: `mean_squared_error`, `mse`, `regression_l2`, `regression`
  * `l2_root`, root square loss, aliases: `root_mean_squared_error`, `rmse`
  * `quantile`, [Quantile regression](https://en.wikipedia.org/wiki/Quantile_regression)
  * `mape`, [MAPE loss](https://en.wikipedia.org/wiki/Mean_absolute_percentage_error), aliases: `mean_absolute_percentage_error`
  * `huber`, [Huber loss](https://en.wikipedia.org/wiki/Huber_loss)
  * `fair`, [Fair loss](https://www.kaggle.com/c/allstate-claims-severity/discussion/24520)
  * `poisson`, negative log-likelihood for [Poisson regression](https://en.wikipedia.org/wiki/Poisson_regression)
  * `gamma`, negative log-likelihood for **Gamma** regression
  * `gamma_deviance`, residual deviance for **Gamma** regression
  * `tweedie`, negative log-likelihood for **Tweedie** regression
  * `ndcg`, [NDCG](https://en.wikipedia.org/wiki/Discounted_cumulative_gain#Normalized_DCG), aliases: `lambdarank`
  * `map`, [MAP](https://makarandtapaswi.wordpress.com/2012/07/02/intuition-behind-average-precision-and-map/), aliases: `mean_average_precision`
  * `auc`, [AUC](https://en.wikipedia.org/wiki/Receiver_operating_characteristic#Area_under_the_curve)
  * `binary_logloss`, [log loss](https://en.wikipedia.org/wiki/Cross_entropy), aliases: `binary`
  * `binary_error`, for one sample: `0` for correct classification, `1` for error classification
    * `multi_logloss`, log loss for multi-class classification, aliases: `multiclass`, `softmax`, `multiclassova`, `multiclass_ova`, `ova`, `ovr`
  * `multi_error`, error rate for multi-class classification
  * `xentropy`, cross-entropy (with optional linear weights), aliases: `cross_entropy`
  * `xentlambda`, “intensity-weighted” cross-entropy, aliases: `cross_entropy_lambda`
  * `kldiv`, [Kullback-Leibler divergence](https://en.wikipedia.org/wiki/Kullback–Leibler_divergence), aliases: `kullback_leibler`
* `metric_freq` - frequency to output metric
  * default : `1`, alias : `output_freq`
* `is_training_metric`: set this to `true` to output metric result over training dataset
* `max_bin` : max number of bins that feature values will be bucketed in
  * small number of bins may reduce training accuracy but may increase general power (deal with over-fitting)
* `num_trees` : number of boosting iterations
  * `alias`: num_tree, num_iteration, num_iterations, num_round, num_rounds
* `learning_rate` : shrinkage rate, default=`0.1`
* `num_leaves`: max number of leaves in one tree
  * default : `31`, aliases: `num_leaf`, `max_leaves`, `max_leaf`, constraints: `num_leaves > 1`
* `early_stopping_round`: will stop training if one metric of one validation data doesn’t improve in last early_stopping_round rounds
  * default: `0`,  aliases: `early_stopping_rounds`, `early_stopping`
* `tree_learner`: default = `searial`
  * `serial`, single machine tree learner
  * `feature`, feature parallel tree learner, aliases: `feature_parallel`
  * `data`, data parallel tree learner, aliases: `data_parallel`
  * `voting`, voting parallel tree learner, aliases: `voting_parallel`
* `num_threads`: default = `0`
  * umber of threads for LightGBM
  * `0` means default number of threads in OpenMP
  * for the best speed, set this to the number of **real CPU cores**, not the number of threads (most CPUs use [hyper-threading](https://en.wikipedia.org/wiki/Hyper-threading) to generate 2 threads per CPU core)
  * do not set it too large if your dataset is small (for instance, do not use 64 threads for a dataset with 10,000 rows)
* `feature_fraction`: default = `1.0` , aliases: `sub_feature`, `colsample_bytree`, constraints: `0.0 < feature_fraction <= 1.0`
  * LightGBM will randomly select part of features on each iteration if `feature_fraction` smaller than `1.0`. For example, if you set it to `0.8`, LightGBM will select 80% of features before training each tree
  * can be used to speed up training
  * can be used to deal with over-fitting
* `bagging_fraction`: default = `1.0`
  * like `feature_fraction`, but this will randomly select part of data without resampling
  * can be used to speed up training
  * can be used to deal with over-fitting
  * **Note**: to enable bagging, `bagging_freq` should be set to a non zero value as well
* `bagging_freq`: default = `0`
  * frequency for bagging
  * `0` means disable bagging; `k` means perform bagging at every `k` iteration
* `min_data_in_leaf`: default = `20`, aliases: `min_data_per_leaf`, `min_data`, `min_child_samples`, constraints: `min_data_in_leaf >= 0`
  * minimal number of data in one leaf. Can be used to deal with over-fitting
* `min_sum_hessian_in_leaf` : default = `1e-3`, type = double, aliases: `min_sum_hessian_per_leaf`, `min_sum_hessian`, `min_hessian`, `min_child_weight`
  * minimal sum hessian in one leaf. Like `min_data_in_leaf`, it can be used to deal with over-fitting
* `is_enable_sparse`: default=`true`, aliases: `is_sparse`, `enable_sparse`, `sparse`
  * used to enable/disable sparse optimization
* `use_two_round_loading`: default=`false`, aliases: `two_round_loading`, `use_two_round_loading`
  * set this to `true` if data file is too big to fit in memory
  * by default, LightGBM will map data file to memory and load features from memory. This will provide faster data loading speed, but may cause run out of memory error when the data file is very big
  * **Note**: works only in case of loading data directly from file
* `is_save_binary_file`: default = `false`, type = bool, aliases: `is_save_binary`, `save_binary`
  * if `true`, LightGBM will save the dataset (including validation data) to a binary file. This speed ups the data loading for the next time
