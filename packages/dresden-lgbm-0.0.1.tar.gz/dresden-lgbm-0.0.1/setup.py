#!/usr/bin/env python
from __future__ import absolute_import
from setuptools import setup

import d_lgbm

# Re-sync the requirements.txt when upgrading the package by running below mentioned command
# virtualenv venv
# source venv/bin/activate
# pip install .
# pip freeze | grep -v dresden-lgbm > requirements.txt
setup(
    name='dresden-lgbm',
    version=d_lgbm.__version__,
    description='LightGBM Dresden module',
    url="https://github.etsycorp.com/Engineering/dresden",
    packages=['d_lgbm', 'd_lgbm/commands'],
    scripts=["bin/lgbm.py"],
    install_requires=[
        'lightgbm==2.2.3', 'scipy==1.4.1', 'scikit-learn==0.20.2',
        'six==1.14.0', 'numpy==1.16.5'
    ],
    tests_require=['mock==3.0.5'],
    author='Etsy')
